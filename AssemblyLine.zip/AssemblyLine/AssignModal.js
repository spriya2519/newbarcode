// src/components/SupervisorInternal/AssignModal.jsx
import React, { useState, useEffect } from "react";
import {
  Dialog, DialogTitle, DialogContent, DialogActions, Button, FormControl, InputLabel, Select, MenuItem,
  Checkbox, ListItemText, OutlinedInput, Box, Typography
} from "@mui/material";

export default function AssignModal({ open, onClose, pcb, operators = [], activities = [], onSave }) {
  const [selectedOperator, setSelectedOperator] = useState("");
  const [selectedActivities, setSelectedActivities] = useState([]);

  useEffect(() => {
    if (!open) {
      setSelectedOperator("");
      setSelectedActivities([]);
    }
  }, [open]);

  const handleSave = () => {
    if (!selectedOperator) return alert("Choose operator");
    if (selectedActivities.length === 0) return alert("Choose at least one activity");
    const operatorObj = typeof selectedOperator === "string"
      ? operators.find(o => o.staffNumber === selectedOperator) || { name: selectedOperator }
      : selectedOperator;
    const activityObjects = selectedActivities.map(aid => activities.find(a => a.id === aid) || { id: aid, name: aid });
    onSave({
      operator: operatorObj,
      activities: activityObjects
    });
    onClose();
  };

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm">
      <DialogTitle>Assign Work {pcb?.serial ? `for ${pcb.serial}` : ""}</DialogTitle>
      <DialogContent>
        <Box sx={{ mt: 1 }}>
          <FormControl fullWidth size="small" sx={{ mb: 2 }}>
            <InputLabel>Operator</InputLabel>
            <Select
              value={selectedOperator}
              label="Operator"
              onChange={(e) => setSelectedOperator(e.target.value)}
            >
              {operators.length === 0 && <MenuItem value="">No operators (create in Admin)</MenuItem>}
              {operators.map(op => <MenuItem key={op.staffNumber || op.name} value={op.staffNumber || op.name}>{op.name} ({op.staffNumber || "—"})</MenuItem>)}
            </Select>
          </FormControl>

          <FormControl fullWidth size="small">
            <InputLabel>Activities</InputLabel>
            <Select
              multiple
              value={selectedActivities}
              onChange={(e) => setSelectedActivities(e.target.value)}
              input={<OutlinedInput label="Activities" />}
              renderValue={(selected) => selected.map(id => (activities.find(a => a.id === id) || { name: id }).name).join(", ")}
            >
              {activities.map(a => (
                <MenuItem key={a.id} value={a.id}>
                  <Checkbox checked={selectedActivities.indexOf(a.id) > -1} />
                  <ListItemText primary={a.name} />
                </MenuItem>
              ))}
            </Select>
            <Typography variant="caption" sx={{ mt: 1, display: "block" }}>Select activities to assign to this PCB.</Typography>
          </FormControl>
        </Box>
      </DialogContent>

      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleSave}>Assign Locally</Button>
      </DialogActions>
    </Dialog>
  );
}
