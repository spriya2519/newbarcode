// // App.js
// import React from "react";
// import { BrowserRouter as Router, Routes, Route, useNavigate } from "react-router-dom";
// import LoginPage from "./components/LoginPage";
// import AdminDashboard from "./components/AdminDashboard/AdminDashboard";
// import SupervisorInternal from "./components/SupervisorInternal";
// import SupervisorExternal from "./components/SupervisorExternal";
// import OperatorPage from "./components/OperatorPage";

// const App = () => {
//   const Wrapper = () => {
//     const navigate = useNavigate();

//     const handleLogin = (username, password) => {
//       if (username === "admin" && password === "123") {
//         navigate("/admin");
//       } else if (username === "supervisor_internal" && password === "123") {
//         navigate("/supervisor/internal");
//       } else if (username === "supervisor_external" && password === "123") {
//         navigate("/supervisor/external");
//       } else if (username === "operator" && password === "123") {
//         navigate("/operator");
//       } else {
//         alert("Invalid credentials");
//       }
//     };

//     return <LoginPage onLogin={handleLogin} />;
//   };

//   const DashboardWrapper = ({ Component }) => {
//     const navigate = useNavigate();

//     const handleLogout = () => {
//       navigate("/");
//     };

//     return <Component onLogout={handleLogout} />;
//   };

//   return (
//     <Router>
//       <Routes>
//         <Route path="/" element={<Wrapper />} />

//         <Route
//           path="/admin"
//           element={<DashboardWrapper Component={AdminDashboard} />}
//         />

//         <Route
//           path="/supervisor/internal"
//           element={<DashboardWrapper Component={SupervisorInternal} />}
//         />

//         <Route
//           path="/supervisor/external"
//           element={<DashboardWrapper Component={SupervisorExternal} />}
//         />

//         <Route
//           path="/operator"
//           element={<DashboardWrapper Component={OperatorPage} />}
//         />
//       </Routes>
//     </Router>
//   );
// };

// export default App;
// App.js



import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route, useNavigate } from "react-router-dom";

import LoginPage from "./LoginPage";
import AdminDashboard from "./AdminDashboard/AdminDashboard";
import SupervisorInternal from "./SupervisorInternal";
import SupervisorExternal from "./SupervisorExternal";
import OperatorPage from "./OperatorPage";



const App = (props) => {
  const [loginStatus, setloginStatus] = useState(false);


  const [serverStatus, setserverStatus] = useState({});

  // 🔥 Centralised state for PCB sent to Supervisor
  const [inactivePCBs, setInactivePCBs] = useState([]);

  // 🔥 For supervisor work assignment
  const handleAssignWork = (serial) => {
    setInactivePCBs((prev) =>
      prev.map((pcb) =>
        pcb.PCB_Serial === serial
          ? { ...pcb, isWorkAssigned: true }
          : pcb
      )
    );
  };

  // ------------------ LOGIN WRAPPER -----------------------
  const Wrapper = () => {
    const navigate = useNavigate();

    const handleLogin = (username, password) => {
      if (username === "admin" && password === "123") {
        navigate("/admin");
      } else if (username === "supervisor_internal" && password === "123") {
        navigate("/supervisor/internal");
      } else if (username === "supervisor_external" && password === "123") {
        navigate("/supervisor/external");
      } else if (username === "operator" && password === "123") {
        navigate("/operator");
      } else {
        alert("Invalid credentials");
      }
    };

    return <LoginPage onLogin={handleLogin} />;
  };

  console.log(JSON.parse(localStorage.getItem("inactiveList")));
  // ------------------ DASHBOARD WRAPPER --------------------
  const DashboardWrapper = ({ Component, extraProps }) => {
    const navigate = useNavigate();
    const handleLogout = () => navigate("/");

    return (
      <Component
        {...extraProps}
        onLogout={handleLogout}
      />
    );
  };

  // ------------------ ROUTES ------------------------
  return (
    <Router>
      <Routes>

        <Route path="/" element={<Wrapper />} />

        {/* ADMIN DASHBOARD */}
        <Route
          path="/admin"
          element={
            <DashboardWrapper
              Component={AdminDashboard}
              extraProps={{
                inactivePCBs: inactivePCBs,
                setInactivePCBs: setInactivePCBs,
              }}
            />
          }
        />

        {/* SUPERVISOR INTERNAL RECEIVES PCB LIST */}
        <Route
          path="/supervisor/internal"
          element={
            <DashboardWrapper
              Component={SupervisorInternal}
              extraProps={{
                inActionPCBs:JSON.parse(localStorage.getItem("inactiveList")),
                handleAssignWork: handleAssignWork,
              }}
            />
          }
        />

        <Route
          path="/supervisor/external"
          element={<DashboardWrapper Component={SupervisorExternal} />}
        />

        <Route
          path="/operator"
          element={<DashboardWrapper Component={OperatorPage} />}
        />
      </Routes>
    </Router>
  );
};

export default App;
