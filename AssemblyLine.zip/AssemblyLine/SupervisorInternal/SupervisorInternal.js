// // // import React, { useState } from "react";
// // import {
// //   Box,
// //   Button,
// //   TextField,
// //   Typography,
// //   Table,
// //   TableHead,
// //   TableRow,
// //   TableCell,
// //   TableBody,
// //   Paper,
// //   Grid,
// //   Card,
// //   IconButton,
// //   CardContent,
// //   AppBar,
// //   Toolbar,
// //   Alert,
// //   Drawer,
// // } from "@mui/material";

// // import LogoutIcon from "@mui/icons-material/Logout";
// // import { PieChart, Pie, Cell, Legend, Tooltip } from "recharts";
// // import { useState } from "react";
// // import { Build, Dashboard, GroupAdd, PlaylistAdd } from "@mui/icons-material";





// // const SupervisorInternal = ({
// //   onLogout,
// //   inActionPCBs = [],
// //   handleAssignWork,
// // }) => {
// //   const [activeTab, setActiveTab] = useState("dashboard");
// //   const [operators, setOperators] = useState([]);
// //   const [selectedPCB, setSelectedPCB] = useState(null);

// //   const [newOperator, setNewOperator] = useState({
// //     name: "",
// //     email: "",
// //     skill: "",
// //   });

// //   const COLORS = ["#8884d8", "#82ca9d"];
// //   const taskData = [
// //     { name: "Pending", value: inActionPCBs.filter((p) => !p.isWorkAssigned).length },
// //     { name: "Assigned", value: inActionPCBs.filter((p) => p.isWorkAssigned).length },
// //   ];

// //   const handleAddOperator = () => {
// //     if (!newOperator.name || !newOperator.email)
// //       return alert("Fill all details");

// //     setOperators([...operators, newOperator]);
// //     setNewOperator({ name: "", email: "", skill: "" });
// //   };

// //   /** ===========================
// //    *   PCB ASSIGNMENT UI (NEW)
// //    *  =========================== */
// //   const renderAssignPCB = () => {
// //     if (inActionPCBs.length === 0) {
// //       return (
// //         <Typography sx={{ p: 3, textAlign: "center" }}>
// //           No PCBs available for assignment.
// //         </Typography>
// //       );
// //     }

// //     const keyName =
// //       inActionPCBs[0]?._pcb_key_id || "PCB Serial Number";

// //     const baseColumns = Object.keys(inActionPCBs[0]).filter(
// //       (k) => !["id", "linkedOperations", "isWorkAssigned", "_pcb_key_id"].includes(k)
// //     );

// //     return (
// //       <Box sx={{ width: "90%", mx: "auto" }}>
// //         <Typography variant="h5" gutterBottom>
// //           Assign Operators to PCB Tasks
// //         </Typography>

// //         {selectedPCB && (
// //           <Alert
// //             severity="info"
// //             onClose={() => setSelectedPCB(null)}
// //             sx={{ mb: 2 }}
// //           >
// //             <strong>PCB:</strong> {selectedPCB[keyName]} — Mandatory Ops:{" "}
// //             {selectedPCB.linkedOperations?.length}
// //           </Alert>
// //         )}

// //         <Table component={Paper}>
// //           <TableHead>
// //             <TableRow>
// //               {baseColumns.map((col) => (
// //                 <TableCell key={col}>{col}</TableCell>
// //               ))}
// //               <TableCell>Status</TableCell>
// //               <TableCell>Assign</TableCell>
// //             </TableRow>
// //           </TableHead>

// //           <TableBody>
// //             {inActionPCBs.map((pcb, i) => {
// //               const serialNumber = pcb[keyName];
// //               return (
// //                 <TableRow key={i}>
// //                   {baseColumns.map((col) => (
// //                     <TableCell key={col}>
// //                       {col === keyName ? (
// //                         <Button
// //                           variant="text"
// //                           onClick={() => setSelectedPCB(pcb)}
// //                         >
// //                           {serialNumber}
// //                         </Button>
// //                       ) : (
// //                         pcb[col]
// //                       )}
// //                     </TableCell>
// //                   ))}

// //                   <TableCell
// //                     sx={{
// //                       fontWeight: "bold",
// //                       color: pcb.isWorkAssigned ? "green" : "red",
// //                     }}
// //                   >
// //                     {pcb.isWorkAssigned ? "ASSIGNED" : "PENDING"}
// //                   </TableCell>

// //                   <TableCell>
// //                     <Button
// //                       variant="contained"
// //                       size="small"
// //                       disabled={pcb.isWorkAssigned}
// //                       onClick={() => {
// //                         if (
// //                           window.confirm(
// //                             `Assign work for PCB ${serialNumber}?`
// //                           )
// //                         ) {
// //                           handleAssignWork(serialNumber);
// //                         }
// //                       }}
// //                     >
// //                       {pcb.isWorkAssigned ? "Assigned" : "Assign Work"}
// //                     </Button>
// //                   </TableCell>
// //                 </TableRow>
// //               );
// //             })}
// //           </TableBody>
// //         </Table>
// //       </Box>
// //     );
// //   };

// //   /** ===========================
// //    *   RENDER MAIN CONTENT
// //    *  =========================== */
// //   const renderContent = () => {
// //     switch (activeTab) {
// //       case "dashboard":
// //         return (
// //           <Box sx={{ width: "60%", mx: "auto" }}>
// //             <Typography variant="h5" gutterBottom>
// //               Dashboard Overview
// //             </Typography>

// //             <Grid container spacing={3}>
// //               <Grid item xs={12} md={6}>
// //                 <Card sx={{ p: 2 }}>
// //                   <CardContent>
// //                     <Typography variant="h6">PCB Status</Typography>

// //                     <PieChart width={300} height={250}>
// //                       <Pie
// //                         data={taskData}
// //                         cx={150}
// //                         cy={100}
// //                         outerRadius={80}
// //                         label
// //                         dataKey="value"
// //                       >
// //                         {taskData.map((entry, index) => (
// //                           <Cell
// //                             key={`cell-${index}`}
// //                             fill={COLORS[index % COLORS.length]}
// //                           />
// //                         ))}
// //                       </Pie>
// //                       <Tooltip />
// //                       <Legend />
// //                     </PieChart>
// //                   </CardContent>
// //                 </Card>
// //               </Grid>

// //               <Grid item xs={12} md={6}>
// //                 <Card sx={{ p: 2 }}>
// //                   <CardContent>
// //                     <Typography variant="h6">Summary</Typography>
// //                     <Typography>Total Operators: {operators.length}</Typography>
// //                     <Typography>Total PCBs: {inActionPCBs.length}</Typography>
// //                     <Typography>
// //                       Assigned:{" "}
// //                       {inActionPCBs.filter((p) => p.isWorkAssigned).length}
// //                     </Typography>
// //                     <Typography>
// //                       Pending:{" "}
// //                       {inActionPCBs.filter((p) => !p.isWorkAssigned).length}
// //                     </Typography>
// //                   </CardContent>
// //                 </Card>
// //               </Grid>
// //             </Grid>
// //           </Box>
// //         );

// //       case "createOperator":
// //         return (
// //           <Box sx={{ width: "60%", mx: "auto" }}>
// //             <Typography variant="h5" gutterBottom>
// //               Create Operator Profile
// //             </Typography>

// //             <TextField
// //               label="Name"
// //               fullWidth
// //               sx={{ mb: 2 }}
// //               value={newOperator.name}
// //               onChange={(e) =>
// //                 setNewOperator({ ...newOperator, name: e.target.value })
// //               }
// //             />

// //             <TextField
// //               label="Email"
// //               fullWidth
// //               sx={{ mb: 2 }}
// //               value={newOperator.email}
// //               onChange={(e) =>
// //                 setNewOperator({ ...newOperator, email: e.target.value })
// //               }
// //             />

// //             <TextField
// //               label="Skill"
// //               fullWidth
// //               sx={{ mb: 2 }}
// //               value={newOperator.skill}
// //               onChange={(e) =>
// //                 setNewOperator({ ...newOperator, skill: e.target.value })
// //               }
// //             />

// //             <Button variant="contained" onClick={handleAddOperator}>
// //               Add Operator
// //             </Button>

// //             <Typography variant="h6" sx={{ mt: 4 }}>
// //               Operator List
// //             </Typography>

// //             <Table component={Paper}>
// //               <TableHead>
// //                 <TableRow>
// //                   <TableCell>Name</TableCell>
// //                   <TableCell>Email</TableCell>
// //                   <TableCell>Skill</TableCell>
// //                 </TableRow>
// //               </TableHead>
// //               <TableBody>
// //                 {operators.map((op, i) => (
// //                   <TableRow key={i}>
// //                     <TableCell>{op.name}</TableCell>
// //                     <TableCell>{op.email}</TableCell>
// //                     <TableCell>{op.skill}</TableCell>
// //                   </TableRow>
// //                 ))}
// //               </TableBody>
// //             </Table>
// //           </Box>
// //         );

// //       case "assignTask":
// //         return renderAssignPCB();

// //       case "corrections":
// //         return (
// //           <Box sx={{ p: 3 }}>
// //             <Typography variant="h5">Process Correction Requests</Typography>
// //             <Typography sx={{ mt: 2 }}>
// //               (Correction requests will come from backend.)
// //             </Typography>
// //           </Box>
// //         );

// //       default:
// //         return null;
// //     }
// //   };

// //   return (
// //     <Box sx={{ height: "100vh", display: "flex", flexDirection: "column" }}>
// //       <Box sx={{ display: "flex", flex: 1 }}>
// //         {/* Sidebar */}
// //         <Drawer
// //         variant="permanent"
// //         sx={{
// //           width: 240,
// //           flexShrink: 0,
// //           [`& .MuiDrawer-paper`]: {
// //             width: 240,
// //             boxSizing: "border-box",
// //             backgroundColor: "#263238",
// //             color: "white",
// //           },
// //         }}
// //       >
// //         <Toolbar>
// //           <Typography variant="h6" sx={{ fontWeight: "bold", color: "#FFD600" }}>
// //             Supervisor (Internal)
// //           </Typography>
// //         </Toolbar>
// //           {/* <Typography variant="h6" sx={{ mb: 2, color: "#90caf9" }}>
           
// //           </Typography> */}

// //           <Button style={{backgroundColor: "#455A64",color:'white'}} color="info" onClick={() => setActiveTab("dashboard")}>
// //             Dashboard
// //           </Button>

// //           <Button style={{backgroundColor: "#455A64",color:'white'}} color="info" onClick={() => setActiveTab("createOperator")}>
// //             Create Operator
// //           </Button>

// //           <Button style={{backgroundColor: "#455A64",color:'white'}}color="info" onClick={() => setActiveTab("assignTask")}>
// //             Assign Task
// //           </Button>

// //           <Button style={{backgroundColor: "#455A64",color:'white'}} color="info" onClick={() => setActiveTab("corrections")}>
// //             Corrections
// //           </Button>
// //           </Drawer>

// //         {/* Main Content */}
// //         <Box sx={{ flex: 1, p: 0, backgroundColor: "#ECEFF1" }}>
// //           <AppBar position="static" sx={{ backgroundColor: "#37474F", mb: 2 }}>
// //             <Toolbar>
// //               <Typography variant="h6" sx={{ flexGrow: 1 }}>
// //                 Supervisor Internal Dashboard
// //               </Typography>
// //               <IconButton color="inherit" onClick={onLogout}>
// //                 <LogoutIcon />
// //               </IconButton>
// //             </Toolbar>
// //           </AppBar>

// //           {renderContent()}
// //         </Box>
// //       </Box>
// //     </Box>
// //   );
// // };

// // export default SupervisorInternal;


// import React, { useState } from "react";
// import {
//   Box,
//   Button,
//   TextField,
//   Typography,
//   Table,
//   TableHead,
//   TableRow,
//   TableCell,
//   TableBody,
//   Paper,
//   Grid,
//   Card,
//   CardContent,
//   AppBar,
//   Toolbar,
//   Alert,
//   Container,
//   CardActionArea,
//   Avatar,
//   Stack,
//   Divider,
//   Chip,
//   IconButton
// } from "@mui/material";

// // Icons
// import LogoutIcon from "@mui/icons-material/Logout";
// import DashboardIcon from "@mui/icons-material/Dashboard";
// import GroupAddIcon from "@mui/icons-material/GroupAdd";
// import AssignmentIcon from "@mui/icons-material/Assignment";
// import BuildIcon from "@mui/icons-material/Build";
// import PersonIcon from "@mui/icons-material/Person";
// import ArrowBackIcon from "@mui/icons-material/ArrowBack";

// import { PieChart, Pie, Cell, Legend, Tooltip, ResponsiveContainer } from "recharts";

// // --- Theme Colors ---
// const THEME = {
//   bg: "#f8fafc", // Very light slate
//   primary: "#1e293b", // Dark Slate
//   accent: "#f59e0b", // Amber
//   cardBg: "#ffffff",
//   textSecondary: "#64748b"
// };

// const SupervisorInternal = ({
//   onLogout,
//   inActionPCBs = [],
//   handleAssignWork,
// }) => {
//   // 'home' means showing the card grid. Any other string is a specific view.
//   const [currentView, setCurrentView] = useState("home");
  
//   const [operators, setOperators] = useState([]);
//   const [selectedPCB, setSelectedPCB] = useState(null);
//   const [newOperator, setNewOperator] = useState({
//     name: "",
//     email: "",
//     skill: "",
//   });

//   const COLORS = ["#6366f1", "#10b981"]; 

//   const taskData = [
//     { name: "Pending", value: inActionPCBs.filter((p) => !p.isWorkAssigned).length },
//     { name: "Assigned", value: inActionPCBs.filter((p) => p.isWorkAssigned).length },
//   ];

//   // --- Handlers ---
//   const handleAddOperator = () => {
//     if (!newOperator.name || !newOperator.email) return alert("Fill all details");
//     setOperators([...operators, newOperator]);
//     setNewOperator({ name: "", email: "", skill: "" });
//   };

//   // --- Navigation Config ---
//   const navCards = [
//     { 
//       id: "dashboard", 
//       title: "Overview Stats", 
//       desc: "View charts and workload distribution",
//       icon: <DashboardIcon sx={{ fontSize: 50, color: "#6366f1" }} />,
//       color: "#e0e7ff"
//     },
//     { 
//       id: "createOperator", 
//       title: "Manage Operators", 
//       desc: "Add new staff and view team roster",
//       icon: <GroupAddIcon sx={{ fontSize: 50, color: "#10b981" }} />,
//       color: "#d1fae5"
//     },
//     { 
//       id: "assignTask", 
//       title: "Assign Tasks", 
//       desc: `Manage ${inActionPCBs.length} active PCBs`,
//       icon: <AssignmentIcon sx={{ fontSize: 50, color: "#f59e0b" }} />,
//       color: "#fef3c7"
//     },
//     { 
//       id: "corrections", 
//       title: "Corrections", 
//       desc: "Handle process correction tickets",
//       icon: <BuildIcon sx={{ fontSize: 50, color: "#ef4444" }} />,
//       color: "#fee2e2"
//     },
//   ];

//   /** ===========================
//    * RENDER HELPERS
//    * =========================== */

//   const renderAssignPCB = () => {
//     if (inActionPCBs.length === 0) {
//       return (
//         <Paper sx={{ p: 5, textAlign: "center", mt: 4, borderRadius: 3 }}>
//           <Typography variant="h6" color="text.secondary">
//             No PCBs available for assignment.
//           </Typography>
//         </Paper>
//       );
//     }

//     const keyName = inActionPCBs[0]?._pcb_key_id || "PCB Serial Number";
//     const baseColumns = Object.keys(inActionPCBs[0]).filter(
//       (k) => !["id", "linkedOperations", "isWorkAssigned", "_pcb_key_id"].includes(k)
//     );

//     return (
//       <Box sx={{ maxWidth: "100%", mx: "auto" }}>
//         {selectedPCB && (
//           <Alert severity="info" onClose={() => setSelectedPCB(null)} sx={{ mb: 3 }}>
//             <strong>Selected:</strong> {selectedPCB[keyName]} — Operations Required:{" "}
//             {selectedPCB.linkedOperations?.length}
//           </Alert>
//         )}

//         <Paper sx={{ width: "100%", overflow: "hidden", borderRadius: 3, boxShadow: 2 }}>
//           <Table stickyHeader>
//             <TableHead>
//               <TableRow>
//                 {baseColumns.map((col) => (
//                   <TableCell key={col} sx={{ fontWeight: "bold", bgcolor: "#f1f5f9" }}>
//                     {col.toUpperCase()}
//                   </TableCell>
//                 ))}
//                 <TableCell sx={{ fontWeight: "bold", bgcolor: "#f1f5f9" }}>STATUS</TableCell>
//                 <TableCell sx={{ fontWeight: "bold", bgcolor: "#f1f5f9" }}>ACTION</TableCell>
//               </TableRow>
//             </TableHead>
//             <TableBody>
//               {inActionPCBs.map((pcb, i) => {
//                 const serialNumber = pcb[keyName];
//                 return (
//                   <TableRow hover key={i}>
//                     {baseColumns.map((col) => (
//                       <TableCell key={col}>
//                         {col === keyName ? (
//                           <Button
//                             size="small"
//                             onClick={() => setSelectedPCB(pcb)}
//                             sx={{ textTransform: "none", fontWeight: "bold" }}
//                           >
//                             {serialNumber}
//                           </Button>
//                         ) : (
//                           pcb[col]
//                         )}
//                       </TableCell>
//                     ))}
//                     <TableCell>
//                       <Chip 
//                         label={pcb.isWorkAssigned ? "ASSIGNED" : "PENDING"} 
//                         color={pcb.isWorkAssigned ? "success" : "warning"}
//                         size="small"
//                         variant="filled"
//                       />
//                     </TableCell>
//                     <TableCell>
//                       <Button
//                         variant="contained"
//                         size="small"
//                         disableElevation
//                         disabled={pcb.isWorkAssigned}
//                         onClick={() => {
//                           if (window.confirm(`Assign work for PCB ${serialNumber}?`)) {
//                             handleAssignWork(serialNumber);
//                           }
//                         }}
//                         sx={{ borderRadius: 2 }}
//                       >
//                         {pcb.isWorkAssigned ? "Done" : "Assign"}
//                       </Button>
//                     </TableCell>
//                   </TableRow>
//                 );
//               })}
//             </TableBody>
//           </Table>
//         </Paper>
//       </Box>
//     );
//   };

//   // --- Views ---

//   // 1. The "Home" Grid View
//   const renderHomeGrid = () => (
//     <Container maxWidth="lg" sx={{ mt: 4 }}>
//       <Box sx={{ mb: 4 }}>
//         <Typography variant="h4" fontWeight="800" color="text.primary">
//           Welcome, Supervisor
//         </Typography>
//         <Typography variant="body1" color="text.secondary">
//           Select a module to begin managing operations.
//         </Typography>
//       </Box>

//       <Grid container spacing={4}>
//         {navCards.map((card) => (
//           <Grid item xs={12} sm={6} md={3} key={card.id}>
//             <Card 
//               sx={{ 
//                 height: "100%", 
//                 borderRadius: 4, 
//                 boxShadow: 3,
//                 transition: "transform 0.2s",
//                 "&:hover": { transform: "translateY(-5px)", boxShadow: 6 }
//               }}
//             >
//               <CardActionArea 
//                 sx={{ height: "100%", p: 3, display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}
//                 onClick={() => setCurrentView(card.id)}
//               >
//                 <Box sx={{ 
//                   p: 2, 
//                   borderRadius: "50%", 
//                   bgcolor: card.color, 
//                   mb: 2,
//                   display: 'flex', alignItems: 'center', justifyContent: 'center'
//                 }}>
//                   {card.icon}
//                 </Box>
//                 <Typography variant="h6" fontWeight="bold" gutterBottom>
//                   {card.title}
//                 </Typography>
//                 <Typography variant="body2" color="text.secondary">
//                   {card.desc}
//                 </Typography>
//               </CardActionArea>
//             </Card>
//           </Grid>
//         ))}
//       </Grid>
//     </Container>
//   );

//   // 2. The Inner Module View
//   const renderModuleContent = () => {
//     switch (currentView) {
//       case "dashboard":
//         return (
//           <Grid container spacing={3}>
//             <Grid item xs={12} md={7}>
//               <Card sx={{ height: "100%", borderRadius: 3, boxShadow: 2 }}>
//                 <CardContent>
//                   <Typography variant="h6" gutterBottom>Workload Distribution</Typography>
//                   <Box sx={{ height: 300, width: '100%' }}>
//                       <ResponsiveContainer>
//                           <PieChart>
//                           <Pie
//                               data={taskData}
//                               cx="50%"
//                               cy="50%"
//                               innerRadius={60}
//                               outerRadius={80}
//                               paddingAngle={5}
//                               dataKey="value"
//                           >
//                               {taskData.map((entry, index) => (
//                               <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
//                               ))}
//                           </Pie>
//                           <Tooltip />
//                           <Legend verticalAlign="bottom" height={36}/>
//                           </PieChart>
//                       </ResponsiveContainer>
//                   </Box>
//                 </CardContent>
//               </Card>
//             </Grid>
//             <Grid item xs={12} md={5}>
//               <Card sx={{ height: "100%", borderRadius: 3, boxShadow: 2 }}>
//                 <CardContent>
//                   <Typography variant="h6" gutterBottom>Quick Stats</Typography>
//                   <Stack spacing={2} sx={{ mt: 2 }}>
//                       <Paper sx={{ p: 2, borderLeft: `5px solid ${THEME.primary}` }}>
//                           <Typography variant="caption" color="text.secondary">TOTAL OPERATORS</Typography>
//                           <Typography variant="h4">{operators.length}</Typography>
//                       </Paper>
//                       <Paper sx={{ p: 2, borderLeft: `5px solid ${COLORS[1]}` }}>
//                           <Typography variant="caption" color="text.secondary">COMPLETED</Typography>
//                           <Typography variant="h4">{inActionPCBs.filter((p) => p.isWorkAssigned).length}</Typography>
//                       </Paper>
//                       <Paper sx={{ p: 2, borderLeft: `5px solid ${COLORS[0]}` }}>
//                           <Typography variant="caption" color="text.secondary">PENDING</Typography>
//                           <Typography variant="h4">{inActionPCBs.filter((p) => !p.isWorkAssigned).length}</Typography>
//                       </Paper>
//                   </Stack>
//                 </CardContent>
//               </Card>
//             </Grid>
//           </Grid>
//         );

//       case "createOperator":
//         return (
//           <Grid container spacing={3}>
//             <Grid item xs={12} md={4}>
//                 <Card sx={{ borderRadius: 3, boxShadow: 2 }}>
//                     <CardContent>
//                         <Stack spacing={2}>
//                             <Typography variant="h6" sx={{ display:'flex', alignItems:'center', gap: 1 }}>
//                                 <PersonIcon color="primary"/> New Profile
//                             </Typography>
//                             <Divider />
//                             <TextField
//                                 label="Full Name"
//                                 size="small"
//                                 fullWidth
//                                 value={newOperator.name}
//                                 onChange={(e) => setNewOperator({ ...newOperator, name: e.target.value })}
//                             />
//                             <TextField
//                                 label="Email"
//                                 size="small"
//                                 fullWidth
//                                 value={newOperator.email}
//                                 onChange={(e) => setNewOperator({ ...newOperator, email: e.target.value })}
//                             />
//                             <TextField
//                                 label="Skill Set"
//                                 size="small"
//                                 fullWidth
//                                 value={newOperator.skill}
//                                 onChange={(e) => setNewOperator({ ...newOperator, skill: e.target.value })}
//                             />
//                             <Button 
//                                 variant="contained" 
//                                 onClick={handleAddOperator}
//                                 sx={{ bgcolor: THEME.primary, '&:hover': { bgcolor: '#334155' } }}
//                             >
//                                 Add Member
//                             </Button>
//                         </Stack>
//                     </CardContent>
//                 </Card>
//             </Grid>
//             <Grid item xs={12} md={8}>
//                 <Card sx={{ borderRadius: 3, boxShadow: 2, minHeight: 300 }}>
//                     <CardContent>
//                         <Typography variant="h6" gutterBottom>Team Roster</Typography>
//                         <Table size="small">
//                             <TableHead>
//                                 <TableRow>
//                                     <TableCell>Name</TableCell>
//                                     <TableCell>Skill</TableCell>
//                                 </TableRow>
//                             </TableHead>
//                             <TableBody>
//                                 {operators.map((op, i) => (
//                                     <TableRow key={i}>
//                                         <TableCell>
//                                             <Typography variant="body2" fontWeight="bold">{op.name}</Typography>
//                                             <Typography variant="caption" color="text.secondary">{op.email}</Typography>
//                                         </TableCell>
//                                         <TableCell>
//                                             <Chip label={op.skill} size="small" />
//                                         </TableCell>
//                                     </TableRow>
//                                 ))}
//                                 {operators.length === 0 && (
//                                   <TableRow>
//                                     <TableCell colSpan={2} align="center" sx={{ py: 3, color: 'text.secondary' }}>
//                                       No operators found.
//                                     </TableCell>
//                                   </TableRow>
//                                 )}
//                             </TableBody>
//                         </Table>
//                     </CardContent>
//                 </Card>
//             </Grid>
//           </Grid>
//         );

//       case "assignTask":
//         return renderAssignPCB();

//       case "corrections":
//         return (
//           <Box sx={{ p: 5, textAlign: 'center', bgcolor: 'white', borderRadius: 3, boxShadow: 1 }}>
//             <BuildIcon sx={{ fontSize: 80, color: 'text.disabled', mb: 2 }} />
//             <Typography variant="h5" color="text.secondary">Maintenance Mode</Typography>
//             <Typography sx={{ mt: 1 }}>
//               Correction tickets and maintenance requests will appear in this feed.
//             </Typography>
//           </Box>
//         );

//       default:
//         return null;
//     }
//   };

//   return (
//     <Box sx={{ minHeight: "100vh", bgcolor: THEME.bg }}>
      
//       {/* --- Top Header --- */}
//       <AppBar position="static" color="transparent" elevation={0} sx={{ bgcolor: "white", borderBottom: "1px solid #e2e8f0" }}>
//         <Toolbar>
//            {/* If not home, show Back button. If home, show Avatar/Logo */}
//            {currentView !== "home" ? (
//              <IconButton onClick={() => setCurrentView("home")} sx={{ mr: 2 }}>
//                 <ArrowBackIcon />
//              </IconButton>
//            ) : (
//             <Avatar sx={{ bgcolor: THEME.accent, color: "black", mr: 2, fontWeight: 'bold' }}>S</Avatar>
//            )}

//           <Typography variant="h6" sx={{ flexGrow: 1, color: THEME.primary, fontWeight: 'bold' }}>
//             {currentView === "home" ? "INTERNAL CONTROLS" : navCards.find(c => c.id === currentView)?.title.toUpperCase()}
//           </Typography>

//           <Button 
//             startIcon={<LogoutIcon />} 
//             color="error" 
//             onClick={onLogout}
//             sx={{ fontWeight: 'bold' }}
//           >
//             Logout
//           </Button>
//         </Toolbar>
//       </AppBar>

//       {/* --- Main Content Body --- */}
//       <Box sx={{ p: 3 }}>
//         {currentView === "home" ? (
//           renderHomeGrid()
//         ) : (
//           <Container maxWidth="xl" sx={{ animation: "fadeIn 0.3s" }}>
//              {/* We can add a simple breadcrumb or title here if needed */}
//              {renderModuleContent()}
//           </Container>
//         )}
//       </Box>

//       {/* Simple animation style */}
//       <style>
//         {`@keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }`}
//       </style>
//     </Box>
//   );
// };

// export default SupervisorInternal;


import React, { useState, useEffect } from "react"; // Import useEffect
import {
  Box,
  Button,
  TextField,
  Typography,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Paper,
  Grid,
  Card,
  CardContent,
  AppBar,
  Toolbar,
  Alert,
  Container,
  CardActionArea,
  Avatar,
  Stack,
  Divider,
  Chip,
  IconButton,
  CircularProgress, // Import for loading state
  Snackbar // Import for notifications
} from "@mui/material";

// Icons
import LogoutIcon from "@mui/icons-material/Logout";
import DashboardIcon from "@mui/icons-material/Dashboard";
import GroupAddIcon from "@mui/icons-material/GroupAdd";
import AssignmentIcon from "@mui/icons-material/Assignment";
import BuildIcon from "@mui/icons-material/Build";
import PersonIcon from "@mui/icons-material/Person";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import RefreshIcon from "@mui/icons-material/Refresh"; // Import Refresh
import FlowAssignment from "./FlowAssignment"; // Import the new file
import AccountTreeIcon from "@mui/icons-material/AccountTree"; // Icon for Flow Assignment

import { PieChart, Pie, Cell, Legend, Tooltip, ResponsiveContainer } from "recharts";

// --- Theme Colors ---
const THEME = {
  bg: "#f8fafc", 
  primary: "#1e293b", 
  accent: "#f59e0b", 
  cardBg: "#ffffff",
  textSecondary: "#64748b"
};

const SupervisorInternal = ({
  onLogout,
  // inActionPCBs = [], // You might not need this prop anymore if fetching internally
  handleAssignWork, // Assuming this is still a function passed from parent to handle the logic
}) => {
  const [currentView, setCurrentView] = useState("home");
  
  // --- New State for Database Fetching ---
  const [dbPCBs, setDbPCBs] = useState([]); // Stores the fetched PCBs
  const [isLoading, setIsLoading] = useState(false); // Loading state
  const [error, setError] = useState(null); // Error state
  // ---------------------------------------

  const [operators, setOperators] = useState([]);
  const [selectedPCB, setSelectedPCB] = useState(null);
  const [newOperator, setNewOperator] = useState({
    name: "",
    email: "",
    skill: "",
  });

  const COLORS = ["#6366f1", "#10b981"]; 

  // Derived data for charts (You might want to base this on dbPCBs now, or keep using props if Dashboard is global)
  const taskData = [
    { name: "Pending", value: dbPCBs.filter((p) => !p.isWorkAssigned).length },
    { name: "Assigned", value: dbPCBs.filter((p) => p.isWorkAssigned).length },
  ];
  // --- 1. The Fetch Function ---
  // const fetchPCBs = async () => {
  //   setIsLoading(true);
  //   setError(null);
  //   try {
  //     // REPLACE with your actual API endpoint
  //     // Example: GET http://localhost:5000/api/pcb/filter?status=inActive
  //     const response = await fetch("http://localhost:8081/api/pcb/filter")
      
  //     if (!response.ok) {
  //       throw new Error("Failed to fetch data from database");
  //     }

  //     const data = await response.json();
  //     setDbPCBs(data); // Store the fetched data
  //   } catch (err) {
  //     console.error("Error fetching PCBs:", err);
  //     // For demo purposes, if API fails, we might leave list empty or show error
  //     setError(err.message);
  //     setDbPCBs([]); 
  //   } finally {
  //     setIsLoading(false);
  //   }
  // };

  const fetchPCBs = async () => {
    setIsLoading(true);
    setError(null);
    try {
      // ADDED: ?status=inActive to the URL
      const response = await fetch("http://localhost:8081/api/pcb/filter?status=Inactive");
      
      if (!response.ok) {
        throw new Error("Failed to fetch data from database");
      }

      const data = await response.json();
      setDbPCBs(data); 
    } catch (err) {
      console.error("Error fetching PCBs:", err);
      setError(err.message);
      setDbPCBs([]); 
    } finally {
      setIsLoading(false);
    }
  };

  // --- 2. useEffect Hook ---
  // When user switches to "assignTask", fetch the data.
  useEffect(() => {
    if (currentView === "assignTask" || currentView === "dashboard") {
      fetchPCBs();
    }
  }, [currentView]);


  // --- Handlers ---
  const handleAddOperator = () => {
    if (!newOperator.name || !newOperator.email) return alert("Fill all details");
    setOperators([...operators, newOperator]);
    setNewOperator({ name: "", email: "", skill: "" });
  };

  const onAssignClick = async (serialNumber) => {
      if (window.confirm(`Assign work for PCB ${serialNumber}?`)) {
        // 1. Call the parent handler (database update logic)
        await handleAssignWork(serialNumber);
        
        // 2. Refresh the list to show updated status
        fetchPCBs();
      }
  };

  // --- Navigation Config ---
  // const navCards = [
  //   { 
  //     id: "dashboard", 
  //     title: "Overview Stats", 
  //     desc: "View charts and workload distribution",
  //     icon: <DashboardIcon sx={{ fontSize: 50, color: "#6366f1" }} />,
  //     color: "#e0e7ff"
  //   },
  //   { 
  //     id: "createOperator", 
  //     title: "Manage Operators", 
  //     desc: "Add new staff and view team roster",
  //     icon: <GroupAddIcon sx={{ fontSize: 50, color: "#10b981" }} />,
  //     color: "#d1fae5"
  //   },
  //   { 
  //     id: "assignTask", 
  //     title: "Assign Tasks", 
  //     desc: `Manage Active PCBs`,
  //     icon: <AssignmentIcon sx={{ fontSize: 50, color: "#f59e0b" }} />,
  //     color: "#fef3c7"
  //   },
  //   { 
  //     id: "corrections", 
  //     title: "Corrections", 
  //     desc: "Handle process correction tickets",
  //     icon: <BuildIcon sx={{ fontSize: 50, color: "#ef4444" }} />,
  //     color: "#fee2e2"
  //   },
  // ];


  const navCards = [
    { 
      id: "dashboard", 
      title: "Overview Stats", 
      desc: "View charts and workload distribution",
      icon: <DashboardIcon sx={{ fontSize: 50, color: "#6366f1" }} />,
      color: "#e0e7ff"
    },
    { 
      id: "createOperator", 
      title: "Manage Operators", 
      desc: "Add new staff and view team roster",
      icon: <GroupAddIcon sx={{ fontSize: 50, color: "#10b981" }} />,
      color: "#d1fae5"
    },
    { 
      id: "assignTask", 
      title: "Assign Tasks", 
      desc: `Manage Active PCBs`,
      icon: <AssignmentIcon sx={{ fontSize: 50, color: "#f59e0b" }} />,
      color: "#fef3c7"
    },
    // --- NEW TAB HERE ---
    { 
      id: "flowAssignment", 
      title: "Flow Assignment", 
      desc: "Create sequences & assign operators",
      icon: <AccountTreeIcon sx={{ fontSize: 50, color: "#8b5cf6" }} />, 
      color: "#ede9fe"
    },
    // --------------------
    { 
      id: "corrections", 
      title: "Corrections", 
      desc: "Handle process correction tickets",
      icon: <BuildIcon sx={{ fontSize: 50, color: "#ef4444" }} />,
      color: "#fee2e2"
    },
];

  /** ===========================
   * RENDER HELPERS
   * =========================== */

  const renderAssignPCB = () => {
    // A. Show Loading Spinner
    if (isLoading) {
        return (
            <Box sx={{ display: 'flex', justifyContent: 'center', p: 5 }}>
                <CircularProgress />
            </Box>
        );
    }

    // B. Show Error Message
    if (error) {
        return (
            <Alert severity="error" sx={{ mt: 2 }}>{error}</Alert>
        );
    }

    // C. Show Empty State
    if (dbPCBs.length === 0) {
      return (
        <Paper sx={{ p: 5, textAlign: "center", mt: 4, borderRadius: 3 }}>
          <Typography variant="h6" color="text.secondary">
            No PCBs found with status "inActive".
          </Typography>
          <Button startIcon={<RefreshIcon/>} onClick={fetchPCBs} sx={{mt:2}}>Refresh</Button>
        </Paper>
      );
    }

    const keyName = dbPCBs[0]?._pcb_key_id || "PCB Serial Number";
    // filtering out technical keys for the table display
    const baseColumns = Object.keys(dbPCBs[0]).filter(
      (k) => !["id", "linkedOperations", "isWorkAssigned", "_pcb_key_id", "_id", "__v"].includes(k)
    );

    return (
      <Box sx={{ maxWidth: "100%", mx: "auto" }}>
        
        {/* Header with Refresh Button */}
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Typography variant="h6">Available PCBs (inActive)</Typography>
            <Button startIcon={<RefreshIcon/>} size="small" onClick={fetchPCBs}>Refresh Data</Button>
        </Box>

        {selectedPCB && (
          <Alert severity="info" onClose={() => setSelectedPCB(null)} sx={{ mb: 3 }}>
            <strong>Selected:</strong> {selectedPCB[keyName]} — Operations Required:{" "}
            {selectedPCB.linkedOperations?.length}
          </Alert>
        )}

        <Paper sx={{ width: "100%", overflow: "hidden", borderRadius: 3, boxShadow: 2 }}>
          <Table stickyHeader>
            <TableHead>
              <TableRow>
                {baseColumns.map((col) => (
                  <TableCell key={col} sx={{ fontWeight: "bold", bgcolor: "#f1f5f9" }}>
                    {col.toUpperCase()}
                  </TableCell>
                ))}
                <TableCell sx={{ fontWeight: "bold", bgcolor: "#f1f5f9" }}>STATUS</TableCell>
                <TableCell sx={{ fontWeight: "bold", bgcolor: "#f1f5f9" }}>ACTION</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {dbPCBs.map((pcb, i) => {
                const serialNumber = pcb[keyName] || pcb.serialNumber || "N/A"; // Fallback for key
                return (
                  <TableRow hover key={i}>
                    {baseColumns.map((col) => (
                      <TableCell key={col}>
                        {col === keyName ? (
                          <Button
                            size="small"
                            onClick={() => setSelectedPCB(pcb)}
                            sx={{ textTransform: "none", fontWeight: "bold" }}
                          >
                            {serialNumber}
                          </Button>
                        ) : (
                          pcb[col]
                        )}
                      </TableCell>
                    ))}
                    <TableCell>
                      <Chip 
                        label={pcb.isWorkAssigned ? "ASSIGNED" : "PENDING"} 
                        color={pcb.isWorkAssigned ? "success" : "warning"}
                        size="small"
                        variant="filled"
                      />
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="contained"
                        size="small"
                        disableElevation
                        disabled={pcb.isWorkAssigned}
                        onClick={() => onAssignClick(serialNumber)}
                        sx={{ borderRadius: 2 }}
                      >
                        {pcb.isWorkAssigned ? "Done" : "Assign"}
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </Paper>
      </Box>
    );
  };

  // --- Views ---

  // 1. The "Home" Grid View
  const renderHomeGrid = () => (
    <Container maxWidth="lg" sx={{ mt: 4 }}>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" fontWeight="800" color="text.primary">
          Welcome, Supervisor
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Select a module to begin managing operations.
        </Typography>
      </Box>

      <Grid container spacing={4}>
        {navCards.map((card) => (
          <Grid item xs={12} sm={6} md={3} key={card.id}>
            <Card 
              sx={{ 
                height: "100%", 
                borderRadius: 4, 
                boxShadow: 3,
                transition: "transform 0.2s",
                "&:hover": { transform: "translateY(-5px)", boxShadow: 6 }
              }}
            >
              <CardActionArea 
                sx={{ height: "100%", p: 3, display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}
                onClick={() => setCurrentView(card.id)}
              >
                <Box sx={{ 
                  p: 2, 
                  borderRadius: "50%", 
                  bgcolor: card.color, 
                  mb: 2,
                  display: 'flex', alignItems: 'center', justifyContent: 'center'
                }}>
                  {card.icon}
                </Box>
                <Typography variant="h6" fontWeight="bold" gutterBottom>
                  {card.title}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {card.desc}
                </Typography>
              </CardActionArea>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  );

  // 2. The Inner Module View
  const renderModuleContent = () => {
    switch (currentView) {
      case "dashboard":
        return (
          <Grid container spacing={3}>
            <Grid item xs={12} md={7}>
              <Card sx={{ height: "100%", borderRadius: 3, boxShadow: 2 }}>
                <CardContent>
                  <Typography variant="h6" gutterBottom>Workload Distribution (Fetched Data)</Typography>
                  <Box sx={{ height: 300, width: '100%' }}>
                      <ResponsiveContainer>
                          <PieChart>
                          <Pie
                              data={taskData}
                              cx="50%"
                              cy="50%"
                              innerRadius={60}
                              outerRadius={80}
                              paddingAngle={5}
                              dataKey="value"
                          >
                              {taskData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                          </Pie>
                          <Tooltip />
                          <Legend verticalAlign="bottom" height={36}/>
                          </PieChart>
                      </ResponsiveContainer>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={5}>
              <Card sx={{ height: "100%", borderRadius: 3, boxShadow: 2 }}>
                <CardContent>
                  <Typography variant="h6" gutterBottom>Quick Stats</Typography>
                  <Stack spacing={2} sx={{ mt: 2 }}>
                      <Paper sx={{ p: 2, borderLeft: `5px solid ${THEME.primary}` }}>
                          <Typography variant="caption" color="text.secondary">TOTAL OPERATORS</Typography>
                          <Typography variant="h4">{operators.length}</Typography>
                      </Paper>
                      <Paper sx={{ p: 2, borderLeft: `5px solid ${COLORS[1]}` }}>
                          <Typography variant="caption" color="text.secondary">COMPLETED / ASSIGNED</Typography>
                          <Typography variant="h4">{dbPCBs.filter((p) => p.isWorkAssigned).length}</Typography>
                      </Paper>
                      <Paper sx={{ p: 2, borderLeft: `5px solid ${COLORS[0]}` }}>
                          <Typography variant="caption" color="text.secondary">PENDING</Typography>
                          <Typography variant="h4">{dbPCBs.filter((p) => !p.isWorkAssigned).length}</Typography>
                      </Paper>
                  </Stack>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        );
      case "flowAssignment":
        return <FlowAssignment />;
      case "createOperator":
        return (
          <Grid container spacing={3}>
            <Grid item xs={12} md={4}>
                <Card sx={{ borderRadius: 3, boxShadow: 2 }}>
                    <CardContent>
                        <Stack spacing={2}>
                            <Typography variant="h6" sx={{ display:'flex', alignItems:'center', gap: 1 }}>
                                <PersonIcon color="primary"/> New Profile
                            </Typography>
                            <Divider />
                            <TextField
                                label="Full Name"
                                size="small"
                                fullWidth
                                value={newOperator.name}
                                onChange={(e) => setNewOperator({ ...newOperator, name: e.target.value })}
                            />
                            <TextField
                                label="Email"
                                size="small"
                                fullWidth
                                value={newOperator.email}
                                onChange={(e) => setNewOperator({ ...newOperator, email: e.target.value })}
                            />
                            <TextField
                                label="Skill Set"
                                size="small"
                                fullWidth
                                value={newOperator.skill}
                                onChange={(e) => setNewOperator({ ...newOperator, skill: e.target.value })}
                            />
                            <Button 
                                variant="contained" 
                                onClick={handleAddOperator}
                                sx={{ bgcolor: THEME.primary, '&:hover': { bgcolor: '#334155' } }}
                            >
                                Add Member
                            </Button>
                        </Stack>
                    </CardContent>
                </Card>
            </Grid>
            <Grid item xs={12} md={8}>
                <Card sx={{ borderRadius: 3, boxShadow: 2, minHeight: 300 }}>
                    <CardContent>
                        <Typography variant="h6" gutterBottom>Team Roster</Typography>
                        <Table size="small">
                            <TableHead>
                                <TableRow>
                                    <TableCell>Name</TableCell>
                                    <TableCell>Skill</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {operators.map((op, i) => (
                                    <TableRow key={i}>
                                        <TableCell>
                                            <Typography variant="body2" fontWeight="bold">{op.name}</Typography>
                                            <Typography variant="caption" color="text.secondary">{op.email}</Typography>
                                        </TableCell>
                                        <TableCell>
                                            <Chip label={op.skill} size="small" />
                                        </TableCell>
                                    </TableRow>
                                ))}
                                {operators.length === 0 && (
                                  <TableRow>
                                    <TableCell colSpan={2} align="center" sx={{ py: 3, color: 'text.secondary' }}>
                                      No operators found.
                                    </TableCell>
                                  </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            </Grid>
          </Grid>
        );

      case "assignTask":
        return renderAssignPCB();

      case "corrections":
        return (
          <Box sx={{ p: 5, textAlign: 'center', bgcolor: 'white', borderRadius: 3, boxShadow: 1 }}>
            <BuildIcon sx={{ fontSize: 80, color: 'text.disabled', mb: 2 }} />
            <Typography variant="h5" color="text.secondary">Maintenance Mode</Typography>
            <Typography sx={{ mt: 1 }}>
              Correction tickets and maintenance requests will appear in this feed.
            </Typography>
          </Box>
        );

      default:
        return null;
    }
  };

  return (
    <Box sx={{ minHeight: "100vh", bgcolor: THEME.bg }}>
      
      {/* --- Top Header --- */}
      <AppBar position="static" color="transparent" elevation={0} sx={{ bgcolor: "white", borderBottom: "1px solid #e2e8f0" }}>
        <Toolbar>
           {/* If not home, show Back button. If home, show Avatar/Logo */}
           {currentView !== "home" ? (
             <IconButton onClick={() => setCurrentView("home")} sx={{ mr: 2 }}>
                <ArrowBackIcon />
             </IconButton>
           ) : (
            <Avatar sx={{ bgcolor: THEME.accent, color: "black", mr: 2, fontWeight: 'bold' }}>S</Avatar>
           )}

          <Typography variant="h6" sx={{ flexGrow: 1, color: THEME.primary, fontWeight: 'bold' }}>
            {currentView === "home" ? "INTERNAL CONTROLS" : navCards.find(c => c.id === currentView)?.title.toUpperCase()}
          </Typography>

          <Button 
            startIcon={<LogoutIcon />} 
            color="error" 
            onClick={onLogout}
            sx={{ fontWeight: 'bold' }}
          >
            Logout
          </Button>
        </Toolbar>
      </AppBar>

      {/* --- Main Content Body --- */}
      <Box sx={{ p: 3 }}>
        {currentView === "home" ? (
          renderHomeGrid()
        ) : (
          <Container maxWidth="xl" sx={{ animation: "fadeIn 0.3s" }}>
             {renderModuleContent()}
          </Container>
        )}
      </Box>

      {/* Simple animation style */}
      <style>
        {`@keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }`}
      </style>
    </Box>
  );
};

export default SupervisorInternal;