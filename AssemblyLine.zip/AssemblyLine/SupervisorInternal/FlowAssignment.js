// import React, { useState, useEffect } from "react";
// import {
//   Box,
//   Button,
//   TextField,
//   Typography,
//   Paper,
//   Grid,
//   Stack,
//   MenuItem,
//   Select,
//   FormControl,
//   InputLabel,
//   List,
//   ListItem,
//   ListItemText,
//   IconButton,
//   Chip,
//   Alert,
//   Divider
// } from "@mui/material";

// import AddCircleIcon from "@mui/icons-material/AddCircle";
// import DeleteIcon from "@mui/icons-material/Delete";
// import SaveIcon from "@mui/icons-material/Save";
// import PersonIcon from "@mui/icons-material/Person";
// import SettingsSuggestIcon from "@mui/icons-material/SettingsSuggest";

// // Mock Service (Replace with your actual API calls)
// const apiService = {
//   // Fetch your 40 operations from DB
//   getOperations: async () => {
//     const response = await fetch("http://localhost:8081/api/operations"); // Update port/route
//     if (!response.ok) throw new Error("Failed to fetch operations");
//     return await response.json(); 
//   },
//   // Fetch operators from DB
//   getOperators: async () => {
//     const response = await fetch("http://localhost:8081/api/operators"); // Update port/route
//     if (!response.ok) throw new Error("Failed to fetch operators");
//     return await response.json();
//   }
// };

// const FlowAssignment = () => {
//   // --- State ---
//   const [operationsList, setOperationsList] = useState([]);
//   const [operatorList, setOperatorList] = useState([]);
  
//   // Builder State
//   const [flowName, setFlowName] = useState("");
//   const [selectedOp, setSelectedOp] = useState(""); // ID of selected operation
//   const [selectedStaff, setSelectedStaff] = useState(""); // ID of selected operator
//   const [currentSteps, setCurrentSteps] = useState([]); // The sequence being built

//   // --- Load Data on Mount ---
//   useEffect(() => {
//     const loadData = async () => {
//       try {
//         // 1. Fetch Operations
//         // If you don't have an endpoint yet, use this mock data for testing:
//         // const mockOps = Array.from({ length: 40 }, (_, i) => ({ id: i + 1, name: `Operation ${i + 1}` }));
//         const ops = await apiService.getOperations(); 
//         setOperationsList(ops);

//         // 2. Fetch Operators
//         const staff = await apiService.getOperators();
//         setOperatorList(staff);
//       } catch (err) {
//         console.error("Error loading data:", err);
//       }
//     };
//     loadData();
//   }, []);

//   // --- Handlers ---

//   const handleAddStep = () => {
//     if (!selectedOp || !selectedStaff) {
//       alert("Please select both an Operation and an Operator.");
//       return;
//     }

//     const opDetails = operationsList.find(o => o.id === selectedOp) || {};
//     const staffDetails = operatorList.find(s => s.id === selectedStaff) || {};

//     const newStep = {
//       stepId: Date.now(),
//       opId: selectedOp,
//       opName: opDetails.name || `Op #${selectedOp}`,
//       operatorId: selectedStaff,
//       operatorName: staffDetails.name || "Unknown Staff"
//     };

//     setCurrentSteps([...currentSteps, newStep]);
    
//     // Reset selections for next step
//     setSelectedOp("");
//     setSelectedStaff("");
//   };

//   const handleDeleteStep = (index) => {
//     const newSteps = [...currentSteps];
//     newSteps.splice(index, 1);
//     setCurrentSteps(newSteps);
//   };

//   const handleSaveFlow = async () => {
//     if (!flowName || currentSteps.length === 0) return alert("Please enter a Flow Name and add at least one step.");

//     const payload = {
//       name: flowName,
//       steps: currentSteps
//     };

//     try {
//       // Replace with your actual SAVE endpoint
//       // await fetch("http://localhost:8081/api/flows/create", { 
//       //   method: 'POST', 
//       //   headers: {'Content-Type': 'application/json'},
//       //   body: JSON.stringify(payload)
//       // });
      
//       console.log("Saving Flow:", payload);
//       alert("Flow Saved Successfully!");
      
//       // Reset
//       setFlowName("");
//       setCurrentSteps([]);
//     } catch (err) {
//       console.error(err);
//       alert("Failed to save flow");
//     }
//   };

//   return (
//     <Grid container spacing={3}>
//       {/* LEFT: Builder Form */}
//       <Grid item xs={12} md={5}>
//         <Paper sx={{ p: 3, borderRadius: 3 }}>
//           <Typography variant="h6" gutterBottom display="flex" alignItems="center" gap={1}>
//             <SettingsSuggestIcon color="primary" /> Build Process Flow
//           </Typography>
//           <Divider sx={{ mb: 3 }} />

//           {/* Flow Name */}
//           <TextField
//             fullWidth
//             label="Flow / Process Name"
//             placeholder="e.g., Standard PCB Assembly A"
//             value={flowName}
//             onChange={(e) => setFlowName(e.target.value)}
//             sx={{ mb: 3 }}
//           />

//           {/* Step Builder */}
//           <Box sx={{ p: 2, bgcolor: "#f8fafc", borderRadius: 2, border: "1px dashed #cbd5e1" }}>
//             <Typography variant="subtitle2" gutterBottom color="text.secondary">Add Sequence Step</Typography>
            
//             {/* 1. Operation Dropdown */}
//             <FormControl fullWidth size="small" sx={{ mb: 2 }}>
//               <InputLabel>Select Operation (1-40)</InputLabel>
//               <Select
//                 value={selectedOp}
//                 label="Select Operation (1-40)"
//                 onChange={(e) => setSelectedOp(e.target.value)}
//               >
//                 {operationsList.map((op) => (
//                   <MenuItem key={op.id} value={op.id}>
//                     {op.name}
//                   </MenuItem>
//                 ))}
//                 {operationsList.length === 0 && <MenuItem disabled>Loading Operations...</MenuItem>}
//               </Select>
//             </FormControl>

//             {/* 2. Operator Dropdown */}
//             <FormControl fullWidth size="small" sx={{ mb: 2 }}>
//               <InputLabel>Assign Operator</InputLabel>
//               <Select
//                 value={selectedStaff}
//                 label="Assign Operator"
//                 onChange={(e) => setSelectedStaff(e.target.value)}
//               >
//                 {operatorList.map((op) => (
//                   <MenuItem key={op.id} value={op.id}>
//                     {op.name} ({op.skill || "General"})
//                   </MenuItem>
//                 ))}
//               </Select>
//             </FormControl>

//             <Button 
//               fullWidth 
//               variant="contained" 
//               startIcon={<AddCircleIcon />}
//               onClick={handleAddStep}
//               disabled={!selectedOp || !selectedStaff}
//             >
//               Add to Sequence
//             </Button>
//           </Box>
//         </Paper>
//       </Grid>

//       {/* RIGHT: Preview List */}
//       <Grid item xs={12} md={7}>
//         <Paper sx={{ p: 3, borderRadius: 3, minHeight: "400px" }}>
//           <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2}>
//             <Typography variant="h6">Sequence Preview</Typography>
//             <Chip label={`${currentSteps.length} Steps`} color="primary" size="small" />
//           </Stack>
          
//           {currentSteps.length === 0 ? (
//             <Alert severity="info">No steps added yet. Use the form on the left to build the flow.</Alert>
//           ) : (
//             <List>
//               {currentSteps.map((step, index) => (
//                 <ListItem 
//                   key={step.stepId} 
//                   sx={{ 
//                     mb: 1, 
//                     bgcolor: "white", 
//                     border: "1px solid #e2e8f0", 
//                     borderRadius: 2,
//                     boxShadow: "0 2px 4px rgba(0,0,0,0.02)"
//                   }}
//                   secondaryAction={
//                     <IconButton edge="end" color="error" onClick={() => handleDeleteStep(index)}>
//                       <DeleteIcon />
//                     </IconButton>
//                   }
//                 >
//                   <Box sx={{ mr: 2, bgcolor: "#e0e7ff", color: "#4338ca", width: 30, height: 30, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: "bold" }}>
//                     {index + 1}
//                   </Box>
//                   <ListItemText
//                     primary={
//                       <Typography variant="subtitle1" fontWeight="bold">
//                         {step.opName}
//                       </Typography>
//                     }
//                     secondary={
//                       <Stack direction="row" alignItems="center" spacing={1} mt={0.5}>
//                         <PersonIcon sx={{ fontSize: 16, color: "text.secondary" }} />
//                         <Typography variant="body2" color="text.secondary">
//                           {step.operatorName}
//                         </Typography>
//                       </Stack>
//                     }
//                   />
//                 </ListItem>
//               ))}
//             </List>
//           )}

//           {currentSteps.length > 0 && (
//             <Box sx={{ mt: 3, textAlign: 'right' }}>
//                <Button 
//                 variant="contained" 
//                 color="success" 
//                 size="large" 
//                 startIcon={<SaveIcon />}
//                 onClick={handleSaveFlow}
//               >
//                 Save Master Flow
//               </Button>
//             </Box>
//           )}
//         </Paper>
//       </Grid>
//     </Grid>
//   );
// };

// export default FlowAssignment;

import React, { useState, useEffect } from "react";
import {
  Box,
  Button,
  TextField,
  Typography,
  Paper,
  Grid,
  Stack,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
  List,
  ListItem,
  ListItemText,
  IconButton,
  Chip,
  Alert,
  Divider,
  CircularProgress
} from "@mui/material";

import AddCircleIcon from "@mui/icons-material/AddCircle";
import DeleteIcon from "@mui/icons-material/Delete";
import SaveIcon from "@mui/icons-material/Save";
import PersonIcon from "@mui/icons-material/Person";
import SettingsSuggestIcon from "@mui/icons-material/SettingsSuggest";

// --- 1. YOUR HARDCODED OPERATIONS LIST ---
const DEFAULT_OPERATIONS_LIST = [
  { "S.No": "1", "Operation Name": "Labelling & Traceability of the Bare PCB" },
  { "S.No": "2", "Operation Name": "Cleaning of Bare PCB" },
  { "S.No": "3", "Operation Name": "Baking of Bare PCB" },
  { "S.No": "4", "Operation Name": "Solder Paste Printing - Top Side" },
  { "S.No": "5", "Operation Name": "Solder Paste Inspection - Top Side" },
  { "S.No": "6", "Operation Name": "Pick n Place - Top side" },
  { "S.No": "7", "Operation Name": "Reflow-Top side" },
  { "S.No": "8", "Operation Name": "Application of Amicon D" },
  { "S.No": "9", "Operation Name": "Solder Paste Printing-BOTTOM side" },
  { "S.No": "10", "Operation Name": "Solder Paste Inspection-BOTTOM side" },
  { "S.No": "11", "Operation Name": "Pick n Place-BOTTOM side" },
  { "S.No": "12", "Operation Name": "Reflow-BOTTOM side" },
  { "S.No": "13", "Operation Name": "Traceability of BGA & Circulator" },
  { "S.No": "14", "Operation Name": "Cleaning of PCBA" },
  { "S.No": "15", "Operation Name": "AOI Inspection" },
  { "S.No": "16", "Operation Name": "X-ray Inspection" },
  { "S.No": "17", "Operation Name": "Endoscope Inspection" },
  { "S.No": "18", "Operation Name": "Visual Inspection" },
  { "S.No": "19", "Operation Name": "AOI correction" },
  { "S.No": "20", "Operation Name": "Cleaning of PCBA" },
  { "S.No": "21", "Operation Name": "Visual Inspection After Rework" },
  { "S.No": "22", "Operation Name": "HSTT" },
  { "S.No": "23", "Operation Name": "Fly Probe Test (FPT)" },
  { "S.No": "24", "Operation Name": "Connector Assembly" },
  { "S.No": "25", "Operation Name": "X-ray of via fill" },
  { "S.No": "26", "Operation Name": "Cleaning After Connector Assembly" },
  { "S.No": "27", "Operation Name": "Contamination Check" },
  { "S.No": "28", "Operation Name": "Conformal Coating" },
  { "S.No": "29", "Operation Name": "Parallel Gap welding" },
  { "S.No": "30", "Operation Name": "Intermediate Control" },
  { "S.No": "31", "Operation Name": "Scotch weld Gluing" },
  { "S.No": "32", "Operation Name": "HASS" },
  { "S.No": "33", "Operation Name": "ATE1" },
  { "S.No": "34", "Operation Name": "ATE2" },
  { "S.No": "35", "Operation Name": "EMI shield mounting" },
  { "S.No": "36", "Operation Name": "Final Control" },
  { "S.No": "37", "Operation Name": "Clearance Control" }
];

const FlowAssignment = () => {
  // --- State ---
  const [operatorList, setOperatorList] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  
  // Builder State
  const [flowName, setFlowName] = useState("");
  const [selectedOpSno, setSelectedOpSno] = useState(""); // Selected Operation ID
  const [selectedStaffId, setSelectedStaffId] = useState(""); // Selected Operator ID
  const [currentSteps, setCurrentSteps] = useState([]); // The sequence being built

  // --- 2. Fetch Operators from Database ---
  useEffect(() => {
    const fetchOperators = async () => {
      setIsLoading(true);
      try {
        // Retrieve Token from LocalStorage (Assuming you store it as 'user' object)
        const userStr = localStorage.getItem("user");
        let token = "";
        if (userStr) {
            const userObj = JSON.parse(userStr);
            token = userObj.accessToken || userObj.token; // Adjust based on how you save it
        }

        const response = await fetch("http://localhost:8081/users", {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "x-access-token": token // REQUIRED by your authJwt middleware
            }
        });

        if (!response.ok) throw new Error("Failed to fetch operators");
        
        const data = await response.json();
        // Assuming your API returns { users: [...] } or just [...]
        // Adjust 'data' or 'data.users' based on your exact controller response
        setOperatorList(Array.isArray(data) ? data : (data.users || []));

      } catch (err) {
        console.error("Error loading operators:", err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchOperators();
  }, []);

  // --- Handlers ---

  const handleAddStep = () => {
    if (!selectedOpSno || !selectedStaffId) {
      alert("Please select both an Operation and an Operator.");
      return;
    }

    // Find full objects based on IDs
    const opDetails = DEFAULT_OPERATIONS_LIST.find(o => o["S.No"] === selectedOpSno);
    const staffDetails = operatorList.find(s => s.id === selectedStaffId || s._id === selectedStaffId);

    const newStep = {
      stepId: Date.now(),
      opId: selectedOpSno,
      opName: opDetails ? opDetails["Operation Name"] : "Unknown",
      operatorId: selectedStaffId,
      operatorName: staffDetails ? (staffDetails.username || staffDetails.name) : "Unknown Staff"
    };

    setCurrentSteps([...currentSteps, newStep]);
    
    // Reset selections for next step
    setSelectedOpSno("");
    setSelectedStaffId("");
  };

  const handleDeleteStep = (index) => {
    const newSteps = [...currentSteps];
    newSteps.splice(index, 1);
    setCurrentSteps(newSteps);
  };

  const handleSaveFlow = async () => {
    if (!flowName || currentSteps.length === 0) return alert("Please enter a Flow Name and add at least one step.");

    const payload = {
      name: flowName,
      steps: currentSteps
    };

    console.log("Saving Flow Payload:", payload);
    // TODO: Add your API call here to save the flow to a new 'Flows' table
    alert("Flow sequence ready to be saved! (Check console for payload)");
    
    // Reset
    setFlowName("");
    setCurrentSteps([]);
  };

  return (
    <Grid container spacing={3}>
      {/* LEFT: Builder Form */}
      <Grid item xs={12} md={5}>
        <Paper sx={{ p: 3, borderRadius: 3 }}>
          <Typography variant="h6" gutterBottom display="flex" alignItems="center" gap={1}>
            <SettingsSuggestIcon color="primary" /> Build Process Flow
          </Typography>
          <Divider sx={{ mb: 3 }} />

          {/* Flow Name */}
          <TextField
            fullWidth
            label="Flow / Process Name"
            placeholder="e.g., Night Shift Standard Flow"
            value={flowName}
            onChange={(e) => setFlowName(e.target.value)}
            sx={{ mb: 3 }}
          />

          {/* Step Builder */}
          <Box sx={{ p: 2, bgcolor: "#f8fafc", borderRadius: 2, border: "1px dashed #cbd5e1" }}>
            <Typography variant="subtitle2" gutterBottom color="text.secondary">Add Sequence Step</Typography>
            
            {/* 1. Operation Dropdown (From JSON) */}
            <FormControl fullWidth size="small" sx={{ mb: 2 }}>
              <InputLabel>Select Operation</InputLabel>
              <Select
                value={selectedOpSno}
                label="Select Operation"
                onChange={(e) => setSelectedOpSno(e.target.value)}
              >
                {DEFAULT_OPERATIONS_LIST.map((op) => (
                  <MenuItem key={op["S.No"]} value={op["S.No"]}>
                    {op["S.No"]}. {op["Operation Name"]}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            {/* 2. Operator Dropdown (From Database) */}
            <FormControl fullWidth size="small" sx={{ mb: 2 }}>
              <InputLabel>Assign Operator</InputLabel>
              <Select
                value={selectedStaffId}
                label="Assign Operator"
                onChange={(e) => setSelectedStaffId(e.target.value)}
                disabled={isLoading}
              >
                {isLoading ? (
                    <MenuItem disabled><CircularProgress size={20} /></MenuItem>
                ) : (
                    operatorList.map((user) => (
                    <MenuItem key={user.id || user._id} value={user.id || user._id}>
                        {user.username || user.name} ({user.role || "Operator"})
                    </MenuItem>
                    ))
                )}
              </Select>
            </FormControl>

            <Button 
              fullWidth 
              variant="contained" 
              startIcon={<AddCircleIcon />}
              onClick={handleAddStep}
              disabled={!selectedOpSno || !selectedStaffId}
            >
              Add to Sequence
            </Button>
          </Box>
        </Paper>
      </Grid>

      {/* RIGHT: Preview List */}
      <Grid item xs={12} md={7}>
        <Paper sx={{ p: 3, borderRadius: 3, minHeight: "400px" }}>
          <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2}>
            <Typography variant="h6">Sequence Preview</Typography>
            <Chip label={`${currentSteps.length} Steps`} color="primary" size="small" />
          </Stack>
          
          {currentSteps.length === 0 ? (
            <Alert severity="info">No steps added yet. Use the form on the left to build the flow.</Alert>
          ) : (
            <List>
              {currentSteps.map((step, index) => (
                <ListItem 
                  key={step.stepId} 
                  sx={{ 
                    mb: 1, 
                    bgcolor: "white", 
                    border: "1px solid #e2e8f0", 
                    borderRadius: 2,
                    boxShadow: "0 2px 4px rgba(0,0,0,0.02)"
                  }}
                  secondaryAction={
                    <IconButton edge="end" color="error" onClick={() => handleDeleteStep(index)}>
                      <DeleteIcon />
                    </IconButton>
                  }
                >
                  <Box sx={{ mr: 2, bgcolor: "#e0e7ff", color: "#4338ca", width: 30, height: 30, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: "bold" }}>
                    {index + 1}
                  </Box>
                  <ListItemText
                    primary={
                      <Typography variant="subtitle1" fontWeight="bold">
                        {step.opName}
                      </Typography>
                    }
                    secondary={
                      <Stack direction="row" alignItems="center" spacing={1} mt={0.5}>
                        <PersonIcon sx={{ fontSize: 16, color: "text.secondary" }} />
                        <Typography variant="body2" color="text.secondary">
                          Assigned to: <b>{step.operatorName}</b>
                        </Typography>
                      </Stack>
                    }
                  />
                </ListItem>
              ))}
            </List>
          )}

          {currentSteps.length > 0 && (
            <Box sx={{ mt: 3, textAlign: 'right' }}>
               <Button 
                variant="contained" 
                color="success" 
                size="large" 
                startIcon={<SaveIcon />}
                onClick={handleSaveFlow}
              >
                Save Master Flow
              </Button>
            </Box>
          )}
        </Paper>
      </Grid>
    </Grid>
  );
};

export default FlowAssignment;