
// import React, { useState, useEffect } from "react";
// import * as XLSX from "xlsx";
// import {
//   Box,
//   Card,
//   CardContent,
//   Typography,
//   Button,
//   Table,
//   TableHead,
//   TableRow,
//   TableCell,
//   TableBody,
//   TextField,
//   Checkbox,
//   Snackbar,
//   Alert,
//   Tabs,
//   Tab,
//   Paper,
//   TableContainer,
//   Stack,
//   Divider,
//   Chip,
//   useTheme
// } from "@mui/material";

// // Icons
// import UploadFileIcon from "@mui/icons-material/UploadFile";
// import AddIcon from "@mui/icons-material/Add";
// import DeleteIcon from "@mui/icons-material/Delete";
// import ReplayIcon from "@mui/icons-material/Replay";
// import CloudUploadIcon from '@mui/icons-material/CloudUpload';
// import StorageIcon from '@mui/icons-material/Storage';
// import BlockIcon from '@mui/icons-material/Block';
// import SaveIcon from '@mui/icons-material/Save';
// import AssignmentReturnIcon from '@mui/icons-material/AssignmentReturn';

// import axios from "axios";

// export default function AddProject() {
//   const theme = useTheme();
  
//   // ==================================================
//   // STATE & LOGIC (UNCHANGED)
//   // ==================================================
//   const [tab, setTab] = useState("upload");
//   const [previewRows, setPreviewRows] = useState([]);
//   const [masterList, setMasterList] = useState([]);
//   const [inactiveList, setInactiveList] = useState([]);
//   const [columns, setColumns] = useState([]);
//   const [serialColumn, setSerialColumn] = useState(""); 
//   const [fileName, setFileName] = useState("");
//   const [alert, setAlert] = useState({ open: false, msg: "", type: "error" });

//   useEffect(() => {
//     axios
//       .get("http://localhost:5000/api/masterlist")
//       .then((res) => {
//         if (res.data?.length > 0) {
//           setMasterList(res.data);
//         }
//       })
//       .catch(() => {});
//   }, []);

//   useEffect(() => {
//     console.log("inactiveList", inactiveList);
//     if (inactiveList.length > 0)
//       localStorage.setItem('inactiveList', JSON.stringify(inactiveList));
//   }, [inactiveList]);

//   const handleFileUpload = (e) => {
//     const file = e.target.files[0];
//     if (!file) return;

//     setFileName(file.name);

//     const reader = new FileReader();
//     reader.onload = (evt) => {
//       const buffer = new Uint8Array(evt.target.result);
//       const wb = XLSX.read(buffer, { type: "array" });
//       const ws = wb.Sheets[wb.SheetNames[0]];

//       let json = XLSX.utils.sheet_to_json(ws);

//       if (json.length === 0) {
//         showAlert("Excel file is empty!", "error");
//         return;
//       }

//       const cols = Object.keys(json[0]);
//       setColumns(cols);

//       const serialCol = cols.find(
//         (c) => c.toLowerCase().replace(/\s+/g, "") === "serialnumber"
//       );
//       setSerialColumn(serialCol);

//       const rows = json.map((row, i) => ({
//         id: Date.now() + "-" + i,
//         ...row,
//       }));

//       setPreviewRows(rows);
//       setTab("preview");
//     };

//     reader.readAsArrayBuffer(file);
//   };

//   const addRow = () => {
//     const newRow = { id: Date.now() };
//     columns.forEach((c) => (newRow[c] = ""));
//     setPreviewRows((p) => [...p, newRow]);
//   };

//   const deleteRow = (id) => {
//     setPreviewRows((p) => p.filter((row) => row.id !== id));
//   };

//   const updateCell = (id, key, value) => {
//     setPreviewRows((p) =>
//       p.map((row) => (row.id === id ? { ...row, [key]: value } : row))
//     );
//   };



// const saveToMaster = () => {
//     // 1. Logic to filter duplicates (UI Logic)
//     let existingSerials = new Set(
//       masterList.map((r) => (serialColumn ? r[serialColumn] : null))
//     );

//     let uniqueRows = [];
//     let duplicates = [];

//     previewRows.forEach((r) => {
//       const serialValue = serialColumn ? r[serialColumn] : null;
//       if (serialColumn && (!serialValue || existingSerials.has(serialValue))) {
//         duplicates.push(serialValue);
//       } else {
//         uniqueRows.push({ ...r, status: "Not Assigned" });
//       }
//     });

//     if (duplicates.length > 0) {
//       showAlert(`Skipped ${duplicates.length} duplicate serial numbers.`, "warning");
//     }

//     // Update UI
//     const finalList = [...masterList, ...uniqueRows];
//     setMasterList(finalList);

//     // -------------------------------------------------------------
//     // 2. PREPARE PAYLOAD (The Robust Fix)
//     // -------------------------------------------------------------
    
//     const backendPayload = uniqueRows.map((row) => {
//       // Helper: Find a value by checking multiple common header names
//       const findValue = (possibleHeaders) => {
//         const keys = Object.keys(row);
//         // Try to find a key that matches one of our possible headers
//         const match = keys.find(k => {
//           const cleanKey = k.toLowerCase().replace(/[^a-z0-9]/g, ""); // Remove spaces, dots, symbols
//           return possibleHeaders.some(h => cleanKey === h);
//         });
//         return match ? row[match] : null;
//       };

//       return {
//         // Backend 'sno': Look for "sno", "no", "id"
//         //sno: parseInt(findValue(["sno", "no", "id", "index"]) || 0, 10),
//         sno: parseInt(findValue(["sno", "no", "index", "serialindex"]) || 0, 10),

//         // Backend 'partNumber': Look for "partnumber", "partno", "pno", "model"
//         partNumber: findValue(["partnumber", "partno", "pno", "model"]) || "UNKNOWN",

//         // Backend 'serialNo': Look for "serialno", "serialnumber", "sno", "serial"
//         // Priority: Use the column we detected earlier (serialColumn), otherwise search
//         serialNo: row[serialColumn] || findValue(["serialno", "serialnumber", "serial", "snumber"])

        
//       };
//     });

//     // -------------------------------------------------------------
//     // 3. DEBUGGING (Check your Browser Console F12)
//     // -------------------------------------------------------------
//     const validPayload = backendPayload.filter(item => item.serialNo);
    
//     console.log("--- DEBUG PAYLOAD ---");
//     console.log("Original Rows:", uniqueRows);
//     console.log("Mapped Payload:", backendPayload);
//     console.log("Valid Payload (Sending):", validPayload);
    
//     if (validPayload.length === 0) {
//         console.error("CRITICAL: All serial numbers are null! Check your Excel Headers.");
//         console.log("Available Excel Headers:", columns);
//         showAlert("Error: Could not find 'Serial Number' column in your data.", "error");
//         return;
//     }

//     // 4. Send to Backend
//     axios.post("http://127.0.0.1:8081/api/pcb/upload-bulk", {
//         csvDataJSON: validPayload
//     })
//     .then((res) => {
//         showAlert(`Success! Saved ${res.data.count} records.`, "success");
//         setTab("master");
//     })
//     .catch((err) => {
//         console.error("Backend Error:", err);
//         if (err.response) {
//             showAlert(`Server Error: ${err.response.data.message}`, "error");
//         } else {
//             showAlert("Network Error", "error");
//         }
//     });
//   };
//   const toggleAssign = (id) => {
//     setMasterList((p) =>
//       p.map((row) =>
//         row.id === id
//           ? { ...row, status: row.status === "Assigned" ? "Not Assigned" : "Assigned" }
//           : row
//       )
//     );
//   };

//   const pushToInactive = () => {
//     const selected = masterList.filter((r) => r.status === "Assigned");
//     const moved = selected.map((r) => ({
//       ...r,
//       status: "Incomplete",
//     }));

//     setInactiveList((p) => [...p, ...moved]);
//     setMasterList((p) => p.filter((r) => r.status !== "Assigned"));
//     setTab("inactive");
//   };

//   const reassign = (id) => {
//     const row = inactiveList.find((r) => r.id === id);
//     const updated = { ...row, status: "Not Assigned" };

//     setMasterList((p) => [...p, updated]);
//     setInactiveList((p) => p.filter((r) => r.id !== id));
//     setTab("master");
//   };

//   const showAlert = (msg, type) => {
//     setAlert({ open: true, msg, type });
//   };

//   // Handle Tab Change
//   const handleTabChange = (event, newValue) => {
//     setTab(newValue);
//   };

//   // ==================================================
//   // UI RENDER
//   // ==================================================
//   return (
//     <Box sx={{ width: '100%', typography: 'body1' }}>
      
//       {/* 1. HEADER & TABS */}
//       <Paper elevation={2} sx={{ mb: 3, borderRadius: 2 }}>
//         <Tabs 
//           value={tab} 
//           onChange={handleTabChange} 
//           variant="fullWidth" 
//           indicatorColor="primary"
//           textColor="primary"
//           sx={{ borderBottom: 1, borderColor: 'divider' }}
//         >
//           <Tab icon={<CloudUploadIcon />} label="Upload Excel" value="upload" iconPosition="start" />
//           <Tab icon={<AddIcon />} label="Preview & Edit" value="preview" iconPosition="start" disabled={previewRows.length === 0} />
//           <Tab icon={<StorageIcon />} label="Master List" value="master" iconPosition="start" />
//           <Tab icon={<BlockIcon />} label="Inactive" value="inactive" iconPosition="start" />
//         </Tabs>
//       </Paper>

//       {/* 2. UPLOAD VIEW */}
//       {tab === "upload" && (
//         <Card elevation={3} sx={{ borderRadius: 3, mt: 4, maxWidth: 600, mx: 'auto' }}>
//           <CardContent sx={{ textAlign: 'center', py: 6 }}>
//             <Box 
//               sx={{ 
//                 border: '2px dashed', 
//                 borderColor: 'primary.light', 
//                 borderRadius: 2, 
//                 bgcolor: 'primary.50',
//                 p: 5,
//                 mb: 3,
//                 cursor: 'pointer',
//                 transition: '0.3s',
//                 '&:hover': { bgcolor: 'primary.100', borderColor: 'primary.main' }
//               }}
//               component="label"
//             >
//               <UploadFileIcon sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
//               <Typography variant="h6" color="textPrimary" gutterBottom>
//                 Click to Browse Excel File
//               </Typography>
//               <Typography variant="body2" color="textSecondary">
//                 Supports .xlsx and .xls files
//               </Typography>
//               <input type="file" hidden onChange={handleFileUpload} accept=".xlsx, .xls" />
//             </Box>

//             {fileName && (
//               <Chip 
//                 label={fileName} 
//                 color="primary" 
//                 variant="outlined" 
//                 onDelete={() => setFileName("")} 
//                 sx={{ mb: 2 }}
//               />
//             )}
            
//             {!fileName && <Typography variant="caption" color="text.secondary">No file selected yet</Typography>}
//           </CardContent>
//         </Card>
//       )}

//       {/* 3. PREVIEW VIEW */}
//       {tab === "preview" && (
//         <Paper elevation={3} sx={{ borderRadius: 2, overflow: 'hidden' }}>
//           <Box sx={{ p: 2, bgcolor: theme.palette.grey[100], display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <Typography variant="h6" fontWeight="bold">Preview Data</Typography>
//             <Stack direction="row" spacing={2}>
//               <Button variant="outlined" startIcon={<AddIcon />} onClick={addRow}>Add Row</Button>
//               <Button variant="contained" startIcon={<SaveIcon />} onClick={saveToMaster}>Save to Master</Button>
//             </Stack>
//           </Box>
//           <Divider />
//           <TableContainer sx={{ maxHeight: '60vh' }}>
//             <Table stickyHeader size="small">
//               <TableHead>
//                 <TableRow>
//                   {columns.map((c) => (
//                     <TableCell key={c} sx={{ bgcolor: 'white', fontWeight: 'bold' }}>{c}</TableCell>
//                   ))}
//                   <TableCell align="center" sx={{ bgcolor: 'white', fontWeight: 'bold' }}>Action</TableCell>
//                 </TableRow>
//               </TableHead>
//               <TableBody>
//                 {previewRows.map((row) => (
//                   <TableRow key={row.id} hover>
//                     {columns.map((c) => (
//                       <TableCell key={c}>
//                         <TextField
//                           variant="standard"
//                           size="small"
//                           value={row[c] || ""}
//                           onChange={(e) => updateCell(row.id, c, e.target.value)}
//                           InputProps={{ disableUnderline: true }}
//                           sx={{ '& .MuiInputBase-input': { fontSize: '0.875rem' } }}
//                           fullWidth
//                         />
//                       </TableCell>
//                     ))}
//                     <TableCell align="center">
//                       <Button size="small" color="error" onClick={() => deleteRow(row.id)}>
//                         <DeleteIcon fontSize="small" />
//                       </Button>
//                     </TableCell>
//                   </TableRow>
//                 ))}
//               </TableBody>
//             </Table>
//           </TableContainer>
//         </Paper>
//       )}

//       {/* 4. MASTER LIST VIEW */}
//       {tab === "master" && (
//         <Paper elevation={3} sx={{ borderRadius: 2, overflow: 'hidden' }}>
//           <Box sx={{ p: 2, bgcolor: theme.palette.grey[100], display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <Typography variant="h6" fontWeight="bold">Master Database</Typography>
//             <Button variant="contained" color="warning" startIcon={<AssignmentReturnIcon />} onClick={pushToInactive}>
//               Move Assigned to Inactive
//             </Button>
//           </Box>
//           <Divider />
//           <TableContainer sx={{ maxHeight: '65vh' }}>
//             <Table stickyHeader size="small">
//               <TableHead>
//                 <TableRow>
//                   <TableCell sx={{ bgcolor: 'white', fontWeight: 'bold' }}>Assign</TableCell>
//                   {columns.map((h) => (
//                     <TableCell key={h} sx={{ bgcolor: 'white', fontWeight: 'bold' }}>{h}</TableCell>
//                   ))}
//                   <TableCell sx={{ bgcolor: 'white', fontWeight: 'bold' }}>Status</TableCell>
//                 </TableRow>
//               </TableHead>
//               <TableBody>
//                 {masterList.map((row) => (
//                   <TableRow key={row.id} hover selected={row.status === "Assigned"}>
//                     <TableCell padding="checkbox">
//                       <Checkbox
//                         checked={row.status === "Assigned"}
//                         onChange={() => toggleAssign(row.id)}
//                         color="primary"
//                       />
//                     </TableCell>
//                     {columns.map((c) => (
//                       <TableCell key={c}>{row[c]}</TableCell>
//                     ))}
//                     <TableCell>
//                       <Chip 
//                         label={row.status} 
//                         size="small" 
//                         color={row.status === "Assigned" ? "success" : "default"} 
//                         variant={row.status === "Assigned" ? "filled" : "outlined"}
//                       />
//                     </TableCell>
//                   </TableRow>
//                 ))}
//                 {masterList.length === 0 && (
//                   <TableRow>
//                     <TableCell colSpan={columns.length + 2} align="center" sx={{ py: 3 }}>
//                       <Typography variant="body2" color="textSecondary">No records found.</Typography>
//                     </TableCell>
//                   </TableRow>
//                 )}
//               </TableBody>
//             </Table>
//           </TableContainer>
//         </Paper>
//       )}

//       {/* 5. INACTIVE VIEW */}
//       {tab === "inactive" && (
//         <Paper elevation={3} sx={{ borderRadius: 2, overflow: 'hidden' }}>
//           <Box sx={{ p: 2, bgcolor: theme.palette.grey[100] }}>
//              <Typography variant="h6" fontWeight="bold">Inactive / Incomplete Items</Typography>
//           </Box>
//           <Divider />
//           <TableContainer sx={{ maxHeight: '65vh' }}>
//             <Table stickyHeader size="small">
//               <TableHead>
//                 <TableRow>
//                   {columns.map((h) => (
//                     <TableCell key={h} sx={{ bgcolor: 'white', fontWeight: 'bold' }}>{h}</TableCell>
//                   ))}
//                   <TableCell sx={{ bgcolor: 'white', fontWeight: 'bold' }}>Status</TableCell>
//                   <TableCell sx={{ bgcolor: 'white', fontWeight: 'bold' }}>Action</TableCell>
//                 </TableRow>
//               </TableHead>
//               <TableBody>
//                 {inactiveList.map((row) => (
//                   <TableRow key={row.id} hover>
//                     {columns.map((c) => (
//                       <TableCell key={c}>{row[c]}</TableCell>
//                     ))}
//                     <TableCell>
//                       <Chip label={row.status} size="small" color="error" variant="outlined" />
//                     </TableCell>
//                     <TableCell>
//                       <Button 
//                         startIcon={<ReplayIcon />} 
//                         size="small" 
//                         variant="outlined" 
//                         onClick={() => reassign(row.id)}
//                       >
//                         Reassign
//                       </Button>
//                     </TableCell>
//                   </TableRow>
//                 ))}
//                  {inactiveList.length === 0 && (
//                   <TableRow>
//                     <TableCell colSpan={columns.length + 2} align="center" sx={{ py: 3 }}>
//                       <Typography variant="body2" color="textSecondary">No inactive records.</Typography>
//                     </TableCell>
//                   </TableRow>
//                 )}
//               </TableBody>
//             </Table>
//           </TableContainer>
//         </Paper>
//       )}

//       {/* SNACKBAR */}
//       <Snackbar
//         open={alert.open}
//         autoHideDuration={3000}
//         onClose={() => setAlert({ ...alert, open: false })}
//         anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
//       >
//         <Alert severity={alert.type} variant="filled" onClose={() => setAlert({ ...alert, open: false })}>
//           {alert.msg}
//         </Alert>
//       </Snackbar>
//     </Box>
//   );
// }

import React, { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  TextField,
  Checkbox,
  Snackbar,
  Alert,
  Tabs,
  Tab,
  Paper,
  TableContainer,
  Stack,
  Divider,
  Chip,
  useTheme
} from "@mui/material";

// Icons
import UploadFileIcon from "@mui/icons-material/UploadFile";
import AddIcon from "@mui/icons-material/Add";
import DeleteIcon from "@mui/icons-material/Delete";
import ReplayIcon from "@mui/icons-material/Replay";
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import StorageIcon from '@mui/icons-material/Storage';
import BlockIcon from '@mui/icons-material/Block';
import SaveIcon from '@mui/icons-material/Save';
import AssignmentReturnIcon from '@mui/icons-material/AssignmentReturn';

import axios from "axios";

// CONFIG
const API_URL = "http://127.0.0.1:8081/api/pcb"; 

export default function AddProject() {
  const theme = useTheme();
  
  // STATE
  const [tab, setTab] = useState("upload");
  const [previewRows, setPreviewRows] = useState([]);
  const [masterList, setMasterList] = useState([]);
  const [inactiveList, setInactiveList] = useState([]);
  const [columns, setColumns] = useState([]);
  const [serialColumn, setSerialColumn] = useState(""); 
  const [fileName, setFileName] = useState("");
  const [alert, setAlert] = useState({ open: false, msg: "", type: "error" });

  // 1. FETCH DATA ON LOAD
  useEffect(() => {
    axios
      .get(`${API_URL}/history`)
      .then((res) => {
        if (res.data && res.data.PcbData) {
          const allData = res.data.PcbData;

          // Split into Master (Active) and Inactive
          const activeItems = allData
            .filter((item) => item.status !== "Inactive")
            .map((item) => ({
              id: item.serialNo, // UI needs unique ID
              ...item,
              status: "Not Assigned", // Reset UI selection
            }));
            
          const inactiveItems = allData
            .filter((item) => item.status === "Inactive")
            .map((item) => ({
              id: item.serialNo,
              ...item,
              status: "Incomplete",
            }));

          setMasterList(activeItems);
          setInactiveList(inactiveItems);
        }
      })
      .catch((err) => console.error("Fetch Error:", err));
  }, []);


  // 2. EXCEL UPLOAD HANDLER
  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (evt) => {
      const buffer = new Uint8Array(evt.target.result);
      const wb = XLSX.read(buffer, { type: "array" });
      const ws = wb.Sheets[wb.SheetNames[0]];
      let json = XLSX.utils.sheet_to_json(ws);

      if (json.length === 0) {
        showAlert("Excel file is empty!", "error");
        return;
      }

      const cols = Object.keys(json[0]);
      setColumns(cols);

      // Detect Serial Column
      const serialCol = cols.find(
        (c) => c.toLowerCase().replace(/\s+/g, "") === "serialnumber"
      );
      setSerialColumn(serialCol);

      const rows = json.map((row, i) => ({
        id: Date.now() + "-" + i,
        ...row,
      }));

      setPreviewRows(rows);
      setTab("preview");
    };
    reader.readAsArrayBuffer(file);
  };

  // 3. TABLE EDIT HANDLERS
  const addRow = () => {
    const newRow = { id: Date.now() };
    columns.forEach((c) => (newRow[c] = ""));
    setPreviewRows((p) => [...p, newRow]);
  };

  const deleteRow = (id) => {
    setPreviewRows((p) => p.filter((row) => row.id !== id));
  };

  const updateCell = (id, key, value) => {
    setPreviewRows((p) =>
      p.map((row) => (row.id === id ? { ...row, [key]: value } : row))
    );
  };

  // 4. SAVE TO MASTER (ROBUST MAPPING)
  const saveToMaster = () => {
    // UI Duplicate Check
    let existingSerials = new Set(
      masterList.map((r) => (serialColumn ? r[serialColumn] : null))
    );
    let uniqueRows = [];
    let duplicates = [];

    previewRows.forEach((r) => {
      const serialValue = serialColumn ? r[serialColumn] : null;
      if (serialColumn && (!serialValue || existingSerials.has(serialValue))) {
        duplicates.push(serialValue);
      } else {
        uniqueRows.push({ ...r, status: "Not Assigned" });
      }
    });

    if (duplicates.length > 0) {
      showAlert(`Skipped ${duplicates.length} duplicates.`, "warning");
    }

    const finalList = [...masterList, ...uniqueRows];
    setMasterList(finalList);

    // Prepare Backend Payload
    const backendPayload = uniqueRows.map((row) => {
      const findValue = (possibleHeaders) => {
        const keys = Object.keys(row);
        const match = keys.find(k => {
          const cleanKey = k.toLowerCase().replace(/[^a-z0-9]/g, "");
          return possibleHeaders.some(h => cleanKey === h);
        });
        return match ? row[match] : null;
      };

      return {
        // IMPORTANT: Exclude 'id' from search to avoid big timestamps
        sno: parseInt(findValue(["sno", "no", "index"]) || 0, 10),
        partNumber: findValue(["partnumber", "partno", "pno", "model"]) || "UNKNOWN",
        serialNo: row[serialColumn] || findValue(["serialno", "serialnumber", "serial"])
      };
    });

    const validPayload = backendPayload.filter(item => item.serialNo);

    if (validPayload.length === 0) {
        if(duplicates.length === 0) showAlert("No valid data to save.", "info");
        return;
    }

    // Call API
    axios.post(`${API_URL}/upload-bulk`, { csvDataJSON: validPayload })
    .then((res) => {
        showAlert(`Saved ${res.data.count} records!`, "success");
        setTab("master");
    })
    .catch((err) => {
        console.error(err);
        showAlert("Failed to save data.", "error");
    });
  };

  // 5. MOVE TO INACTIVE
  const toggleAssign = (id) => {
    setMasterList((p) =>
      p.map((row) =>
        row.id === id
          ? { ...row, status: row.status === "Assigned" ? "Not Assigned" : "Assigned" }
          : row
      )
    );
  };

  const pushToInactive = () => {
    const selected = masterList.filter((r) => r.status === "Assigned");
    if (selected.length === 0) return showAlert("Select items first.", "warning");

    const serials = selected.map(r => r.serialNo);

    // Call API
    axios.put(`${API_URL}/update-status`, { serialNos: serials, status: "Inactive" })
    .then(() => {
        const moved = selected.map((r) => ({ ...r, status: "Incomplete" }));
        setInactiveList((p) => [...p, ...moved]);
        setMasterList((p) => p.filter((r) => r.status !== "Assigned"));
        showAlert("Moved to Inactive List.", "success");
        setTab("inactive");
    })
    .catch(() => showAlert("Error updating status.", "error"));
  };

  // 6. REASSIGN (Move back to Master)
  const reassign = (id) => {
    const item = inactiveList.find((r) => r.id === id);
    if (!item) return;

    // Call API
    axios.put(`${API_URL}/update-status`, { serialNos: [item.serialNo], status: "Active" })
    .then(() => {
        const updated = { ...item, status: "Not Assigned" };
        setMasterList((p) => [...p, updated]);
        setInactiveList((p) => p.filter((r) => r.id !== id));
        showAlert("Reassigned to Master List.", "success");
        setTab("master");
    })
    .catch(() => showAlert("Error reassigning.", "error"));
  };

  const showAlert = (msg, type) => {
    setAlert({ open: true, msg, type });
  };

  const handleTabChange = (event, newValue) => {
    setTab(newValue);
  };

  // ==================================================
  // UI RENDER
  // ==================================================
  return (
    <Box sx={{ width: '100%', typography: 'body1' }}>
      
      {/* TABS */}
      <Paper elevation={2} sx={{ mb: 3, borderRadius: 2 }}>
        <Tabs 
          value={tab} 
          onChange={handleTabChange} 
          variant="fullWidth" 
          indicatorColor="primary"
          textColor="primary"
        >
          <Tab icon={<CloudUploadIcon />} label="Upload Excel" value="upload" iconPosition="start" />
          <Tab icon={<AddIcon />} label="Preview" value="preview" iconPosition="start" disabled={previewRows.length === 0} />
          <Tab icon={<StorageIcon />} label="Master List" value="master" iconPosition="start" />
          <Tab icon={<BlockIcon />} label="Inactive" value="inactive" iconPosition="start" />
        </Tabs>
      </Paper>

      {/* 1. UPLOAD VIEW */}
      {tab === "upload" && (
        <Card elevation={3} sx={{ borderRadius: 3, mt: 4, maxWidth: 600, mx: 'auto' }}>
          <CardContent sx={{ textAlign: 'center', py: 6 }}>
            <Box 
              sx={{ 
                border: '2px dashed', borderColor: 'primary.light', borderRadius: 2, 
                bgcolor: 'primary.50', p: 5, mb: 3, cursor: 'pointer',
                '&:hover': { bgcolor: 'primary.100' }
              }}
              component="label"
            >
              <UploadFileIcon sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
              <Typography variant="h6">Click to Browse Excel File</Typography>
              <input type="file" hidden onChange={handleFileUpload} accept=".xlsx, .xls" />
            </Box>
            {fileName && <Chip label={fileName} color="primary" onDelete={() => setFileName("")} />}
          </CardContent>
        </Card>
      )}

      {/* 2. PREVIEW VIEW */}
      {tab === "preview" && (
        <Paper elevation={3} sx={{ borderRadius: 2 }}>
          <Box sx={{ p: 2, bgcolor: theme.palette.grey[100], display: 'flex', justifyContent: 'space-between' }}>
            <Typography variant="h6">Preview Data</Typography>
            <Stack direction="row" spacing={2}>
              <Button variant="outlined" startIcon={<AddIcon />} onClick={addRow}>Add Row</Button>
              <Button variant="contained" startIcon={<SaveIcon />} onClick={saveToMaster}>Save to Master</Button>
            </Stack>
          </Box>
          <Divider />
          <TableContainer sx={{ maxHeight: '60vh' }}>
            <Table stickyHeader size="small">
              <TableHead>
                <TableRow>
                  {columns.map((c) => <TableCell key={c} sx={{ fontWeight: 'bold' }}>{c}</TableCell>)}
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Action</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {previewRows.map((row) => (
                  <TableRow key={row.id}>
                    {columns.map((c) => (
                      <TableCell key={c}>
                        <TextField
                          variant="standard" size="small" fullWidth
                          value={row[c] || ""}
                          onChange={(e) => updateCell(row.id, c, e.target.value)}
                          InputProps={{ disableUnderline: true }}
                        />
                      </TableCell>
                    ))}
                    <TableCell align="center">
                      <Button size="small" color="error" onClick={() => deleteRow(row.id)}><DeleteIcon /></Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      )}

      {/* 3. MASTER LIST VIEW */}
      {tab === "master" && (
        <Paper elevation={3} sx={{ borderRadius: 2 }}>
          <Box sx={{ p: 2, bgcolor: theme.palette.grey[100], display: 'flex', justifyContent: 'space-between' }}>
            <Typography variant="h6">Master Database</Typography>
            <Button variant="contained" color="warning" startIcon={<AssignmentReturnIcon />} onClick={pushToInactive}>
              Move Assigned to Inactive
            </Button>
          </Box>
          <Divider />
          <TableContainer sx={{ maxHeight: '65vh' }}>
            <Table stickyHeader size="small">
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 'bold' }}>Select</TableCell>
                  {columns.map((h) => <TableCell key={h} sx={{ fontWeight: 'bold' }}>{h}</TableCell>)}
                  <TableCell sx={{ fontWeight: 'bold' }}>Status</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {masterList.map((row) => (
                  <TableRow key={row.id} hover selected={row.status === "Assigned"}>
                    <TableCell padding="checkbox">
                      <Checkbox checked={row.status === "Assigned"} onChange={() => toggleAssign(row.id)} />
                    </TableCell>
                    {columns.map((c) => <TableCell key={c}>{row[c]}</TableCell>)}
                    <TableCell>
                      <Chip label={row.status} size="small" color={row.status === "Assigned" ? "success" : "default"} />
                    </TableCell>
                  </TableRow>
                ))}
                {masterList.length === 0 && (
                   <TableRow><TableCell colSpan={10} align="center">No active records found.</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      )}

      {/* 4. INACTIVE VIEW */}
      {tab === "inactive" && (
        <Paper elevation={3} sx={{ borderRadius: 2 }}>
          <Box sx={{ p: 2, bgcolor: theme.palette.grey[100] }}>
             <Typography variant="h6">Inactive / Incomplete Items</Typography>
          </Box>
          <Divider />
          <TableContainer sx={{ maxHeight: '65vh' }}>
            <Table stickyHeader size="small">
              <TableHead>
                <TableRow>
                  {columns.map((h) => <TableCell key={h} sx={{ fontWeight: 'bold' }}>{h}</TableCell>)}
                  <TableCell sx={{ fontWeight: 'bold' }}>Status</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Action</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {inactiveList.map((row) => (
                  <TableRow key={row.id} hover>
                    {columns.map((c) => <TableCell key={c}>{row[c]}</TableCell>)}
                    <TableCell><Chip label={row.status} size="small" color="error" variant="outlined" /></TableCell>
                    <TableCell>
                      <Button startIcon={<ReplayIcon />} size="small" onClick={() => reassign(row.id)}>Reassign</Button>
                    </TableCell>
                  </TableRow>
                ))}
                 {inactiveList.length === 0 && (
                   <TableRow><TableCell colSpan={10} align="center">No inactive records.</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      )}

      {/* SNACKBAR */}
      <Snackbar
        open={alert.open} autoHideDuration={3000}
        onClose={() => setAlert({ ...alert, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert severity={alert.type} variant="filled" onClose={() => setAlert({ ...alert, open: false })}>
          {alert.msg}
        </Alert>
      </Snackbar>
    </Box>
  );
}