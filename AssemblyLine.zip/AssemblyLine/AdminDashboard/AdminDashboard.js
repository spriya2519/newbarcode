// // src/components/AdminDashboard/AdminDashboard.jsx
// import React, { useState } from "react";
// import {
//   Box,
//   Drawer,
//   List,
//   ListItem,
//   ListItemIcon,
//   ListItemText,
//   Typography,
//     IconButton,
//   AppBar,
//   Toolbar,
// } from "@mui/material";
// import LogoutIcon from "@mui/icons-material/Logout";
// import {
//   Dashboard,
//   PlaylistAdd,
//   Build,
//   GroupAdd,
// } from "@mui/icons-material";
// import AddProject from "./AddProject";
// import AddProcess from "./AddProcess";
// import ManageUsers from "./ManageUsers";
// import DashboardView from "./DashboardView";

// const menuItems = [
//   { text: "Dashboard", icon: <Dashboard />, component: <DashboardView /> },
//   { text: "Add Project", icon: <PlaylistAdd />, component: <AddProject /> },
//   { text: "Add Process", icon: <Build />, component: <AddProcess /> },
//   { text: "Manage Users", icon: <GroupAdd />, component: <ManageUsers /> },
// ];

// export default function AdminDashboard({ onLogout }) {
//   const [selected, setSelected] = useState(menuItems[0]);

//   return (
//     <Box sx={{ display: "flex" }}>
//       {/* Sidebar */}
//       <Drawer
//         variant="permanent"
//         sx={{
//           width: 240,
//           flexShrink: 0,
//           [`& .MuiDrawer-paper`]: {
//             width: 240,
//             boxSizing: "border-box",
//             backgroundColor: "#263238",
//             color: "white",
//           },
//         }}
//       >
//         <Toolbar>
//           <Typography variant="h6" sx={{ fontWeight: "bold", color: "#FFD600" }}>
//             Admin Panel
//           </Typography>
//         </Toolbar>
//         <List>
//           {menuItems.map((item) => (
//             <ListItem
//               button
//               key={item.text}
//               selected={selected.text === item.text}
//               onClick={() => setSelected(item)}
//               sx={{
//                 "&.Mui-selected": { backgroundColor: "#455A64" },
//               }}
//             >
//               <ListItemIcon sx={{ color: "white" }}>{item.icon}</ListItemIcon>
//               <ListItemText primary={item.text} />
//             </ListItem>
//           ))}
//         </List>
//       </Drawer>

//       {/* Main Content */}
//       <Box component="main" sx={{ flexGrow: 1, bgcolor: "#ECEFF1", p: 3 }}>
//         <AppBar
//           position="static"
//           sx={{ backgroundColor: "#37474F", mb: 2, boxShadow: 0 }}
//         >
//           <Toolbar>
//             <Typography variant="h6" sx={{ flexGrow: 1 }}>
//               {selected.text}</Typography>

//           <IconButton color="inherit" onClick={onLogout}>
//             <LogoutIcon />
//           </IconButton>
            
//           </Toolbar>
    
//         </AppBar>
        
//         {selected.component}
//       </Box>

//     </Box>
//   );
// }


// src/components/AdminDashboard/AdminDashboard.jsx
import React, { useState } from "react";
import {
  Box,
  Typography,
  IconButton,
  AppBar,
  Toolbar,
  Container,
  Grid,
  Card,
  CardActionArea,
  CardContent,
  useTheme,
  Avatar,
  Tooltip,
} from "@mui/material";
import {
  Logout as LogoutIcon,
  Dashboard as DashboardIcon,
  PlaylistAdd as PlaylistAddIcon,
  Build as BuildIcon,
  GroupAdd as GroupAddIcon,
  ArrowBack as ArrowBackIcon,
  Home as HomeIcon,
} from "@mui/icons-material";

// Sub-components (assuming these exist as per your original code)
import AddProject from "./AddProject";
import AddProcess from "./AddProcess";
import ManageUsers from "./ManageUsers";
import DashboardView from "./DashboardView";

// Define menu items with their corresponding components and icons
const menuItems = [
  {
    text: "Overview Dashboard",
    description: "View key metrics and system status.",
    icon: <DashboardIcon fontSize="large" />,
    component: <DashboardView />,
    color: "#1976d2", // Primary Blue
  },
  {
    text: "Add Project",
    description: "Create new projects and assign workflows.",
    icon: <PlaylistAddIcon fontSize="large" />,
    component: <AddProject />,
    color: "#2e7d32", // Green
  },
  {
    text: "Add Process",
    description: "Define new manufacturing processes.",
    icon: <BuildIcon fontSize="large" />,
    component: <AddProcess />,
    color: "#ed6c02", // Orange
  },
  {
    text: "Manage Users",
    description: "Administer user roles and permissions.",
    icon: <GroupAddIcon fontSize="large" />,
    component: <ManageUsers />,
    color: "#9c27b0", // Purple
  },
];

export default function AdminDashboard({ onLogout }) {
  const theme = useTheme();
  // State: 'null' means we are on the Home Card Grid view. 
  // Otherwise, it holds the selected menu item object.
  const [selectedView, setSelectedView] = useState(null);

  // Helper to return to the main grid
  const handleBackToHome = () => {
    setSelectedView(null);
  };

  // ---- The "Home Grid" Component ----
  const HomeCardGrid = () => (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ mb: 4, textAlign: 'center' }}>
        <Typography variant="h4" component="h1" gutterBottom fontWeight="bold" color="primary.main">
          Welcome, Administrator
        </Typography>
        <Typography variant="subtitle1" color="text.secondary">
          Select an action below to manage the system.
        </Typography>
      </Box>

      <Grid container spacing={4} justifyContent="center">
        {menuItems.map((item) => (
          <Grid item key={item.text} xs={12} sm={6} md={4} lg={3}>
            <Card
              elevation={3}
              sx={{
                height: "100%",
                borderRadius: 3,
                transition: "transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out",
                "&:hover": {
                  transform: "translateY(-8px)",
                  boxShadow: theme.shadows[10],
                  "& .MuiAvatar-root": {
                     backgroundColor: item.color,
                     color: "white"
                  }
                },
              }}
            >
              <CardActionArea
                onClick={() => setSelectedView(item)}
                sx={{ height: "100%", p: 2 }}
              >
                <CardContent
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    textAlign: "center",
                    height: "100%"
                  }}
                >
                  {/* Colored Avatar for Icon */}
                  <Avatar
                    sx={{
                      bgcolor: theme.palette.grey[100],
                      color: item.color,
                      width: 70,
                      height: 70,
                      mb: 2,
                      transition: "all 0.3s ease",
                    }}
                  >
                    {item.icon}
                  </Avatar>

                  <Typography variant="h6" component="div" fontWeight="bold" gutterBottom>
                    {item.text}
                  </Typography>
                   <Typography variant="body2" color="text.secondary">
                    {item.description}
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  );

  // ---- Main Render ----
  return (
    <Box sx={{ display: "flex", flexDirection: "column", minHeight: "100vh", bgcolor: "#f4f6f8" }}>
      {/* Professional AppBar */}
      <AppBar
        position="sticky"
        elevation={2}
        sx={{
          backgroundColor: theme.palette.background.paper,
          color: theme.palette.text.primary,
          borderBottom: `1px solid ${theme.palette.divider}`
        }}
      >
        <Toolbar>
          {/* Conditional 'Back' or 'Home' Icon */}
          {selectedView ? (
            <Tooltip title="Back to Dashboard Home">
               <IconButton
                 edge="start"
                 color="primary"
                 onClick={handleBackToHome}
                 sx={{ mr: 2 }}
               >
                 <ArrowBackIcon />
               </IconButton>
            </Tooltip>
          ) : (
             <IconButton edge="start" color="primary" sx={{ mr: 2, cursor: 'default' }}>
                <HomeIcon />
             </IconButton>
          )}

          {/* Dynamic Title */}
          <Typography variant="h6" component="div" sx={{ flexGrow: 1, fontWeight: 600 }}>
            {selectedView ? selectedView.text : "Admin Control Panel"}
          </Typography>

          {/* Logout Button */}
          <Tooltip title="Logout">
            <IconButton onClick={onLogout} color="error">
              <LogoutIcon />
            </IconButton>
          </Tooltip>
        </Toolbar>
      </AppBar>

      {/* Main Content Area - Switches between Grid and Selected Component */}
      <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
        {selectedView ? (
          // Render the component selected from the card
          <Box sx={{ bgcolor: theme.palette.background.paper, p: 3, borderRadius: 2, boxShadow: 1, minHeight:'80vh' }}>
             {selectedView.component}
          </Box>
        ) : (
          // Render the Home Grid
          <HomeCardGrid />
        )}
      </Box>
    </Box>
  );
}