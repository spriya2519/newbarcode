
// // // // // import React, { useState } from "react";
// // // // // import {
// // // // //   Box,
// // // // //   Typography,
// // // // //   Button,
// // // // //   Card,
// // // // //   CardContent,
// // // // //   TextField,
// // // // //   Table,
// // // // //   TableBody,
// // // // //   TableCell,
// // // // //   TableHead,
// // // // //   TableRow,
// // // // //   Paper,
// // // // //   Snackbar,
// // // // //   Alert,
// // // // //   AppBar,
// // // // //   Toolbar,
// // // // //   IconButton
// // // // // } from "@mui/material";
// // // // // import LogoutIcon from "@mui/icons-material/Logout";

// // // // // const OperatorPage = ({ onLogout }) => {
// // // // //   // Sample task list
// // // // //   const [tasks, setTasks] = useState([
// // // // //     { id: 1, name: "Inspect Material", status: "Pending" },
// // // // //     { id: 2, name: "Assemble Parts", status: "Pending" },
// // // // //     { id: 3, name: "Quality Check", status: "Completed" },
// // // // //   ]);

// // // // //   const [correction, setCorrection] = useState("");
// // // // //   const [openSnackbar, setOpenSnackbar] = useState(false);

// // // // //   const handleComplete = (id) => {
// // // // //     const updated = tasks.map((task) =>
// // // // //       task.id === id ? { ...task, status: "Completed" } : task
// // // // //     );
// // // // //     setTasks(updated);
// // // // //     setOpenSnackbar(true);
// // // // //   };

// // // // //   const handleRequestCorrection = () => {
// // // // //     if (!correction.trim())
// // // // //       return alert("Please enter your correction details");
// // // // //     alert(`Correction Request Sent:\n${correction}`);
// // // // //     setCorrection("");
// // // // //   };

// // // // //   return (
// // // // //     <Box sx={{ display: "flex", height: "100vh", backgroundColor: "#ECEFF1" }}>
      
// // // // //       {/* Sidebar */}
// // // // //       <Box
// // // // //         sx={{
// // // // //           width: 220,
// // // // //           backgroundColor: "#263238",
// // // // //           color: "#fff",
// // // // //           display: "flex",
// // // // //           flexDirection: "column",
// // // // //           p: 2,
// // // // //           gap: 1,
// // // // //         }}
// // // // //       >
// // // // //         <Typography variant="h6" sx={{ mb: 2, color: "#90caf9" }}>
// // // // //           Operator Panel
// // // // //         </Typography>
// // // // //         <Button variant="contained" color="info">
// // // // //           My Tasks
// // // // //         </Button>
// // // // //         <Button variant="contained" color="info">
// // // // //           Request Correction
// // // // //         </Button>
// // // // //       </Box>

// // // // //       {/* Main Content */}
// // // // //       <Box sx={{ flex: 1 }}>

// // // // //         {/* ✅ Added AppBar (same style as AdminDashboard) */}
// // // // //         <AppBar
// // // // //           position="static"
// // // // //           sx={{ backgroundColor: "#37474F", mb: 2, boxShadow: 0 }}
// // // // //         >
// // // // //           <Toolbar>
// // // // //             <Typography variant="h6" sx={{ flexGrow: 1 }}>
// // // // //               Operator Dashboard
// // // // //             </Typography>

// // // // //             <IconButton color="inherit" onClick={onLogout}>
// // // // //               <LogoutIcon />
// // // // //             </IconButton>
// // // // //           </Toolbar>
// // // // //         </AppBar>

// // // // //         <Box sx={{ p: 3 }}>

// // // // //           {/* Task Table */}
// // // // //           <Card sx={{ mb: 4 }}>
// // // // //             <CardContent>
// // // // //               <Typography variant="h6" gutterBottom>
// // // // //                 Assigned Tasks
// // // // //               </Typography>
// // // // //               <Table component={Paper}>
// // // // //                 <TableHead>
// // // // //                   <TableRow sx={{ backgroundColor: "#CFD8DC" }}>
// // // // //                     <TableCell>Task Name</TableCell>
// // // // //                     <TableCell>Status</TableCell>
// // // // //                     <TableCell>Action</TableCell>
// // // // //                   </TableRow>
// // // // //                 </TableHead>
// // // // //                 <TableBody>
// // // // //                   {tasks.map((task) => (
// // // // //                     <TableRow key={task.id}>
// // // // //                       <TableCell>{task.name}</TableCell>
// // // // //                       <TableCell>{task.status}</TableCell>
// // // // //                       <TableCell>
// // // // //                         {task.status === "Pending" ? (
// // // // //                           <Button
// // // // //                             variant="contained"
// // // // //                             color="success"
// // // // //                             size="small"
// // // // //                             onClick={() => handleComplete(task.id)}
// // // // //                           >
// // // // //                             Mark Complete
// // // // //                           </Button>
// // // // //                         ) : (
// // // // //                           <Typography color="success.main">✔ Done</Typography>
// // // // //                         )}
// // // // //                       </TableCell>
// // // // //                     </TableRow>
// // // // //                   ))}
// // // // //                 </TableBody>
// // // // //               </Table>
// // // // //             </CardContent>
// // // // //           </Card>

// // // // //           {/* Correction Request */}
// // // // //           <Card sx={{ width: "70%", p: 2 }}>
// // // // //             <CardContent>
// // // // //               <Typography variant="h6" gutterBottom>
// // // // //                 Request for Process Correction
// // // // //               </Typography>
// // // // //               <TextField
// // // // //                 label="Describe issue or correction required"
// // // // //                 multiline
// // // // //                 rows={4}
// // // // //                 fullWidth
// // // // //                 sx={{ mb: 2 }}
// // // // //                 value={correction}
// // // // //                 onChange={(e) => setCorrection(e.target.value)}
// // // // //               />
// // // // //               <Button
// // // // //                 variant="contained"
// // // // //                 color="warning"
// // // // //                 onClick={handleRequestCorrection}
// // // // //               >
// // // // //                 Send Request
// // // // //               </Button>
// // // // //             </CardContent>
// // // // //           </Card>

// // // // //           <Snackbar
// // // // //             open={openSnackbar}
// // // // //             autoHideDuration={2000}
// // // // //             onClose={() => setOpenSnackbar(false)}
// // // // //           >
// // // // //             <Alert
// // // // //               onClose={() => setOpenSnackbar(false)}
// // // // //               severity="success"
// // // // //             >
// // // // //               Task marked as completed!
// // // // //             </Alert>
// // // // //           </Snackbar>

// // // // //         </Box>
// // // // //       </Box>
// // // // //     </Box>
// // // // //   );
// // // // // };

// // // // // export default OperatorPage;


// // // // // src/components/OperatorPage/OperatorPage.jsx
// // // // import React, { useState } from "react";
// // // // import {
// // // //   Box,
// // // //   Typography,
// // // //   Button,
// // // //   Card,
// // // //   CardContent,
// // // //   CardActionArea,
// // // //   TextField,
// // // //   Table,
// // // //   TableBody,
// // // //   TableCell,
// // // //   TableHead,
// // // //   TableRow,
// // // //   Paper,
// // // //   Snackbar,
// // // //   Alert,
// // // //   AppBar,
// // // //   Toolbar,
// // // //   IconButton,
// // // //   Container,
// // // //   Grid,
// // // //   Avatar,
// // // //   Tooltip,
// // // //   useTheme,
// // // //   Chip
// // // // } from "@mui/material";
// // // // import {
// // // //   Logout as LogoutIcon,
// // // //   AssignmentTurnedIn as TaskIcon,
// // // //   ReportProblem as AlertIcon,
// // // //   ArrowBack as ArrowBackIcon,
// // // //   Home as HomeIcon,
// // // //   CheckCircle as CheckCircleIcon,
// // // //   Pending as PendingIcon
// // // // } from "@mui/icons-material";
// // // // import OperatorTabs from "../Components11/Operator/Dashboard/OperatorTabs";

// // // // // --- Sub-Component: Task List View ---
// // // // const TaskListView = ({ tasks, onComplete }) => (
// // // //   <Card elevation={0} sx={{ border: "1px solid #e0e0e0" }}>
// // // //     <CardContent>
// // // //       <Box sx={{ mb: 3, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
// // // //         <Typography variant="h5" color="primary.main" fontWeight="bold">
// // // //           Assigned Tasks
// // // //         </Typography>
// // // //         <Chip label={`${tasks.filter(t => t.status === 'Pending').length} Pending`} color="warning" variant="outlined" />
// // // //       </Box>

// // // //       <Table component={Paper} elevation={0} sx={{ border: "1px solid #eeeeee" }}>
// // // //         <TableHead>
// // // //           <TableRow sx={{ backgroundColor: "#f5f5f5" }}>
// // // //             <TableCell sx={{ fontWeight: "bold" }}>Task ID</TableCell>
// // // //             <TableCell sx={{ fontWeight: "bold" }}>Task Name</TableCell>
// // // //             <TableCell sx={{ fontWeight: "bold" }}>Status</TableCell>
// // // //             <TableCell sx={{ fontWeight: "bold", textAlign: "right" }}>Action</TableCell>
// // // //           </TableRow>
// // // //         </TableHead>
// // // //         <TableBody>
// // // //           {tasks.map((task) => (
// // // //             <TableRow key={task.id} hover>
// // // //               <TableCell>#{task.id}</TableCell>
// // // //               <TableCell sx={{ fontWeight: 500 }}>{task.name}</TableCell>
// // // //               <TableCell>
// // // //                 <Chip 
// // // //                   icon={task.status === "Completed" ? <CheckCircleIcon /> : <PendingIcon />}
// // // //                   label={task.status} 
// // // //                   color={task.status === "Completed" ? "success" : "default"} 
// // // //                   size="small" 
// // // //                   variant={task.status === "Completed" ? "filled" : "outlined"}
// // // //                 />
// // // //               </TableCell>
// // // //               <TableCell align="right">
// // // //                 {task.status === "Pending" ? (
// // // //                   <Button
// // // //                     variant="contained"
// // // //                     color="primary"
// // // //                     size="small"
// // // //                     startIcon={<CheckCircleIcon />}
// // // //                     onClick={() => onComplete(task.id)}
// // // //                     sx={{ textTransform: "none", borderRadius: 2 }}
// // // //                   >
// // // //                     Mark Complete
// // // //                   </Button>
// // // //                 ) : (
// // // //                   <Typography variant="caption" color="text.secondary" sx={{ fontStyle: 'italic' }}>
// // // //                     Completed
// // // //                   </Typography>
// // // //                 )}
// // // //               </TableCell>
// // // //             </TableRow>
// // // //           ))}
// // // //         </TableBody>
// // // //       </Table>
// // // //     </CardContent>
// // // //   </Card>
// // // // );

// // // // // --- Sub-Component: Correction Request View ---
// // // // const CorrectionRequestView = ({ correction, setCorrection, onSubmit }) => (
// // // //   <Container maxWidth="md">
// // // //     <Card elevation={0} sx={{ border: "1px solid #e0e0e0" }}>
// // // //       <CardContent sx={{ p: 4 }}>
// // // //         <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
// // // //            <Avatar sx={{ bgcolor: '#ed6c02', mr: 2 }}>
// // // //              <AlertIcon />
// // // //            </Avatar>
// // // //            <Typography variant="h5" fontWeight="bold">
// // // //              Report an Issue
// // // //            </Typography>
// // // //         </Box>
        
// // // //         <Typography variant="body1" color="text.secondary" paragraph>
// // // //           Please describe the issue, machine fault, or process correction required in detail below. This will be sent to the supervisor immediately.
// // // //         </Typography>

// // // //         <TextField
// // // //           label="Description of Issue / Correction"
// // // //           placeholder="E.g., Machine #4 alignment is off by 2mm..."
// // // //           multiline
// // // //           rows={6}
// // // //           fullWidth
// // // //           variant="outlined"
// // // //           sx={{ mb: 3, bgcolor: '#fafafa' }}
// // // //           value={correction}
// // // //           onChange={(e) => setCorrection(e.target.value)}
// // // //         />
        
// // // //         <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
// // // //           <Button
// // // //             variant="contained"
// // // //             color="warning"
// // // //             size="large"
// // // //             startIcon={<AlertIcon />}
// // // //             onClick={onSubmit}
// // // //             sx={{ px: 4, py: 1.5, borderRadius: 2 }}
// // // //           >
// // // //             Submit Request
// // // //           </Button>
// // // //         </Box>
// // // //       </CardContent>
// // // //     </Card>
// // // //   </Container>
// // // // );

// // // // // --- Main Component ---
// // // // const OperatorPage = ({ onLogout }) => {
// // // //   const theme = useTheme();
  
// // // //   // -- State Management --
// // // //   // 'selectedView' stores the ID of the active view ('tasks', 'correction', or null for Home)
// // // //   const [selectedView, setSelectedView] = useState(null); 
  
// // // //   // Data State
// // // //   const [tasks, setTasks] = useState([
// // // //     { id: 101, name: "Inspect Incoming Material - Batch A", status: "Pending" },
// // // //     { id: 102, name: "Assemble Hydraulic Pump", status: "Pending" },
// // // //     { id: 103, name: "Final Quality Safety Check", status: "Completed" },
// // // //     { id: 104, name: "Log Daily Output Metrics", status: "Pending" },
// // // //   ]);
// // // //   const [correction, setCorrection] = useState("");
// // // //   const [openSnackbar, setOpenSnackbar] = useState(false);
// // // //   const [snackbarMsg, setSnackbarMsg] = useState("");

// // // //   // -- Handlers --
// // // //   const handleBackToHome = () => setSelectedView(null);

// // // //   const handleComplete = (id) => {
// // // //     const updated = tasks.map((task) =>
// // // //       task.id === id ? { ...task, status: "Completed" } : task
// // // //     );
// // // //     setTasks(updated);
// // // //     setSnackbarMsg("Task marked as completed successfully.");
// // // //     setOpenSnackbar(true);
// // // //   };

// // // //   const handleRequestCorrection = () => {
// // // //     if (!correction.trim()) return alert("Please enter details first.");
// // // //     setSnackbarMsg("Correction request sent to supervisor.");
// // // //     setOpenSnackbar(true);
// // // //     setCorrection("");
// // // //     // Optional: Navigate back home after submit
// // // //     // setSelectedView(null); 
// // // //   };

// // // //   // -- Menu Configuration --
// // // //   const menuItems = [
// // // //     {
// // // //       id: 'tasks',
// // // //       text: "My Tasks",
// // // //       description: "View and update your assigned daily production tasks.",
// // // //       icon: <TaskIcon fontSize="large" />,
// // // //       color: "#0288d1", // Light Blue
// // // //     },
// // // //     {
// // // //       id: 'correction',
// // // //       text: "Request Correction",
// // // //       description: "Report process deviations or request supervisor aid.",
// // // //       icon: <AlertIcon fontSize="large" />,
// // // //       color: "#ed6c02", // Warning Orange
// // // //     },
// // // //   ];

// // // //   // -- Render Helper --
// // // //   const renderContent = () => {
// // // //     switch (selectedView?.id) {
// // // //       case 'tasks':
// // // //         return <TaskListView tasks={tasks} onComplete={handleComplete} />;
// // // //       case 'correction':
// // // //         return <CorrectionRequestView correction={correction} setCorrection={setCorrection} onSubmit={handleRequestCorrection} />;
// // // //       default:
// // // //         return <HomeCardGrid />;
// // // //     }
// // // //   };

// // // //   // -- Home Grid Component --
// // // //   const HomeCardGrid = () => (
// // // //     <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
// // // //       <Box sx={{ mb: 5, textAlign: 'center' }}>
// // // //         <Typography variant="h4" component="h1" gutterBottom fontWeight="bold" color="text.primary">
// // // //           Operator Dashboard
// // // //         </Typography>
// // // //         <Typography variant="subtitle1" color="text.secondary">
// // // //           Select an action to proceed with your shift duties.
// // // //         </Typography>
// // // //       </Box>

// // // //       <Grid container spacing={4} justifyContent="center">
// // // //         {menuItems.map((item) => (
// // // //           <Grid item key={item.id} xs={12} sm={6} md={5}>
// // // //             <Card
// // // //               elevation={2}
// // // //               sx={{
// // // //                 height: "100%",
// // // //                 borderRadius: 4,
// // // //                 transition: "transform 0.3s, box-shadow 0.3s",
// // // //                 "&:hover": {
// // // //                   transform: "translateY(-5px)",
// // // //                   boxShadow: theme.shadows[8],
// // // //                   "& .MuiAvatar-root": {
// // // //                       backgroundColor: item.color,
// // // //                       color: "white"
// // // //                   }
// // // //                 },
// // // //               }}
// // // //             >
// // // //               <CardActionArea
// // // //                 onClick={() => setSelectedView(item)}
// // // //                 sx={{ height: "100%", p: 3 }}
// // // //               >
// // // //                 <CardContent sx={{ display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center" }}>
// // // //                   <Avatar
// // // //                     sx={{
// // // //                       bgcolor: theme.palette.grey[100],
// // // //                       color: item.color,
// // // //                       width: 80,
// // // //                       height: 80,
// // // //                       mb: 2,
// // // //                       transition: "all 0.3s ease",
// // // //                     }}
// // // //                   >
// // // //                     {item.icon}
// // // //                   </Avatar>
// // // //                   <Typography variant="h5" component="div" fontWeight="bold" gutterBottom>
// // // //                     {item.text}
// // // //                   </Typography>
// // // //                   <Typography variant="body1" color="text.secondary">
// // // //                     {item.description}
// // // //                   </Typography>
// // // //                 </CardContent>
// // // //               </CardActionArea>
// // // //             </Card>
// // // //           </Grid>
// // // //         ))}
// // // //       </Grid>
// // // //     </Container>
// // // //   );

// // // //   return (
// // // //     <Box sx={{ display: "flex", flexDirection: "column", minHeight: "100vh", bgcolor: "#f4f6f8" }}>
      
// // // //       {/* Top App Bar */}
// // // //       <AppBar
// // // //         position="sticky"
// // // //         elevation={0}
// // // //         sx={{
// // // //           backgroundColor: theme.palette.background.paper,
// // // //           color: theme.palette.text.primary,
// // // //           borderBottom: `1px solid ${theme.palette.divider}`
// // // //         }}
// // // //       >
// // // //         <Toolbar>
// // // //           {/* Back / Home Logic */}
// // // //           {selectedView ? (
// // // //             <Tooltip title="Back to Dashboard">
// // // //               <IconButton edge="start" color="primary" onClick={handleBackToHome} sx={{ mr: 2 }}>
// // // //                 <ArrowBackIcon />
// // // //               </IconButton>
// // // //             </Tooltip>
// // // //           ) : (
// // // //             <IconButton edge="start" color="primary" sx={{ mr: 2, cursor: 'default' }}>
// // // //               <HomeIcon />
// // // //             </IconButton>
// // // //           )}

// // // //           <Typography variant="h6" component="div" sx={{ flexGrow: 1, fontWeight: 600 }}>
// // // //             {selectedView ? selectedView.text : "Shop Floor Control"}
// // // //           </Typography>

// // // //           <Button 
// // // //             color="error" 
// // // //             onClick={onLogout} 
// // // //             startIcon={<LogoutIcon />}
// // // //             sx={{ fontWeight: 'bold' }}
// // // //           >
// // // //             Logout
// // // //           </Button>
// // // //         </Toolbar>
// // // //       </AppBar>

// // // //       {/* Main Content Area */}
// // // //       <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
// // // //         {/* If a view is selected, wrap it in a box with white bg, otherwise show grid */}
// // // //         {selectedView ? (
// // // //           <Box sx={{ bgcolor: theme.palette.background.paper, p: 4, borderRadius: 2, boxShadow: 1, minHeight: '80vh' }}>
// // // //             {renderContent()}
// // // //           </Box>
// // // //         ) : (
// // // //           renderContent()
// // // //         )}
// // // //       </Box>

// // // //       {/* Notification Snackbar */}
// // // //       <Snackbar
// // // //         open={openSnackbar}
// // // //         autoHideDuration={3000}
// // // //         onClose={() => setOpenSnackbar(false)}
// // // //         anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
// // // //       >
// // // //         <Alert onClose={() => setOpenSnackbar(false)} severity="success" variant="filled" sx={{ width: '100%' }}>
// // // //           {snackbarMsg}
// // // //         </Alert>
// // // //       </Snackbar>
// // // //     </Box>
// // // //   );
// // // // };

// // // // export default OperatorPage;


// // // import React, { useState, useMemo } from "react";
// // // import axios from "axios"; // Ensure axios is installed
// // // import {
// // //   Box,
// // //   Typography,
// // //   Button,
// // //   Card,
// // //   CardContent,
// // //   Table,
// // //   TableBody,
// // //   TableCell,
// // //   TableHead,
// // //   TableRow,
// // //   Paper,
// // //   Snackbar,
// // //   Alert,
// // //   AppBar,
// // //   Toolbar,
// // //   IconButton,
// // //   Container,
// // //   Avatar,
// // //   Tooltip,
// // //   useTheme,
// // //   Chip,
// // //   Tabs,
// // //   Tab,
// // //   Dialog,
// // //   DialogContent,
// // //   DialogTitle,
// // //   Stack,
// // //   CardActionArea,
// // //   Grid,
// // //   TableContainer
// // // } from "@mui/material";
// // // import {
// // //   Logout as LogoutIcon,
// // //   ArrowBack as ArrowBackIcon,
// // //   Home as HomeIcon,
// // //   CheckCircle as CheckCircleIcon,
// // //   PlayArrow as PlayArrowIcon,
// // //   AccessTime as AccessTimeIcon,
// // //   Refresh as RefreshIcon,
// // //   Assignment as FormIcon,
// // //   Lock as LockIcon
// // // } from "@mui/icons-material";

// // // // Import your existing component
// // // import ProcessFormPage from "./ProcessForms/ProcessFormPage";

// // // // --- API Helper for Status Update ---
// // // const updatePCBStatusAPI = async (pcbSerial, stageId, status) => {
// // //   try {
// // //     // Calling the specific API you requested
// // //     await axios.post("http://127.0.0.1:8081/api/pcb/update-status", {
// // //       pcbId: pcbSerial,
// // //       stageId: stageId,
// // //       status: status,
// // //       timestamp: new Date().toISOString()
// // //     });
// // //   } catch (error) {
// // //     console.error("Failed to update status API:", error);
// // //     // We don't block the UI here, but you might want to show an error alert
// // //   }
// // // };

// // // // --- Sub-Component: Form Dialog ---
// // // const ProcessFormDialog = ({ open, setOpen, activeForm, currentUser, onSaveSuccess }) => {
// // //   if (!activeForm) return null;

// // //   return (
// // //     <Dialog open={open} onClose={() => setOpen(false)} maxWidth="md" fullWidth>
// // //       <DialogTitle sx={{ bgcolor: "#f5f5f5", borderBottom: 1, borderColor: "divider" }}>
// // //         Process Task: {activeForm.stageName} ({activeForm.pcbSerial})
// // //       </DialogTitle>
// // //       <DialogContent sx={{ mt: 2 }}>
// // //         <ProcessFormPage
// // //           pcbSerial={activeForm.pcbSerial}
// // //           stageId={activeForm.stageId} // This matches the keys in formConfigs.js
// // //           operator={currentUser}
// // //           onSaveComplete={() => {
// // //             onSaveSuccess(activeForm.pcbSerial, activeForm.stageId);
// // //             setOpen(false);
// // //           }}
// // //         />
// // //       </DialogContent>
// // //     </Dialog>
// // //   );
// // // };

// // // // --- Sub-Component: Task Tabs View ---
// // // const TaskTabsView = ({ currentUser, inActionPCBs, onOpenForm }) => {
// // //   const [activeTab, setActiveTab] = useState(0);

// // //   // 1. Derive Unique Stages (Tabs) assigned to this user
// // //   const myStages = useMemo(() => {
// // //     const staffId = currentUser?.staffNumber || "";
// // //     const uniqueMap = new Map();

// // //     inActionPCBs.forEach((pcb) => {
// // //       (pcb.linkedOperations || []).forEach((op) => {
// // //         // Filter tasks assigned to current user
// // //         if (op.assignedTo && op.assignedTo.includes(staffId)) {
// // //           const id = String(op.sno || op["S.No"]); // Ensure ID is string for matching formConfigs
// // //           if (!uniqueMap.has(id)) {
// // //             uniqueMap.set(id, { 
// // //               id: id, 
// // //               name: op.name || op["Operation Name"] 
// // //             });
// // //           }
// // //         }
// // //       });
// // //     });

// // //     return Array.from(uniqueMap.values()).sort((a, b) => parseInt(a.id) - parseInt(b.id));
// // //   }, [inActionPCBs, currentUser]);

// // //   // 2. Get PCBs for the Active Tab
// // //   const currentRows = useMemo(() => {
// // //     if (myStages.length === 0) return [];
// // //     const targetStageId = myStages[activeTab]?.id;

// // //     const rows = [];
// // //     inActionPCBs.forEach((pcb) => {
// // //       const ops = pcb.linkedOperations || [];
// // //       const op = ops.find(o => String(o.sno || o["S.No"]) === targetStageId);

// // //       if (op) {
// // //         // Determine Logic: Is it locked?
// // //         const opIndex = ops.indexOf(op);
// // //         let isLocked = false;
// // //         if (opIndex > 0 && ops[opIndex - 1].status !== "Completed") {
// // //           isLocked = true;
// // //         }

// // //         rows.push({
// // //           pcbSerial: pcb["PCB Serial Number"] || pcb.serial_number || pcb._pcb_key_id,
// // //           opStatus: op.status || "Pending",
// // //           startTime: op.startTime,
// // //           endTime: op.endTime,
// // //           isLocked: isLocked,
// // //           stageName: op.name,
// // //           stageId: targetStageId
// // //         });
// // //       }
// // //     });

// // //     return rows;
// // //   }, [myStages, activeTab, inActionPCBs]);

// // //   if (myStages.length === 0) {
// // //     return (
// // //       <Paper sx={{ p: 4, textAlign: "center" }}>
// // //         <Typography color="text.secondary">No active tasks assigned to you.</Typography>
// // //       </Paper>
// // //     );
// // //   }

// // //   return (
// // //     <Box>
// // //       {/* TABS HEADER */}
// // //       <Paper elevation={0} sx={{ mb: 2, borderBottom: 1, borderColor: "divider" }}>
// // //         <Tabs 
// // //           value={activeTab} 
// // //           onChange={(e, v) => setActiveTab(v)}
// // //           variant="scrollable"
// // //           scrollButtons="auto"
// // //         >
// // //           {myStages.map((stage) => (
// // //             <Tab key={stage.id} label={`${stage.id}. ${stage.name}`} />
// // //           ))}
// // //         </Tabs>
// // //       </Paper>

// // //       {/* TABLE CONTENT */}
// // //       <TableContainer component={Paper} elevation={1} sx={{ border: "1px solid #e0e0e0" }}>
// // //         <Table>
// // //           <TableHead sx={{ bgcolor: "#f5f5f5" }}>
// // //             <TableRow>
// // //               <TableCell><strong>PCB Serial</strong></TableCell>
// // //               <TableCell><strong>Status</strong></TableCell>
// // //               <TableCell><strong>Timing</strong></TableCell>
// // //               <TableCell align="right"><strong>Action</strong></TableCell>
// // //             </TableRow>
// // //           </TableHead>
// // //           <TableBody>
// // //             {currentRows.map((row) => {
// // //               const isDone = row.opStatus === "Completed";
// // //               const inProgress = row.opStatus === "In Progress";
              
// // //               return (
// // //                 <TableRow key={row.pcbSerial} hover>
// // //                   <TableCell>
// // //                     <Typography fontWeight="bold">{row.pcbSerial}</Typography>
// // //                     {row.isLocked && (
// // //                       <Chip icon={<LockIcon />} label="Locked" size="small" sx={{ mt: 0.5 }} />
// // //                     )}
// // //                   </TableCell>
                  
// // //                   <TableCell>
// // //                     <Chip 
// // //                       label={row.opStatus} 
// // //                       color={isDone ? "success" : inProgress ? "warning" : "default"}
// // //                       size="small" 
// // //                       variant={inProgress ? "filled" : "outlined"}
// // //                     />
// // //                   </TableCell>

// // //                   <TableCell>
// // //                     <Stack spacing={0.5}>
// // //                        {row.startTime && (
// // //                          <Typography variant="caption" display="block">
// // //                            Start: {new Date(row.startTime).toLocaleTimeString()}
// // //                          </Typography>
// // //                        )}
// // //                        {row.endTime && (
// // //                          <Typography variant="caption" color="success.main" display="block">
// // //                            End: {new Date(row.endTime).toLocaleTimeString()}
// // //                          </Typography>
// // //                        )}
// // //                     </Stack>
// // //                   </TableCell>

// // //                   <TableCell align="right">
// // //                     <Button
// // //                       variant={isDone ? "outlined" : "contained"}
// // //                       color={isDone ? "success" : "primary"}
// // //                       size="small"
// // //                       startIcon={isDone ? <CheckCircleIcon /> : <FormIcon />}
// // //                       disabled={row.isLocked}
// // //                       onClick={() => onOpenForm(row)}
// // //                     >
// // //                       {isDone ? "View / Edit" : "Process Task"}
// // //                     </Button>
// // //                   </TableCell>
// // //                 </TableRow>
// // //               );
// // //             })}
// // //           </TableBody>
// // //         </Table>
// // //       </TableContainer>
// // //     </Box>
// // //   );
// // // };

// // // // --- Main Page Component ---
// // // const OperatorPage = ({ currentUser, inActionPCBs, updateInActionPCBs, onLogout }) => {
// // //   const theme = useTheme();
  
// // //   // -- State --
// // //   const [selectedView, setSelectedView] = useState(null); // 'tasks' or null (home)
// // //   const [openFormDialog, setOpenFormDialog] = useState(false);
// // //   const [activeFormData, setActiveFormData] = useState(null);
// // //   const [snackbar, setSnackbar] = useState({ open: false, msg: "" });

// // //   // -- Handlers --

// // //   // 1. Open the Dialog
// // //   const handleOpenForm = (row) => {
// // //     setActiveFormData(row);
// // //     setOpenFormDialog(true);
// // //   };

// // //   // 2. Handle Successful Save (Called from ProcessFormPage)
// // //   const handleSaveSuccess = async (pcbSerial, stageId) => {
// // //     const now = new Date().toISOString();

// // //     // A. Update Local State (Auto-fill table)
// // //     updateInActionPCBs((prev) => prev.map((pcb) => {
// // //       const currentSerial = pcb["PCB Serial Number"] || pcb.serial_number || pcb._pcb_key_id;
// // //       if (currentSerial !== pcbSerial) return pcb;

// // //       // Update the specific operation in the list
// // //       const newOps = (pcb.linkedOperations || []).map((op) => {
// // //         if (String(op.sno || op["S.No"]) === String(stageId)) {
// // //           return {
// // //             ...op,
// // //             status: "Completed",
// // //             endTime: now,
// // //             startTime: op.startTime || now // Ensure start time is filled if missed
// // //           };
// // //         }
// // //         return op;
// // //       });

// // //       return { ...pcb, linkedOperations: newOps };
// // //     }));

// // //     // B. Call the Status Update API provided
// // //     await updatePCBStatusAPI(pcbSerial, stageId, "Completed");

// // //     setSnackbar({ open: true, msg: "Task saved & updated successfully!" });
// // //   };

// // //   // -- Navigation Helper --
// // //   const renderContent = () => {
// // //     if (selectedView === 'tasks') {
// // //       return (
// // //         <TaskTabsView 
// // //           currentUser={currentUser}
// // //           inActionPCBs={inActionPCBs}
// // //           onOpenForm={handleOpenForm}
// // //         />
// // //       );
// // //     }
    
// // //     // Default Home Grid
// // //     return (
// // //       <Container maxWidth="lg" sx={{ mt: 4 }}>
// // //          <Grid container spacing={4} justifyContent="center">
// // //             <Grid item xs={12} sm={6} md={5}>
// // //                <Card 
// // //                  elevation={3} 
// // //                  sx={{ borderRadius: 4, height: '100%', transition: '0.3s', '&:hover': { transform: 'translateY(-5px)' } }}
// // //                >
// // //                  <CardActionArea onClick={() => setSelectedView('tasks')} sx={{ height: '100%', p: 4 }}>
// // //                    <CardContent sx={{ textAlign: 'center' }}>
// // //                      <Avatar sx={{ bgcolor: theme.palette.primary.main, width: 80, height: 80, mb: 3, mx: 'auto' }}>
// // //                        <FormIcon fontSize="large" />
// // //                      </Avatar>
// // //                      <Typography variant="h5" fontWeight="bold" gutterBottom>My Tasks</Typography>
// // //                      <Typography color="text.secondary">View assigned stages and process pending PCBs.</Typography>
// // //                    </CardContent>
// // //                  </CardActionArea>
// // //                </Card>
// // //             </Grid>
// // //          </Grid>
// // //       </Container>
// // //     );
// // //   };

// // //   return (
// // //     <Box sx={{ display: "flex", flexDirection: "column", minHeight: "100vh", bgcolor: "#f4f6f8" }}>
      
// // //       {/* App Bar */}
// // //       <AppBar position="sticky" color="default" elevation={0} sx={{ borderBottom: 1, borderColor: "divider" }}>
// // //         <Toolbar>
// // //           {selectedView ? (
// // //             <IconButton onClick={() => setSelectedView(null)} color="primary" sx={{ mr: 2 }}>
// // //               <ArrowBackIcon />
// // //             </IconButton>
// // //           ) : (
// // //             <IconButton color="primary" sx={{ mr: 2, cursor: "default" }}>
// // //               <HomeIcon />
// // //             </IconButton>
// // //           )}
          
// // //           <Typography variant="h6" sx={{ flexGrow: 1, fontWeight: "bold" }}>
// // //             {selectedView === 'tasks' ? "My Tasks" : "Operator Dashboard"}
// // //           </Typography>

// // //           <Button color="error" startIcon={<LogoutIcon />} onClick={onLogout}>
// // //             Logout
// // //           </Button>
// // //         </Toolbar>
// // //       </AppBar>

// // //       {/* Main Content */}
// // //       <Box sx={{ flexGrow: 1, p: 3 }}>
// // //         {selectedView === 'tasks' ? (
// // //           <Box sx={{ bgcolor: "white", p: 3, borderRadius: 2, boxShadow: 1, minHeight: "80vh" }}>
// // //             {renderContent()}
// // //           </Box>
// // //         ) : (
// // //           renderContent()
// // //         )}
// // //       </Box>

// // //       {/* Dynamic Form Dialog */}
// // //       <ProcessFormDialog 
// // //         open={openFormDialog}
// // //         setOpen={setOpenFormDialog}
// // //         activeForm={activeFormData}
// // //         currentUser={currentUser}
// // //         onSaveSuccess={handleSaveSuccess}
// // //       />

// // //       {/* Notifications */}
// // //       <Snackbar
// // //         open={snackbar.open}
// // //         autoHideDuration={3000}
// // //         onClose={() => setSnackbar({ ...snackbar, open: false })}
// // //         anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
// // //       >
// // //         <Alert severity="success" variant="filled">{snackbar.msg}</Alert>
// // //       </Snackbar>

// // //     </Box>
// // //   );
// // // };

// // // export default OperatorPage;

// // import React, { useState, useMemo } from "react";
// // import axios from "axios"; 
// // import {
// //   Box,
// //   Typography,
// //   Button,
// //   Card,
// //   CardContent,
// //   Table,
// //   TableBody,
// //   TableCell,
// //   TableHead,
// //   TableRow,
// //   Paper,
// //   Snackbar,
// //   Alert,
// //   AppBar,
// //   Toolbar,
// //   IconButton,
// //   Container,
// //   Avatar,
// //   CardActionArea,
// //   Grid,
// //   Chip,
// //   Tabs,
// //   Tab,
// //   Dialog,
// //   DialogContent,
// //   DialogTitle,
// //   Stack,
// //   TableContainer
// // } from "@mui/material";
// // import {
// //   Logout as LogoutIcon,
// //   ArrowBack as ArrowBackIcon,
// //   Home as HomeIcon,
// //   CheckCircle as CheckCircleIcon,
// //   Assignment as FormIcon,
// //   Lock as LockIcon
// // } from "@mui/icons-material";

// // // Import your existing component
// // import ProcessFormPage from "./ProcessForms/ProcessFormPage"

// // // --- API Helper for Status Update ---
// // const updatePCBStatusAPI = async (pcbSerial, stageId, status) => {
// //   try {
// //     await axios.post("http://127.0.0.1:8081/api/pcb", {
// //       pcbId: pcbSerial,
// //       stageId: stageId,
// //       status: status,
// //       timestamp: new Date().toISOString()
// //     });
// //   } catch (error) {
// //     console.error("Failed to update status API:", error);
// //   }
// // };

// // // --- Sub-Component: Form Dialog ---
// // const ProcessFormDialog = ({ open, setOpen, activeForm, currentUser, onSaveSuccess }) => {
// //   if (!activeForm) return null;

// //   return (
// //     <Dialog open={open} onClose={() => setOpen(false)} maxWidth="md" fullWidth>
// //       <DialogTitle sx={{ bgcolor: "#f5f5f5", borderBottom: 1, borderColor: "divider" }}>
// //         Process Task: {activeForm.stageName} ({activeForm.pcbSerial})
// //       </DialogTitle>
// //       <DialogContent sx={{ mt: 2 }}>
// //         <ProcessFormPage
// //           pcbSerial={activeForm.pcbSerial}
// //           stageId={activeForm.stageId} 
// //           operator={currentUser}
// //           onSaveComplete={() => {
// //             onSaveSuccess(activeForm.pcbSerial, activeForm.stageId);
// //             setOpen(false);
// //           }}
// //         />
// //       </DialogContent>
// //     </Dialog>
// //   );
// // };

// // // --- Sub-Component: Task Tabs View ---
// // const TaskTabsView = ({ currentUser, inActionPCBs = [], onOpenForm }) => { // ✅ Added default []
// //   const [activeTab, setActiveTab] = useState(0);

// //   // 1. Derive Unique Stages (Tabs)
// //   const myStages = useMemo(() => {
// //     const staffId = currentUser?.staffNumber || "";
// //     const uniqueMap = new Map();

// //     // ✅ SAFETY CHECK: (inActionPCBs || [])
// //     (inActionPCBs || []).forEach((pcb) => {
// //       (pcb.linkedOperations || []).forEach((op) => {
// //         if (op.assignedTo && op.assignedTo.includes(staffId)) {
// //           const id = String(op.sno || op["S.No"]); 
// //           if (!uniqueMap.has(id)) {
// //             uniqueMap.set(id, { 
// //               id: id, 
// //               name: op.name || op["Operation Name"] 
// //             });
// //           }
// //         }
// //       });
// //     });

// //     return Array.from(uniqueMap.values()).sort((a, b) => parseInt(a.id) - parseInt(b.id));
// //   }, [inActionPCBs, currentUser]);

// //   // 2. Get PCBs for the Active Tab
// //   const currentRows = useMemo(() => {
// //     if (!myStages || myStages.length === 0) return [];
    
// //     // Safety check for activeTab index
// //     const activeStage = myStages[activeTab];
// //     if (!activeStage) return [];

// //     const targetStageId = activeStage.id;
// //     const rows = [];

// //     // ✅ SAFETY CHECK: (inActionPCBs || [])
// //     (inActionPCBs || []).forEach((pcb) => {
// //       const ops = pcb.linkedOperations || [];
// //       const op = ops.find(o => String(o.sno || o["S.No"]) === targetStageId);

// //       if (op) {
// //         const opIndex = ops.indexOf(op);
// //         let isLocked = false;
// //         // Check if previous stage is completed
// //         if (opIndex > 0 && ops[opIndex - 1].status !== "Completed") {
// //           isLocked = true;
// //         }

// //         rows.push({
// //           pcbSerial: pcb["PCB Serial Number"] || pcb.serial_number || pcb._pcb_key_id,
// //           opStatus: op.status || "Pending",
// //           startTime: op.startTime,
// //           endTime: op.endTime,
// //           isLocked: isLocked,
// //           stageName: op.name,
// //           stageId: targetStageId
// //         });
// //       }
// //     });

// //     return rows;
// //   }, [myStages, activeTab, inActionPCBs]);

// //   if (myStages.length === 0) {
// //     return (
// //       <Paper sx={{ p: 4, textAlign: "center" }}>
// //         <Typography color="text.secondary">No active tasks assigned to you.</Typography>
// //       </Paper>
// //     );
// //   }

// //   return (
// //     <Box>
// //       <Paper elevation={0} sx={{ mb: 2, borderBottom: 1, borderColor: "divider" }}>
// //         <Tabs 
// //           value={activeTab} 
// //           onChange={(e, v) => setActiveTab(v)}
// //           variant="scrollable"
// //           scrollButtons="auto"
// //         >
// //           {myStages.map((stage) => (
// //             <Tab key={stage.id} label={`${stage.id}. ${stage.name}`} />
// //           ))}
// //         </Tabs>
// //       </Paper>

// //       <TableContainer component={Paper} elevation={1} sx={{ border: "1px solid #e0e0e0" }}>
// //         <Table>
// //           <TableHead sx={{ bgcolor: "#f5f5f5" }}>
// //             <TableRow>
// //               <TableCell><strong>PCB Serial</strong></TableCell>
// //               <TableCell><strong>Status</strong></TableCell>
// //               <TableCell><strong>Timing</strong></TableCell>
// //               <TableCell align="right"><strong>Action</strong></TableCell>
// //             </TableRow>
// //           </TableHead>
// //           <TableBody>
// //             {currentRows.map((row) => {
// //               const isDone = row.opStatus === "Completed";
// //               const inProgress = row.opStatus === "In Progress";
              
// //               return (
// //                 <TableRow key={row.pcbSerial} hover>
// //                   <TableCell>
// //                     <Typography fontWeight="bold">{row.pcbSerial}</Typography>
// //                     {row.isLocked && (
// //                       <Chip icon={<LockIcon />} label="Locked" size="small" sx={{ mt: 0.5 }} />
// //                     )}
// //                   </TableCell>
                  
// //                   <TableCell>
// //                     <Chip 
// //                       label={row.opStatus} 
// //                       color={isDone ? "success" : inProgress ? "warning" : "default"}
// //                       size="small" 
// //                       variant={inProgress ? "filled" : "outlined"}
// //                     />
// //                   </TableCell>

// //                   <TableCell>
// //                     <Stack spacing={0.5}>
// //                        {row.startTime && (
// //                          <Typography variant="caption" display="block">
// //                            Start: {new Date(row.startTime).toLocaleTimeString()}
// //                          </Typography>
// //                        )}
// //                        {row.endTime && (
// //                          <Typography variant="caption" color="success.main" display="block">
// //                            End: {new Date(row.endTime).toLocaleTimeString()}
// //                          </Typography>
// //                        )}
// //                     </Stack>
// //                   </TableCell>

// //                   <TableCell align="right">
// //                     <Button
// //                       variant={isDone ? "outlined" : "contained"}
// //                       color={isDone ? "success" : "primary"}
// //                       size="small"
// //                       startIcon={isDone ? <CheckCircleIcon /> : <FormIcon />}
// //                       disabled={row.isLocked}
// //                       onClick={() => onOpenForm(row)}
// //                     >
// //                       {isDone ? "View / Edit" : "Process Task"}
// //                     </Button>
// //                   </TableCell>
// //                 </TableRow>
// //               );
// //             })}
// //           </TableBody>
// //         </Table>
// //       </TableContainer>
// //     </Box>
// //   );
// // };

// // // --- Main Page Component ---
// // const OperatorPage = ({ currentUser, inActionPCBs = [], updateInActionPCBs, onLogout }) => { // ✅ Added default []
// //   const [selectedView, setSelectedView] = useState(null); 
// //   const [openFormDialog, setOpenFormDialog] = useState(false);
// //   const [activeFormData, setActiveFormData] = useState(null);
// //   const [snackbar, setSnackbar] = useState({ open: false, msg: "" });

// //   const handleOpenForm = (row) => {
// //     setActiveFormData(row);
// //     setOpenFormDialog(true);
// //   };

// //   const handleSaveSuccess = async (pcbSerial, stageId) => {
// //     const now = new Date().toISOString();

// //     if (updateInActionPCBs) {
// //         updateInActionPCBs((prev) => (prev || []).map((pcb) => { // ✅ Added safety check here too
// //         const currentSerial = pcb["PCB Serial Number"] || pcb.serial_number || pcb._pcb_key_id;
// //         if (currentSerial !== pcbSerial) return pcb;

// //         const newOps = (pcb.linkedOperations || []).map((op) => {
// //             if (String(op.sno || op["S.No"]) === String(stageId)) {
// //             return {
// //                 ...op,
// //                 status: "Completed",
// //                 endTime: now,
// //                 startTime: op.startTime || now 
// //             };
// //             }
// //             return op;
// //         });

// //         return { ...pcb, linkedOperations: newOps };
// //         }));
// //     }

// //     await updatePCBStatusAPI(pcbSerial, stageId, "Completed");
// //     setSnackbar({ open: true, msg: "Task saved & updated successfully!" });
// //   };

// //   const renderContent = () => {
// //     if (selectedView === 'tasks') {
// //       return (
// //         <TaskTabsView 
// //           currentUser={currentUser}
// //           inActionPCBs={inActionPCBs}
// //           onOpenForm={handleOpenForm}
// //         />
// //       );
// //     }
    
// //     return (
// //       <Container maxWidth="lg" sx={{ mt: 4 }}>
// //          <Grid container spacing={4} justifyContent="center">
// //             <Grid item xs={12} sm={6} md={5}>
// //                <Card 
// //                  elevation={3} 
// //                  sx={{ borderRadius: 4, height: '100%', transition: '0.3s', '&:hover': { transform: 'translateY(-5px)' } }}
// //                >
// //                  <CardActionArea onClick={() => setSelectedView('tasks')} sx={{ height: '100%', p: 4 }}>
// //                    <CardContent sx={{ textAlign: 'center' }}>
// //                      <Avatar sx={{ bgcolor: "#1976d2", width: 80, height: 80, mb: 3, mx: 'auto' }}>
// //                        <FormIcon fontSize="large" />
// //                      </Avatar>
// //                      <Typography variant="h5" fontWeight="bold" gutterBottom>My Tasks</Typography>
// //                      <Typography color="text.secondary">View assigned stages and process pending PCBs.</Typography>
// //                    </CardContent>
// //                  </CardActionArea>
// //                </Card>
// //             </Grid>
// //          </Grid>
// //       </Container>
// //     );
// //   };

// //   return (
// //     <Box sx={{ display: "flex", flexDirection: "column", minHeight: "100vh", bgcolor: "#f4f6f8" }}>
      
// //       <AppBar position="sticky" color="default" elevation={0} sx={{ borderBottom: 1, borderColor: "divider" }}>
// //         <Toolbar>
// //           {selectedView ? (
// //             <IconButton onClick={() => setSelectedView(null)} color="primary" sx={{ mr: 2 }}>
// //               <ArrowBackIcon />
// //             </IconButton>
// //           ) : (
// //             <IconButton color="primary" sx={{ mr: 2, cursor: "default" }}>
// //               <HomeIcon />
// //             </IconButton>
// //           )}
          
// //           <Typography variant="h6" sx={{ flexGrow: 1, fontWeight: "bold" }}>
// //             {selectedView === 'tasks' ? "My Tasks" : "Operator Dashboard"}
// //           </Typography>

// //           <Button color="error" startIcon={<LogoutIcon />} onClick={onLogout}>
// //             Logout
// //           </Button>
// //         </Toolbar>
// //       </AppBar>

// //       <Box sx={{ flexGrow: 1, p: 3 }}>
// //         {selectedView === 'tasks' ? (
// //           <Box sx={{ bgcolor: "white", p: 3, borderRadius: 2, boxShadow: 1, minHeight: "80vh" }}>
// //             {renderContent()}
// //           </Box>
// //         ) : (
// //           renderContent()
// //         )}
// //       </Box>

// //       <ProcessFormDialog 
// //         open={openFormDialog}
// //         setOpen={setOpenFormDialog}
// //         activeForm={activeFormData}
// //         currentUser={currentUser}
// //         onSaveSuccess={handleSaveSuccess}
// //       />

// //       <Snackbar
// //         open={snackbar.open}
// //         autoHideDuration={3000}
// //         onClose={() => setSnackbar({ ...snackbar, open: false })}
// //         anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
// //       >
// //         <Alert severity="success" variant="filled">{snackbar.msg}</Alert>
// //       </Snackbar>

// //     </Box>
// //   );
// // };

// // export default OperatorPage;

// import React, { useState, useMemo } from "react";
// import axios from "axios"; 
// import {
//   Box,
//   Typography,
//   Button,
//   Card,
//   CardContent,
//   Table,
//   TableBody,
//   TableCell,
//   TableHead,
//   TableRow,
//   Paper,
//   Snackbar,
//   Alert,
//   AppBar,
//   Toolbar,
//   IconButton,
//   Container,
//   Avatar,
//   CardActionArea,
//   Grid,
//   Chip,
//   Tabs,
//   Tab,
//   Dialog,
//   DialogContent,
//   DialogTitle,
//   Stack,
//   TableContainer
// } from "@mui/material";
// import {
//   Logout as LogoutIcon,
//   ArrowBack as ArrowBackIcon,
//   Home as HomeIcon,
//   CheckCircle as CheckCircleIcon,
//   Assignment as FormIcon,
//   Lock as LockIcon
// } from "@mui/icons-material";

// // Import your existing component
// import ProcessFormPage from "./ProcessForms/ProcessFormPage"

// // --- 1. DUMMY DATA FOR TESTING ---
// const DUMMY_USER = {
//   name: "Demo Operator",
//   staffNumber: "OP-101" // <--- This ID matches the assignments below
// };

// const DUMMY_PCBS = [
//   {
//     "PCB Serial Number": "SN-2023-001",
//     linkedOperations: [
//       {
//         "S.No": "1",
//         "Operation Name": "Labelling & Traceability",
//         assignedTo: ["OP-101"], // Assigned to our dummy user
//         status: "Pending",
//         startTime: null,
//         endTime: null
//       },
//       {
//         "S.No": "2",
//         "Operation Name": "Cleaning of Bare PCB",
//         assignedTo: ["OP-101"],
//         status: "Pending",
//         startTime: null,
//         endTime: null
//       }
//     ]
//   },
//   {
//     "PCB Serial Number": "SN-2023-005",
//     linkedOperations: [
//       {
//         "S.No": "1",
//         "Operation Name": "Labelling & Traceability",
//         assignedTo: ["OP-101"],
//         status: "Completed",
//         startTime: "2023-10-27T10:00:00.000Z",
//         endTime: "2023-10-27T10:15:00.000Z"
//       },
//       {
//         "S.No": "2",
//         "Operation Name": "Cleaning of Bare PCB",
//         assignedTo: ["OP-101"],
//         status: "Pending", // This should show up in tab 2
//         startTime: null,
//         endTime: null
//       }
//     ]
//   },
//   {
//     "PCB Serial Number": "SN-2023-008",
//     linkedOperations: [
//       {
//         "S.No": "4",
//         "Operation Name": "Solder Paste Printing",
//         assignedTo: ["OP-101"],
//         status: "Pending",
//         startTime: null,
//         endTime: null
//       }
//     ]
//   }
// ];

// // --- API Helper for Status Update ---
// const updatePCBStatusAPI = async (pcbSerial, stageId, status) => {
//   try {
//     // Assuming API_URL is defined globally or just use the direct link
//     // const API_URL = "http://127.0.0.1:8081/api"; 
//     await axios.post("http://127.0.0.1:8081/api/pcb/update-status", {
//       pcbId: pcbSerial,
//       stageId: stageId,
//       status: status,
//       timestamp: new Date().toISOString()
//     });
//   } catch (error) {
//     console.error("Failed to update status API:", error);
//   }
// };

// // --- Sub-Component: Form Dialog ---
// const ProcessFormDialog = ({ open, setOpen, activeForm, currentUser, onSaveSuccess }) => {
//   if (!activeForm) return null;

//   return (
//     <Dialog open={open} onClose={() => setOpen(false)} maxWidth="md" fullWidth>
//       <DialogTitle sx={{ bgcolor: "#f5f5f5", borderBottom: 1, borderColor: "divider" }}>
//         Process Task: {activeForm.stageName} ({activeForm.pcbSerial})
//       </DialogTitle>
//       <DialogContent sx={{ mt: 2 }}>
//         <ProcessFormPage
//           pcbSerial={activeForm.pcbSerial}
//           stageId={activeForm.stageId} 
//           operator={currentUser}
//           onSaveComplete={() => {
//             onSaveSuccess(activeForm.pcbSerial, activeForm.stageId);
//             setOpen(false);
//           }}
//         />
//       </DialogContent>
//     </Dialog>
//   );
// };

// // --- Sub-Component: Task Tabs View ---
// const TaskTabsView = ({ currentUser, inActionPCBs = [], onOpenForm }) => { 
//   const [activeTab, setActiveTab] = useState(0);

//   // 1. Derive Unique Stages (Tabs)
//   const myStages = useMemo(() => {
//     const staffId = currentUser?.staffNumber || "";
//     const uniqueMap = new Map();

//     (inActionPCBs || []).forEach((pcb) => {
//       (pcb.linkedOperations || []).forEach((op) => {
//         // Check assignment
//         if (op.assignedTo && op.assignedTo.includes(staffId)) {
//           const id = String(op.sno || op["S.No"]); 
//           if (!uniqueMap.has(id)) {
//             uniqueMap.set(id, { 
//               id: id, 
//               name: op.name || op["Operation Name"] 
//             });
//           }
//         }
//       });
//     });

//     return Array.from(uniqueMap.values()).sort((a, b) => parseInt(a.id) - parseInt(b.id));
//   }, [inActionPCBs, currentUser]);

//   // 2. Get PCBs for the Active Tab
//   const currentRows = useMemo(() => {
//     if (!myStages || myStages.length === 0) return [];
    
//     const activeStage = myStages[activeTab];
//     if (!activeStage) return [];

//     const targetStageId = activeStage.id;
//     const rows = [];

//     (inActionPCBs || []).forEach((pcb) => {
//       const ops = pcb.linkedOperations || [];
//       const op = ops.find(o => String(o.sno || o["S.No"]) === targetStageId);

//       if (op) {
//         const opIndex = ops.indexOf(op);
//         let isLocked = false;
//         // Check if previous stage is completed
//         if (opIndex > 0 && ops[opIndex - 1].status !== "Completed") {
//           isLocked = true;
//         }

//         rows.push({
//           pcbSerial: pcb["PCB Serial Number"] || pcb.serial_number || pcb._pcb_key_id,
//           opStatus: op.status || "Pending",
//           startTime: op.startTime,
//           endTime: op.endTime,
//           isLocked: isLocked,
//           stageName: op.name,
//           stageId: targetStageId
//         });
//       }
//     });

//     return rows;
//   }, [myStages, activeTab, inActionPCBs]);

//   if (myStages.length === 0) {
//     return (
//       <Paper sx={{ p: 4, textAlign: "center" }}>
//         <Typography color="text.secondary">No active tasks assigned to you.</Typography>
//         <Typography variant="caption">Debug: Current Staff ID is {currentUser?.staffNumber}</Typography>
//       </Paper>
//     );
//   }

//   return (
//     <Box>
//       <Paper elevation={0} sx={{ mb: 2, borderBottom: 1, borderColor: "divider" }}>
//         <Tabs 
//           value={activeTab} 
//           onChange={(e, v) => setActiveTab(v)}
//           variant="scrollable"
//           scrollButtons="auto"
//         >
//           {myStages.map((stage) => (
//             <Tab key={stage.id} label={`${stage.id}. ${stage.name}`} />
//           ))}
//         </Tabs>
//       </Paper>

//       <TableContainer component={Paper} elevation={1} sx={{ border: "1px solid #e0e0e0" }}>
//         <Table>
//           <TableHead sx={{ bgcolor: "#f5f5f5" }}>
//             <TableRow>
//               <TableCell><strong>PCB Serial</strong></TableCell>
//               <TableCell><strong>Status</strong></TableCell>
//               <TableCell><strong>Timing</strong></TableCell>
//               <TableCell align="right"><strong>Action</strong></TableCell>
//             </TableRow>
//           </TableHead>
//           <TableBody>
//             {currentRows.map((row) => {
//               const isDone = row.opStatus === "Completed";
//               const inProgress = row.opStatus === "In Progress";
              
//               return (
//                 <TableRow key={row.pcbSerial} hover>
//                   <TableCell>
//                     <Typography fontWeight="bold">{row.pcbSerial}</Typography>
//                     {row.isLocked && (
//                       <Chip icon={<LockIcon />} label="Locked" size="small" sx={{ mt: 0.5 }} />
//                     )}
//                   </TableCell>
                  
//                   <TableCell>
//                     <Chip 
//                       label={row.opStatus} 
//                       color={isDone ? "success" : inProgress ? "warning" : "default"}
//                       size="small" 
//                       variant={inProgress ? "filled" : "outlined"}
//                     />
//                   </TableCell>

//                   <TableCell>
//                     <Stack spacing={0.5}>
//                        {row.startTime && (
//                          <Typography variant="caption" display="block">
//                            Start: {new Date(row.startTime).toLocaleTimeString()}
//                          </Typography>
//                        )}
//                        {row.endTime && (
//                          <Typography variant="caption" color="success.main" display="block">
//                            End: {new Date(row.endTime).toLocaleTimeString()}
//                          </Typography>
//                        )}
//                     </Stack>
//                   </TableCell>

//                   <TableCell align="right">
//                     <Button
//                       variant={isDone ? "outlined" : "contained"}
//                       color={isDone ? "success" : "primary"}
//                       size="small"
//                       startIcon={isDone ? <CheckCircleIcon /> : <FormIcon />}
//                       disabled={row.isLocked}
//                       onClick={() => onOpenForm(row)}
//                     >
//                       {isDone ? "View / Edit" : "Process Task"}
//                     </Button>
//                   </TableCell>
//                 </TableRow>
//               );
//             })}
//           </TableBody>
//         </Table>
//       </TableContainer>
//     </Box>
//   );
// };

// // --- Main Page Component ---
// const OperatorPage = ({ currentUser, inActionPCBs, updateInActionPCBs, onLogout }) => {
  
//   // ✅ USE DUMMY DATA IF PROPS ARE MISSING
//   // This logic ensures you see data immediately even without backend connection
//   const activeUser = currentUser || DUMMY_USER;
//   const activePCBs = (inActionPCBs && inActionPCBs.length > 0) ? inActionPCBs : DUMMY_PCBS;

//   const [selectedView, setSelectedView] = useState(null); 
//   const [openFormDialog, setOpenFormDialog] = useState(false);
//   const [activeFormData, setActiveFormData] = useState(null);
//   const [snackbar, setSnackbar] = useState({ open: false, msg: "" });

//   const handleOpenForm = (row) => {
//     setActiveFormData(row);
//     setOpenFormDialog(true);
//   };

//   const handleSaveSuccess = async (pcbSerial, stageId) => {
//     const now = new Date().toISOString();

//     if (updateInActionPCBs) {
//         updateInActionPCBs((prev) => (prev || []).map((pcb) => { 
//         const currentSerial = pcb["PCB Serial Number"] || pcb.serial_number || pcb._pcb_key_id;
//         if (currentSerial !== pcbSerial) return pcb;

//         const newOps = (pcb.linkedOperations || []).map((op) => {
//             if (String(op.sno || op["S.No"]) === String(stageId)) {
//             return {
//                 ...op,
//                 status: "Completed",
//                 endTime: now,
//                 startTime: op.startTime || now 
//             };
//             }
//             return op;
//         });

//         return { ...pcb, linkedOperations: newOps };
//         }));
//     } else {
//         // Fallback for demo: alert the user since updateInActionPCBs prop is likely missing
//         console.log("Demo Update: Task Completed locally");
//     }

//     await updatePCBStatusAPI(pcbSerial, stageId, "Completed");
//     setSnackbar({ open: true, msg: "Task saved & updated successfully!" });
//   };

//   const renderContent = () => {
//     if (selectedView === 'tasks') {
//       return (
//         <TaskTabsView 
//           currentUser={activeUser}
//           inActionPCBs={activePCBs}
//           onOpenForm={handleOpenForm}
//         />
//       );
//     }
    
//     return (
//       <Container maxWidth="lg" sx={{ mt: 4 }}>
//          <Grid container spacing={4} justifyContent="center">
//             <Grid item xs={12} sm={6} md={5}>
//                <Card 
//                  elevation={3} 
//                  sx={{ borderRadius: 4, height: '100%', transition: '0.3s', '&:hover': { transform: 'translateY(-5px)' } }}
//                >
//                  <CardActionArea onClick={() => setSelectedView('tasks')} sx={{ height: '100%', p: 4 }}>
//                    <CardContent sx={{ textAlign: 'center' }}>
//                      <Avatar sx={{ bgcolor: "#1976d2", width: 80, height: 80, mb: 3, mx: 'auto' }}>
//                        <FormIcon fontSize="large" />
//                      </Avatar>
//                      <Typography variant="h5" fontWeight="bold" gutterBottom>My Tasks</Typography>
//                      <Typography color="text.secondary">View assigned stages and process pending PCBs.</Typography>
//                    </CardContent>
//                  </CardActionArea>
//                </Card>
//             </Grid>
//          </Grid>
//       </Container>
//     );
//   };

//   return (
//     <Box sx={{ display: "flex", flexDirection: "column", minHeight: "100vh", bgcolor: "#f4f6f8" }}>
      
//       <AppBar position="sticky" color="default" elevation={0} sx={{ borderBottom: 1, borderColor: "divider" }}>
//         <Toolbar>
//           {selectedView ? (
//             <IconButton onClick={() => setSelectedView(null)} color="primary" sx={{ mr: 2 }}>
//               <ArrowBackIcon />
//             </IconButton>
//           ) : (
//             <IconButton color="primary" sx={{ mr: 2, cursor: "default" }}>
//               <HomeIcon />
//             </IconButton>
//           )}
          
//           <Typography variant="h6" sx={{ flexGrow: 1, fontWeight: "bold" }}>
//             {selectedView === 'tasks' ? "My Tasks" : "Operator Dashboard"}
//           </Typography>
          
//           {/* Debug Info for Demo */}
//           <Typography variant="caption" sx={{ mr: 2, color: 'text.secondary', display: { xs: 'none', md: 'block' } }}>
//             Logged in as: {activeUser.name} ({activeUser.staffNumber})
//           </Typography>

//           <Button color="error" startIcon={<LogoutIcon />} onClick={onLogout}>
//             Logout
//           </Button>
//         </Toolbar>
//       </AppBar>

//       <Box sx={{ flexGrow: 1, p: 3 }}>
//         {selectedView === 'tasks' ? (
//           <Box sx={{ bgcolor: "white", p: 3, borderRadius: 2, boxShadow: 1, minHeight: "80vh" }}>
//             {renderContent()}
//           </Box>
//         ) : (
//           renderContent()
//         )}
//       </Box>

//       <ProcessFormDialog 
//         open={openFormDialog}
//         setOpen={setOpenFormDialog}
//         activeForm={activeFormData}
//         currentUser={activeUser}
//         onSaveSuccess={handleSaveSuccess}
//       />

//       <Snackbar
//         open={snackbar.open}
//         autoHideDuration={3000}
//         onClose={() => setSnackbar({ ...snackbar, open: false })}
//         anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
//       >
//         <Alert severity="success" variant="filled">{snackbar.msg}</Alert>
//       </Snackbar>

//     </Box>
//   );
// };

// export default OperatorPage;

import React, { useState, useMemo, useEffect } from "react";
import axios from "axios"; 
import {
  Box,
  Typography,
  Button,
  Card,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Paper,
  Snackbar,
  Alert,
  AppBar,
  Toolbar,
  IconButton,
  Container,
  Avatar,
  CardActionArea,
  Grid,
  Chip,
  Tabs,
  Tab,
  Dialog,
  DialogContent,
  DialogTitle,
  Stack,
  TableContainer
} from "@mui/material";
import {
  Logout as LogoutIcon,
  ArrowBack as ArrowBackIcon,
  Home as HomeIcon,
  CheckCircle as CheckCircleIcon,
  Assignment as FormIcon,
  Lock as LockIcon
} from "@mui/icons-material";

import ProcessFormPage from "./ProcessForms/ProcessFormPage"

// --- 1. DUMMY DATA ---
const DUMMY_USER = {
  name: "Demo Operator",
  staffNumber: "OP-101"
};

const DUMMY_PCBS = [
  {
    "PCB Serial Number": "SN-2023-001",
    linkedOperations: [
      {
        "S.No": "1",
        "Operation Name": "Labelling & Traceability",
        assignedTo: ["OP-101"],
        status: "Pending",
        startTime: null,
        endTime: null
      },
      {
        "S.No": "2",
        "Operation Name": "Cleaning of Bare PCB",
        assignedTo: ["OP-101"],
        status: "Pending",
        startTime: null,
        endTime: null
      }
    ]
  },
  {
    "PCB Serial Number": "SN-2023-005",
    linkedOperations: [
      {
        "S.No": "1",
        "Operation Name": "Labelling & Traceability",
        assignedTo: ["OP-101"],
        status: "Completed",
        startTime: "2023-10-27T10:00:00.000Z",
        endTime: "2023-10-27T10:15:00.000Z"
      },
      {
        "S.No": "2",
        "Operation Name": "Cleaning of Bare PCB",
        assignedTo: ["OP-101"],
        status: "Pending",
        startTime: null,
        endTime: null
      }
    ]
  }
];

// --- API Helper ---
const updatePCBStatusAPI = async (pcbSerial, stageId, status) => {
  try {
    const API_URL = "http://127.0.0.1:8081/api"; 
    await axios.post(`${API_URL}/pcb`, {
      pcbId: pcbSerial,
      stageId: stageId,
      status: status,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error("Failed to update status API:", error);
  }
};

// --- Sub-Component: Form Dialog ---
const ProcessFormDialog = ({ open, setOpen, activeForm, currentUser, onSaveSuccess }) => {
  if (!activeForm) return null;

  return (
    <Dialog open={open} onClose={() => setOpen(false)} maxWidth="md" fullWidth>
      <DialogTitle sx={{ bgcolor: "#f5f5f5", borderBottom: 1, borderColor: "divider" }}>
        Process Task: {activeForm.stageName} ({activeForm.pcbSerial})
      </DialogTitle>
      <DialogContent sx={{ mt: 2 }}>
        <ProcessFormPage
          pcbSerial={activeForm.pcbSerial}
          stageId={activeForm.stageId} 
          operator={currentUser}
          onSaveComplete={() => {
            onSaveSuccess(activeForm.pcbSerial, activeForm.stageId);
            setOpen(false);
          }}
        />
      </DialogContent>
    </Dialog>
  );
};

// --- Sub-Component: Task Tabs View ---
const TaskTabsView = ({ currentUser, inActionPCBs = [], onOpenForm }) => { 
  const [activeTab, setActiveTab] = useState(0);

  const myStages = useMemo(() => {
    const staffId = currentUser?.staffNumber || "";
    const uniqueMap = new Map();

    (inActionPCBs || []).forEach((pcb) => {
      (pcb.linkedOperations || []).forEach((op) => {
        if (op.assignedTo && op.assignedTo.includes(staffId)) {
          const id = String(op.sno || op["S.No"]); 
          if (!uniqueMap.has(id)) {
            uniqueMap.set(id, { id: id, name: op.name || op["Operation Name"] });
          }
        }
      });
    });

    return Array.from(uniqueMap.values()).sort((a, b) => parseInt(a.id) - parseInt(b.id));
  }, [inActionPCBs, currentUser]);

  const currentRows = useMemo(() => {
    if (!myStages || myStages.length === 0) return [];
    
    const activeStage = myStages[activeTab];
    if (!activeStage) return [];

    const targetStageId = activeStage.id;
    const rows = [];

    (inActionPCBs || []).forEach((pcb) => {
      const ops = pcb.linkedOperations || [];
      const op = ops.find(o => String(o.sno || o["S.No"]) === targetStageId);

      if (op) {
        const opIndex = ops.indexOf(op);
        let isLocked = false;
        if (opIndex > 0 && ops[opIndex - 1].status !== "Completed") {
          isLocked = true;
        }

        rows.push({
          pcbSerial: pcb["PCB Serial Number"] || pcb.serial_number || pcb._pcb_key_id,
          opStatus: op.status || "Pending",
          startTime: op.startTime,
          endTime: op.endTime,
          isLocked: isLocked,
          stageName: op.name,
          stageId: targetStageId
        });
      }
    });

    return rows;
  }, [myStages, activeTab, inActionPCBs]);

  if (myStages.length === 0) {
    return (
      <Paper sx={{ p: 4, textAlign: "center" }}>
        <Typography color="text.secondary">No active tasks assigned to you.</Typography>
      </Paper>
    );
  }

  return (
    <Box>
      <Paper elevation={0} sx={{ mb: 2, borderBottom: 1, borderColor: "divider" }}>
        <Tabs 
          value={activeTab} 
          onChange={(e, v) => setActiveTab(v)}
          variant="scrollable"
          scrollButtons="auto"
        >
          {myStages.map((stage) => (
            <Tab key={stage.id} label={`${stage.id}. ${stage.name}`} />
          ))}
        </Tabs>
      </Paper>

      <TableContainer component={Paper} elevation={1} sx={{ border: "1px solid #e0e0e0" }}>
        <Table>
          <TableHead sx={{ bgcolor: "#f5f5f5" }}>
            <TableRow>
              <TableCell><strong>PCB Serial</strong></TableCell>
              <TableCell><strong>Status</strong></TableCell>
              <TableCell><strong>Timing</strong></TableCell>
              <TableCell align="right"><strong>Action</strong></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {currentRows.map((row) => {
              const isDone = row.opStatus === "Completed";
              const inProgress = row.opStatus === "In Progress";
              
              return (
                <TableRow key={row.pcbSerial} hover>
                  <TableCell>
                    <Typography fontWeight="bold">{row.pcbSerial}</Typography>
                    {row.isLocked && (
                      <Chip icon={<LockIcon />} label="Locked" size="small" sx={{ mt: 0.5 }} />
                    )}
                  </TableCell>
                  
                  <TableCell>
                    <Chip 
                      label={row.opStatus} 
                      color={isDone ? "success" : inProgress ? "warning" : "default"}
                      size="small" 
                      variant={inProgress ? "filled" : "outlined"}
                    />
                  </TableCell>

                  {/* TIMING COLUMN - Updated on Save */}
                  <TableCell>
                    <Stack spacing={0.5}>
                       {row.startTime ? (
                         <Typography variant="caption" display="block">
                           Start: {new Date(row.startTime).toLocaleTimeString()}
                         </Typography>
                       ) : (
                         <Typography variant="caption" color="text.secondary">-</Typography>
                       )}
                       
                       {row.endTime ? (
                         <Typography variant="caption" color="success.main" display="block">
                           End: {new Date(row.endTime).toLocaleTimeString()}
                         </Typography>
                       ) : null}
                    </Stack>
                  </TableCell>

                  <TableCell align="right">
                    <Button
                      variant={isDone ? "outlined" : "contained"}
                      color={isDone ? "success" : "primary"}
                      size="small"
                      startIcon={isDone ? <CheckCircleIcon /> : <FormIcon />}
                      disabled={row.isLocked}
                      onClick={() => onOpenForm(row)}
                    >
                      {isDone ? "View / Edit" : "Process Task"}
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

// --- Main Page Component ---
const OperatorPage = ({ currentUser, inActionPCBs, updateInActionPCBs, onLogout }) => {
  
  // ✅ 1. Initialize Local State with Props or Dummy Data
  const [localPCBs, setLocalPCBs] = useState([]);
  const activeUser = currentUser || DUMMY_USER;

  // Effect to sync props to local state if props are provided
  useEffect(() => {
    if (inActionPCBs && inActionPCBs.length > 0) {
      setLocalPCBs(inActionPCBs);
    } else {
      setLocalPCBs(DUMMY_PCBS);
    }
  }, [inActionPCBs]);

  const [selectedView, setSelectedView] = useState(null); 
  const [openFormDialog, setOpenFormDialog] = useState(false);
  const [activeFormData, setActiveFormData] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, msg: "" });

  const handleOpenForm = (row) => {
    setActiveFormData(row);
    setOpenFormDialog(true);
  };

  const handleSaveSuccess = async (pcbSerial, stageId) => {
    const now = new Date().toISOString();

    // ✅ 2. Update Local State Immediately (Auto-fill table logic)
    setLocalPCBs((prevPCBs) => {
      return prevPCBs.map((pcb) => {
        const currentSerial = pcb["PCB Serial Number"] || pcb.serial_number || pcb._pcb_key_id;
        
        if (currentSerial !== pcbSerial) return pcb;

        // Find and update the specific operation
        const newOps = (pcb.linkedOperations || []).map((op) => {
          if (String(op.sno || op["S.No"]) === String(stageId)) {
            return {
              ...op,
              status: "Completed",
              endTime: now,
              // If start time was missing (never started), assume started when saved (now)
              // If start time existed, keep it.
              startTime: op.startTime || now 
            };
          }
          return op;
        });

        return { ...pcb, linkedOperations: newOps };
      });
    });

    // ✅ 3. Call External Update (if prop provided) & API
    if (updateInActionPCBs) {
       // Sync back to parent if parent function exists
       // (We repeat logic here or pass the new state if parent supports it)
    }

    await updatePCBStatusAPI(pcbSerial, stageId, "Completed");
    setSnackbar({ open: true, msg: "Task saved & updated successfully!" });
  };

  const renderContent = () => {
    if (selectedView === 'tasks') {
      return (
        <TaskTabsView 
          currentUser={activeUser}
          inActionPCBs={localPCBs} // ✅ Pass LOCAL state
          onOpenForm={handleOpenForm}
        />
      );
    }
    
    return (
      <Container maxWidth="lg" sx={{ mt: 4 }}>
         <Grid container spacing={4} justifyContent="center">
            <Grid item xs={12} sm={6} md={5}>
               <Card 
                 elevation={3} 
                 sx={{ borderRadius: 4, height: '100%', transition: '0.3s', '&:hover': { transform: 'translateY(-5px)' } }}
               >
                 <CardActionArea onClick={() => setSelectedView('tasks')} sx={{ height: '100%', p: 4 }}>
                   <CardContent sx={{ textAlign: 'center' }}>
                     <Avatar sx={{ bgcolor: "#1976d2", width: 80, height: 80, mb: 3, mx: 'auto' }}>
                       <FormIcon fontSize="large" />
                     </Avatar>
                     <Typography variant="h5" fontWeight="bold" gutterBottom>My Tasks</Typography>
                     <Typography color="text.secondary">View assigned stages and process pending PCBs.</Typography>
                   </CardContent>
                 </CardActionArea>
               </Card>
            </Grid>
         </Grid>
      </Container>
    );
  };

  return (
    <Box sx={{ display: "flex", flexDirection: "column", minHeight: "100vh", bgcolor: "#f4f6f8" }}>
      
      <AppBar position="sticky" color="default" elevation={0} sx={{ borderBottom: 1, borderColor: "divider" }}>
        <Toolbar>
          {selectedView ? (
            <IconButton onClick={() => setSelectedView(null)} color="primary" sx={{ mr: 2 }}>
              <ArrowBackIcon />
            </IconButton>
          ) : (
            <IconButton color="primary" sx={{ mr: 2, cursor: "default" }}>
              <HomeIcon />
            </IconButton>
          )}
          
          <Typography variant="h6" sx={{ flexGrow: 1, fontWeight: "bold" }}>
            {selectedView === 'tasks' ? "My Tasks" : "Operator Dashboard"}
          </Typography>
          
          <Typography variant="caption" sx={{ mr: 2, color: 'text.secondary', display: { xs: 'none', md: 'block' } }}>
            Logged in as: {activeUser.name}
          </Typography>

          <Button color="error" startIcon={<LogoutIcon />} onClick={onLogout}>
            Logout
          </Button>
        </Toolbar>
      </AppBar>

      <Box sx={{ flexGrow: 1, p: 3 }}>
        {selectedView === 'tasks' ? (
          <Box sx={{ bgcolor: "white", p: 3, borderRadius: 2, boxShadow: 1, minHeight: "80vh" }}>
            {renderContent()}
          </Box>
        ) : (
          renderContent()
        )}
      </Box>

      <ProcessFormDialog 
        open={openFormDialog}
        setOpen={setOpenFormDialog}
        activeForm={activeFormData}
        currentUser={activeUser}
        onSaveSuccess={handleSaveSuccess}
      />

      <Snackbar
        open={snackbar.open}
        autoHideDuration={3000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert severity="success" variant="filled">{snackbar.msg}</Alert>
      </Snackbar>

    </Box>
  );
};

export default OperatorPage;