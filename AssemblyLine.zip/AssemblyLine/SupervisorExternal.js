// import React from "react";
// import {
//   Box,
//   Typography,
//   Grid,
//   Card,
//   CardContent,
//   Button,
//   AppBar,
//   Toolbar,
//   IconButton,
// } from "@mui/material";
// import LogoutIcon from "@mui/icons-material/Logout";

// import {
//   PieChart,
//   Pie,
//   Cell,
//   Tooltip,
//   Legend,
//   BarChart,
//   Bar,
//   XAxis,
//   YAxis,
//   CartesianGrid,
// } from "recharts";

// const SupervisorExternal = ({ onLogout }) => {
//   // 🧮 Dummy data
//   const tasks = [
//     { name: "Task 1", status: "Completed" },
//     { name: "Task 2", status: "Pending" },
//     { name: "Task 3", status: "Pending" },
//     { name: "Task 4", status: "Completed" },
//     { name: "Task 5", status: "Completed" },
//   ];

//   const completedCount = tasks.filter((t) => t.status === "Completed").length;
//   const pendingCount = tasks.filter((t) => t.status === "Pending").length;

//   const pieData = [
//     { name: "Completed", value: completedCount },
//     { name: "Pending", value: pendingCount },
//   ];

//   const COLORS = ["#4CAF50", "#F44336"];

//   const barData = [
//     { name: "Completed", value: completedCount },
//     { name: "Pending", value: pendingCount },
//   ];

//   return (
//     <Box sx={{ display: "flex", height: "100vh", backgroundColor: "#ECEFF1" }}>
//       {/* Sidebar */}
//       <Box
//         sx={{
//           width: 220,
//           backgroundColor: "#263238",
//           color: "#fff",
//           display: "flex",
//           flexDirection: "column",
//           p: 2,
//           gap: 1,
//         }}
//       >
//         <Typography variant="h6" sx={{ mb: 2, color: "#90caf9" }}>
//           Supervisor (External)
//         </Typography>
//         <Button variant="contained" color="info">
//           Dashboard
//         </Button>
//       </Box>

//       {/* Main Content */}
//       <Box sx={{ flex: 1 }}>
        
//         {/* ✅ Added AppBar (same style as AdminDashboard) */}
//         <AppBar
//           position="static"
//           sx={{ backgroundColor: "#37474F", mb: 2, boxShadow: 0 }}
//         >
//           <Toolbar>
//             <Typography variant="h6" sx={{ flexGrow: 1 }}>
//               External Supervisor Dashboard
//             </Typography>

//             <IconButton color="inherit" onClick={onLogout}>
//               <LogoutIcon />
//             </IconButton>
//           </Toolbar>
//         </AppBar>

//         <Box sx={{ p: 4 }}>
//           <Grid container spacing={3}>
//             {/* Pie Chart */}
//             <Grid item xs={12} md={6}>
//               <Card>
//                 <CardContent>
//                   <Typography variant="h6" gutterBottom>
//                     Task Status Overview
//                   </Typography>
//                   <PieChart width={300} height={300}>
//                     <Pie
//                       data={pieData}
//                       dataKey="value"
//                       cx="50%"
//                       cy="50%"
//                       outerRadius={90}
//                       label
//                     >
//                       {pieData.map((entry, index) => (
//                         <Cell
//                           key={`cell-${index}`}
//                           fill={COLORS[index % COLORS.length]}
//                         />
//                       ))}
//                     </Pie>
//                     <Tooltip />
//                     <Legend />
//                   </PieChart>
//                 </CardContent>
//               </Card>
//             </Grid>

//             {/* Bar Chart */}
//             <Grid item xs={12} md={6}>
//               <Card>
//                 <CardContent>
//                   <Typography variant="h6" gutterBottom>
//                     Task Distribution
//                   </Typography>
//                   <BarChart
//                     width={350}
//                     height={300}
//                     data={barData}
//                     margin={{ top: 20, right: 20, left: 0, bottom: 20 }}
//                   >
//                     <CartesianGrid strokeDasharray="3 3" />
//                     <XAxis dataKey="name" />
//                     <YAxis />
//                     <Tooltip />
//                     <Legend />
//                     <Bar dataKey="value" fill="#2196F3" />
//                   </BarChart>
//                 </CardContent>
//               </Card>
//             </Grid>
//           </Grid>

//           {/* Summary Cards */}
//           <Grid container spacing={3} sx={{ mt: 2 }}>
//             <Grid item xs={12} md={6}>
//               <Card sx={{ bgcolor: "#C8E6C9" }}>
//                 <CardContent>
//                   <Typography variant="h6">Completed Tasks</Typography>
//                   <Typography variant="h4" color="success.main">
//                     {completedCount}
//                   </Typography>
//                 </CardContent>
//               </Card>
//             </Grid>
//             <Grid item xs={12} md={6}>
//               <Card sx={{ bgcolor: "#FFCDD2" }}>
//                 <CardContent>
//                   <Typography variant="h6">Pending Tasks</Typography>
//                   <Typography variant="h4" color="error.main">
//                     {pendingCount}
//                   </Typography>
//                 </CardContent>
//               </Card>
//             </Grid>
//           </Grid>
//         </Box>
//       </Box>
//     </Box>
//   );
// };

// export default SupervisorExternal;

// src/components/SupervisorExternal/SupervisorExternal.jsx
import React, { useState } from "react";
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  CardActionArea,
  Button,
  AppBar,
  Toolbar,
  IconButton,
  Container,
  Avatar,
  Tooltip,
  useTheme,
  Paper
} from "@mui/material";
import {
  Logout as LogoutIcon,
  BarChart as BarChartIcon,
  PieChart as PieChartIcon,
  ArrowBack as ArrowBackIcon,
  Home as HomeIcon,
  Insights as InsightsIcon,
  Assessment as AssessmentIcon
} from "@mui/icons-material";

// Chart Imports
import {
  PieChart,
  Pie,
  Cell,
  Tooltip as RechartsTooltip,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer
} from "recharts";

// --- Sub-Component: Visual Analytics View (Charts) ---
const VisualAnalyticsView = ({ pieData, barData, COLORS }) => (
  <Box>
    <Box sx={{ mb: 3 }}>
      <Typography variant="h5" fontWeight="bold" color="primary.main">
        Visual Performance Analytics
      </Typography>
      <Typography variant="body2" color="text.secondary">
        Graphical representation of task completion rates.
      </Typography>
    </Box>

    <Grid container spacing={3}>
      {/* Pie Chart Card */}
      <Grid item xs={12} md={6}>
        <Card elevation={0} sx={{ border: "1px solid #e0e0e0", height: '100%' }}>
          <CardContent sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <Typography variant="h6" gutterBottom fontWeight="bold">
              Task Status Overview
            </Typography>
            {/* Centering the chart */}
            <Box sx={{ display: 'flex', justifyContent: 'center', width: '100%' }}>
              <PieChart width={300} height={300}>
                <Pie
                  data={pieData}
                  dataKey="value"
                  cx="50%"
                  cy="50%"
                  outerRadius={90}
                  label
                >
                  {pieData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={COLORS[index % COLORS.length]}
                    />
                  ))}
                </Pie>
                <RechartsTooltip />
                <Legend />
              </PieChart>
            </Box>
          </CardContent>
        </Card>
      </Grid>

      {/* Bar Chart Card */}
      <Grid item xs={12} md={6}>
        <Card elevation={0} sx={{ border: "1px solid #e0e0e0", height: '100%' }}>
          <CardContent sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <Typography variant="h6" gutterBottom fontWeight="bold">
              Task Distribution
            </Typography>
            <Box sx={{ display: 'flex', justifyContent: 'center', width: '100%' }}>
              <BarChart
                width={350}
                height={300}
                data={barData}
                margin={{ top: 20, right: 20, left: 0, bottom: 20 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <RechartsTooltip />
                <Legend />
                <Bar dataKey="value" fill="#2196F3" />
              </BarChart>
            </Box>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  </Box>
);

// --- Sub-Component: Metrics View (Summary Cards) ---
const MetricsView = ({ completedCount, pendingCount }) => (
  <Box>
    <Box sx={{ mb: 3 }}>
      <Typography variant="h5" fontWeight="bold" color="primary.main">
        Key Metrics Summary
      </Typography>
      <Typography variant="body2" color="text.secondary">
        Real-time numeric breakdown of current workload.
      </Typography>
    </Box>

    <Grid container spacing={3}>
      <Grid item xs={12} md={6}>
        <Card 
          elevation={0} 
          sx={{ 
            bgcolor: "#e8f5e9", // Light Green
            border: "1px solid #c8e6c9",
            borderRadius: 3
          }}
        >
          <CardContent sx={{ textAlign: 'center', py: 5 }}>
            <Typography variant="h6" color="success.dark" gutterBottom>
              Completed Tasks
            </Typography>
            <Typography variant="h2" fontWeight="bold" color="success.main">
              {completedCount}
            </Typography>
          </CardContent>
        </Card>
      </Grid>
      
      <Grid item xs={12} md={6}>
        <Card 
          elevation={0} 
          sx={{ 
            bgcolor: "#ffebee", // Light Red
            border: "1px solid #ffcdd2",
            borderRadius: 3
          }}
        >
          <CardContent sx={{ textAlign: 'center', py: 5 }}>
            <Typography variant="h6" color="error.dark" gutterBottom>
              Pending Tasks
            </Typography>
            <Typography variant="h2" fontWeight="bold" color="error.main">
              {pendingCount}
            </Typography>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  </Box>
);

// --- Main Component ---
const SupervisorExternal = ({ onLogout }) => {
  const theme = useTheme();
  const [selectedView, setSelectedView] = useState(null);

  // 🧮 Data Logic (Kept exactly as original)
  const tasks = [
    { name: "Task 1", status: "Completed" },
    { name: "Task 2", status: "Pending" },
    { name: "Task 3", status: "Pending" },
    { name: "Task 4", status: "Completed" },
    { name: "Task 5", status: "Completed" },
  ];

  const completedCount = tasks.filter((t) => t.status === "Completed").length;
  const pendingCount = tasks.filter((t) => t.status === "Pending").length;

  const pieData = [
    { name: "Completed", value: completedCount },
    { name: "Pending", value: pendingCount },
  ];

  const COLORS = ["#4CAF50", "#F44336"];

  const barData = [
    { name: "Completed", value: completedCount },
    { name: "Pending", value: pendingCount },
  ];

  // -- Menu Configuration --
  const menuItems = [
    {
      id: 'analytics',
      text: "Visual Analytics",
      description: "View graphical breakdown (Pie & Bar charts) of tasks.",
      icon: <InsightsIcon fontSize="large" />,
      color: "#2196F3", // Blue
    },
    {
      id: 'metrics',
      text: "Task Metrics",
      description: "View specific counts for completed and pending items.",
      icon: <AssessmentIcon fontSize="large" />,
      color: "#673AB7", // Deep Purple
    },
  ];

  const handleBackToHome = () => setSelectedView(null);

  // -- Render Helper --
  const renderContent = () => {
    switch (selectedView?.id) {
      case 'analytics':
        return (
          <VisualAnalyticsView 
            pieData={pieData} 
            barData={barData} 
            COLORS={COLORS} 
          />
        );
      case 'metrics':
        return (
          <MetricsView 
            completedCount={completedCount} 
            pendingCount={pendingCount} 
          />
        );
      default:
        return <HomeCardGrid />;
    }
  };

  // -- Home Grid Component --
  const HomeCardGrid = () => (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ mb: 5, textAlign: 'center' }}>
        <Typography variant="h4" component="h1" gutterBottom fontWeight="bold" color="text.primary">
          External Supervisor Dashboard
        </Typography>
        <Typography variant="subtitle1" color="text.secondary">
          Monitor team performance and task completion status.
        </Typography>
      </Box>

      <Grid container spacing={4} justifyContent="center">
        {menuItems.map((item) => (
          <Grid item key={item.id} xs={12} sm={6} md={5}>
            <Card
              elevation={2}
              sx={{
                height: "100%",
                borderRadius: 4,
                transition: "transform 0.3s, box-shadow 0.3s",
                "&:hover": {
                  transform: "translateY(-5px)",
                  boxShadow: theme.shadows[8],
                  "& .MuiAvatar-root": {
                      backgroundColor: item.color,
                      color: "white"
                  }
                },
              }}
            >
              <CardActionArea
                onClick={() => setSelectedView(item)}
                sx={{ height: "100%", p: 3 }}
              >
                <CardContent sx={{ display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center" }}>
                  <Avatar
                    sx={{
                      bgcolor: theme.palette.grey[100],
                      color: item.color,
                      width: 80,
                      height: 80,
                      mb: 2,
                      transition: "all 0.3s ease",
                    }}
                  >
                    {item.icon}
                  </Avatar>
                  <Typography variant="h5" component="div" fontWeight="bold" gutterBottom>
                    {item.text}
                  </Typography>
                  <Typography variant="body1" color="text.secondary">
                    {item.description}
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  );

  return (
    <Box sx={{ display: "flex", flexDirection: "column", minHeight: "100vh", bgcolor: "#f4f6f8" }}>
      {/* Top App Bar */}
      <AppBar
        position="sticky"
        elevation={0}
        sx={{
          backgroundColor: theme.palette.background.paper,
          color: theme.palette.text.primary,
          borderBottom: `1px solid ${theme.palette.divider}`
        }}
      >
        <Toolbar>
          {/* Back / Home Logic */}
          {selectedView ? (
            <Tooltip title="Back to Dashboard">
              <IconButton edge="start" color="primary" onClick={handleBackToHome} sx={{ mr: 2 }}>
                <ArrowBackIcon />
              </IconButton>
            </Tooltip>
          ) : (
            <IconButton edge="start" color="primary" sx={{ mr: 2, cursor: 'default' }}>
              <HomeIcon />
            </IconButton>
          )}

          <Typography variant="h6" component="div" sx={{ flexGrow: 1, fontWeight: 600 }}>
            {selectedView ? selectedView.text : "Supervisor Panel"}
          </Typography>

          <Button 
            color="error" 
            onClick={onLogout} 
            startIcon={<LogoutIcon />}
            sx={{ fontWeight: 'bold' }}
          >
            Logout
          </Button>
        </Toolbar>
      </AppBar>

      {/* Main Content Area */}
      <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
        {selectedView ? (
          <Box sx={{ bgcolor: theme.palette.background.paper, p: 4, borderRadius: 2, boxShadow: 1, minHeight: '80vh' }}>
            {renderContent()}
          </Box>
        ) : (
          renderContent()
        )}
      </Box>
    </Box>
  );
};

export default SupervisorExternal;
