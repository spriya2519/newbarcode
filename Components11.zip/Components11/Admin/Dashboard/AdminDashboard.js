import React, { useState } from "react";
import { Box } from "@mui/material";

// Sub-components
import AdminHeader from "./AdminHeader";
import HomeCards from "./HomeCards";
import MasterView from "./MasterView";
import InActionView from "./InActionView";
import CreateProjectView from "./CreateProjectView";
import PreviewView from "./PreviewView";
import ProfileView from "./ProfileView";

// Utilities for matching Serial Numbers safely
import { normalizeSerialValue, detectSerialKeyFromKeys } from "../utils/helpers";

// Constants
const STATUS_KEY = "Status";
const STATUS_NOT_YET_ASSIGNED = "Not Yet Created";

export default function AdminDashboard({
  onLogout,
  addInActionPCBs,     // Updates App.js (Supervisor List)
  deleteInActionPCB,   // Updates App.js (Supervisor List)
  masterList,
  setMasterList,
  inActionList,
  setInActionList
}) {

  // View State
  const [view, setView] = useState("home");

  // Data States
  const [uploadedPreviewData, setUploadedPreviewData] = useState(null);
  const [previewColumns, setPreviewColumns] = useState([]);
  const [pcbSerialKey, setPcbSerialKey] = useState("serial_number");
  const [selectedIds, setSelectedIds] = useState(new Set());

  // --- 🔥 1. DUPLICATE PREVENTION GATEKEEPER ---
  // We pass this function to PreviewView instead of the raw setMasterList.
  // It intercepts the update, checks for duplicates, and cleans the list.
  const safeSetMasterList = (newStateOrUpdater) => {
    setMasterList((prevList) => {
      // Resolve the new list (handle both value and function updates)
      const incomingList = typeof newStateOrUpdater === "function"
        ? newStateOrUpdater(prevList)
        : newStateOrUpdater;

      if (!incomingList || incomingList.length === 0) return incomingList;

      // Deduplication Logic
      const seenSerials = new Set();
      const uniqueList = [];
      let duplicateCount = 0;

      for (const item of incomingList) {
        // Detect key dynamically for each item (safe fallback)
        const key = item._pcb_key_id || detectSerialKeyFromKeys(Object.keys(item));
        const rawSerial = item[key] || item["serial number"] || item["SNo"] || "";
        const normalized = normalizeSerialValue(rawSerial);

        if (normalized && seenSerials.has(normalized)) {
          duplicateCount++;
        } else {
          if (normalized) seenSerials.add(normalized);
          uniqueList.push(item);
        }
      }

      if (duplicateCount > 0) {
        alert(`Blocked ${duplicateCount} duplicate PCBs. They were already in the list or duplicated in the upload.`);
      }

      return uniqueList;
    });
  };

  // --- 🔥 2. CUSTOM DELETE HANDLER ---
  // Handles the "Double Update" (In-Action + Master Reset)
  const handleLocalDeletePCB = (serialToRemove) => {
    
    // 1. Remove from Admin's In-Action List
    setInActionList((prev) => 
      prev.filter((item) => {
        const key = item._pcb_key_id || pcbSerialKey || detectSerialKeyFromKeys(Object.keys(item));
        const itemSerial = item[key] || item["serial number"] || item["SNo"];
        return normalizeSerialValue(itemSerial) !== normalizeSerialValue(serialToRemove);
      })
    );

    // 2. Update Master List (Reset Status so Checkbox works again)
    setMasterList((prev) => 
      prev.map((item) => {
        const key = detectSerialKeyFromKeys(Object.keys(item));
        const itemSerial = item[key] || item["serial number"] || item["SNo"];

        if (normalizeSerialValue(itemSerial) === normalizeSerialValue(serialToRemove)) {
          return { ...item, [STATUS_KEY]: STATUS_NOT_YET_ASSIGNED };
        }
        return item;
      })
    );

    // 3. Sync with App.js (Remove from Supervisor's List)
    if (deleteInActionPCB) {
      deleteInActionPCB(serialToRemove);
    }
  };

  return (
    <Box
      sx={{
        minHeight: "100vh",
        background: "linear-gradient(135deg, #e3f2fd, #bbdefb)",
      }}
    >

      {/* Top Bar */}
      <AdminHeader
        onLogout={onLogout}
        onHome={() => setView("home")}
      />

      {/* Dashboard Router */}
      {view === "home" && <HomeCards setView={setView} />}

      {view === "master" && (
        <MasterView
          masterList={masterList}
          setMasterList={setMasterList} // MasterView just updates statuses, usually safe.
          setInActionList={setInActionList}
          addInActionPCBs={addInActionPCBs}
          selectedIds={selectedIds}
          setSelectedIds={setSelectedIds}
          setPcbSerialKey={setPcbSerialKey}
          setView={setView}
        />
      )}

      {view === "inaction" && (
        <InActionView
          inActionList={inActionList}
          // Pass our custom handler instead of the raw prop
          deleteInActionPCB={handleLocalDeletePCB} 
          pcbSerialKey={pcbSerialKey}
          setView={setView}
        />
      )}

      {view === "create" && (
        <CreateProjectView
          setUploadedPreviewData={setUploadedPreviewData}
          setPreviewColumns={setPreviewColumns}
          setPcbSerialKey={setPcbSerialKey}
          setView={setView}
        />
      )}

      {view === "preview" && uploadedPreviewData && (
        <PreviewView
          uploadedPreviewData={uploadedPreviewData}
          previewColumns={previewColumns}
          setUploadedPreviewData={setUploadedPreviewData}
          setPreviewColumns={setPreviewColumns}
          // 🔥 PASS THE SAFE SETTER HERE
          setMasterList={safeSetMasterList} 
          setView={setView}
        />
      )}

      {view === "profile" && <ProfileView setView={setView} />}

    </Box>
  );
}